/*
 * DemoModel_types.h
 *
 * Code generation for model "DemoModel".
 *
 * Model version              : 1.69
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Sun Feb 21 10:18:30 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_DemoModel_types_h_
#define RTW_HEADER_DemoModel_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_SysCmd_
#define DEFINED_TYPEDEF_FOR_SysCmd_

typedef struct {
  real_T Master;
  real_T PrimPwrSupply;
  real_T SecPwrSupply;
} SysCmd;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SysFailCmd_
#define DEFINED_TYPEDEF_FOR_SysFailCmd_

typedef struct {
  real_T FAN1Fail;
  real_T FAN2Fail;
  real_T FAN3Fail;
  real_T OverHeat26;
  real_T OverHeat28;
} SysFailCmd;

#endif

#ifndef DEFINED_TYPEDEF_FOR_RelayFailCmd_
#define DEFINED_TYPEDEF_FOR_RelayFailCmd_

typedef struct {
  real_T ORCond2_1;
  real_T ORCond2_2;
  real_T ANDCond3_1;
  real_T ANDCond3_2;
  real_T ANDCond3_3;
  real_T ANDCond4;
  real_T ANDCond5_12;
  real_T ANDCond5_3;
  real_T ORCond7_1;
  real_T ORCond7_2;
  real_T ANDCond8;
  real_T PrimFailCond;
  real_T SecFailCond;
} RelayFailCmd;

#endif

#ifndef DEFINED_TYPEDEF_FOR_FANState_
#define DEFINED_TYPEDEF_FOR_FANState_

typedef struct {
  real_T FAN1Ener;
  real_T FAN1State;
  real_T FAN2Ener;
  real_T FAN2State;
  real_T FAN3Ener;
  real_T FAN3State;
} FANState;

#endif

#ifndef DEFINED_TYPEDEF_FOR_RelayState_
#define DEFINED_TYPEDEF_FOR_RelayState_

typedef struct {
  real_T ORCond2_1;
  real_T ORCond2_2;
  real_T ANDCond3_1;
  real_T ANDCond3_2;
  real_T ANDCond3_3;
  real_T ANDCond4;
  real_T ANDCond5_12;
  real_T ANDCond5_3;
  real_T ANDCond7_1;
  real_T ANDCond7_2;
  real_T ANDCond8;
  real_T PrimFailCond;
  real_T SecFailCond;
} RelayState;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SysState_
#define DEFINED_TYPEDEF_FOR_SysState_

typedef struct {
  real_T MasterInd;
} SysState;

#endif

/* Parameters (default storage) */
typedef struct P_DemoModel_T_ P_DemoModel_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_DemoModel_T RT_MODEL_DemoModel_T;

#endif                                 /* RTW_HEADER_DemoModel_types_h_ */
