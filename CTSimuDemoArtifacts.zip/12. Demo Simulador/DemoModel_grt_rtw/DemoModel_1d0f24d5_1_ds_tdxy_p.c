/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#include "ne_ds.h"
#include "DemoModel_1d0f24d5_1_ds_tdxy_p.h"
#include "DemoModel_1d0f24d5_1_ds_sys_struct.h"
#include "DemoModel_1d0f24d5_1_ds_externals.h"
#include "DemoModel_1d0f24d5_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T DemoModel_1d0f24d5_1_ds_tdxy_p(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t1, NeDsMethodOutput *t2)
{
  PmSparsityPattern out;
  (void)t1;
  out = t2->mTDXY_P;
  out.mNumCol = 46ULL;
  out.mNumRow = 20ULL;
  out.mJc[0] = 0;
  out.mJc[1] = 9;
  out.mJc[2] = 10;
  out.mJc[3] = 10;
  out.mJc[4] = 11;
  out.mJc[5] = 11;
  out.mJc[6] = 11;
  out.mJc[7] = 13;
  out.mJc[8] = 17;
  out.mJc[9] = 20;
  out.mJc[10] = 20;
  out.mJc[11] = 21;
  out.mJc[12] = 22;
  out.mJc[13] = 23;
  out.mJc[14] = 23;
  out.mJc[15] = 24;
  out.mJc[16] = 24;
  out.mJc[17] = 25;
  out.mJc[18] = 25;
  out.mJc[19] = 25;
  out.mJc[20] = 25;
  out.mJc[21] = 26;
  out.mJc[22] = 26;
  out.mJc[23] = 26;
  out.mJc[24] = 26;
  out.mJc[25] = 26;
  out.mJc[26] = 27;
  out.mJc[27] = 28;
  out.mJc[28] = 28;
  out.mJc[29] = 28;
  out.mJc[30] = 34;
  out.mJc[31] = 35;
  out.mJc[32] = 35;
  out.mJc[33] = 36;
  out.mJc[34] = 37;
  out.mJc[35] = 38;
  out.mJc[36] = 39;
  out.mJc[37] = 40;
  out.mJc[38] = 40;
  out.mJc[39] = 40;
  out.mJc[40] = 40;
  out.mJc[41] = 40;
  out.mJc[42] = 40;
  out.mJc[43] = 40;
  out.mJc[44] = 40;
  out.mJc[45] = 40;
  out.mJc[46] = 40;
  out.mIr[0] = 1;
  out.mIr[1] = 2;
  out.mIr[2] = 3;
  out.mIr[3] = 5;
  out.mIr[4] = 9;
  out.mIr[5] = 12;
  out.mIr[6] = 14;
  out.mIr[7] = 15;
  out.mIr[8] = 19;
  out.mIr[9] = 15;
  out.mIr[10] = 15;
  out.mIr[11] = 8;
  out.mIr[12] = 15;
  out.mIr[13] = 0;
  out.mIr[14] = 3;
  out.mIr[15] = 4;
  out.mIr[16] = 16;
  out.mIr[17] = 0;
  out.mIr[18] = 4;
  out.mIr[19] = 17;
  out.mIr[20] = 3;
  out.mIr[21] = 1;
  out.mIr[22] = 5;
  out.mIr[23] = 2;
  out.mIr[24] = 8;
  out.mIr[25] = 9;
  out.mIr[26] = 6;
  out.mIr[27] = 6;
  out.mIr[28] = 7;
  out.mIr[29] = 10;
  out.mIr[30] = 11;
  out.mIr[31] = 13;
  out.mIr[32] = 16;
  out.mIr[33] = 18;
  out.mIr[34] = 7;
  out.mIr[35] = 11;
  out.mIr[36] = 13;
  out.mIr[37] = 11;
  out.mIr[38] = 14;
  out.mIr[39] = 12;
  (void)sys;
  (void)t2;
  return 0;
}
