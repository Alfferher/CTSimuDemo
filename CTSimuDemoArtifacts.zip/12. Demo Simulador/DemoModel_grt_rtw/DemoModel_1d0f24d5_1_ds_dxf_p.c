/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#include "ne_ds.h"
#include "DemoModel_1d0f24d5_1_ds_dxf_p.h"
#include "DemoModel_1d0f24d5_1_ds_sys_struct.h"
#include "DemoModel_1d0f24d5_1_ds_externals.h"
#include "DemoModel_1d0f24d5_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T DemoModel_1d0f24d5_1_ds_dxf_p(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t1, NeDsMethodOutput *t2)
{
  PmSparsityPattern out;
  int32_T b;
  static int32_T _cg_const_2[157] = { 2, 4, 5, 6, 8, 11, 17, 18, 20, 21, 22, 24,
    26, 35, 40, 2, 8, 11, 24, 40, 0, 2, 8, 11, 24, 40, 3, 9, 1, 2, 3, 8, 11, 18,
    24, 40, 42, 45, 4, 5, 23, 24, 26, 37, 40, 5, 24, 26, 40, 3, 9, 11, 4, 24, 26,
    40, 21, 24, 40, 6, 24, 40, 7, 22, 24, 40, 10, 11, 18, 19, 24, 40, 11, 17, 42,
    11, 45, 12, 13, 17, 24, 30, 40, 41, 42, 13, 15, 13, 15, 17, 14, 16, 23, 32,
    34, 37, 43, 23, 32, 37, 43, 17, 30, 17, 41, 19, 23, 25, 26, 32, 34, 36, 37,
    38, 39, 23, 25, 29, 37, 44, 18, 19, 23, 24, 37, 40, 23, 36, 37, 39, 23, 37,
    38, 23, 36, 37, 39, 20, 24, 40, 24, 35, 40, 23, 37, 24, 40, 25, 29, 25, 44,
    27, 28, 31, 32, 34, 33 };

  (void)t1;
  out = t2->mDXF_P;
  out.mNumCol = 46ULL;
  out.mNumRow = 46ULL;
  out.mJc[0] = 0;
  out.mJc[1] = 15;
  out.mJc[2] = 20;
  out.mJc[3] = 21;
  out.mJc[4] = 26;
  out.mJc[5] = 28;
  out.mJc[6] = 29;
  out.mJc[7] = 38;
  out.mJc[8] = 45;
  out.mJc[9] = 49;
  out.mJc[10] = 52;
  out.mJc[11] = 56;
  out.mJc[12] = 59;
  out.mJc[13] = 62;
  out.mJc[14] = 63;
  out.mJc[15] = 66;
  out.mJc[16] = 67;
  out.mJc[17] = 72;
  out.mJc[18] = 75;
  out.mJc[19] = 77;
  out.mJc[20] = 78;
  out.mJc[21] = 85;
  out.mJc[22] = 87;
  out.mJc[23] = 90;
  out.mJc[24] = 91;
  out.mJc[25] = 92;
  out.mJc[26] = 97;
  out.mJc[27] = 101;
  out.mJc[28] = 103;
  out.mJc[29] = 105;
  out.mJc[30] = 115;
  out.mJc[31] = 120;
  out.mJc[32] = 126;
  out.mJc[33] = 130;
  out.mJc[34] = 133;
  out.mJc[35] = 137;
  out.mJc[36] = 140;
  out.mJc[37] = 143;
  out.mJc[38] = 145;
  out.mJc[39] = 147;
  out.mJc[40] = 149;
  out.mJc[41] = 151;
  out.mJc[42] = 152;
  out.mJc[43] = 153;
  out.mJc[44] = 154;
  out.mJc[45] = 156;
  out.mJc[46] = 157;
  for (b = 0; b < 157; b++) {
    out.mIr[b] = _cg_const_2[b];
  }

  (void)sys;
  (void)t2;
  return 0;
}
