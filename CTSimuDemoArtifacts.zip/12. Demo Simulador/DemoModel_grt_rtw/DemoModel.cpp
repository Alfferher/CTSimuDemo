/*
 * DemoModel.cpp
 *
 * Code generation for model "DemoModel".
 *
 * Model version              : 1.69
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Sun Feb 21 10:18:30 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "DemoModel.h"
#include "DemoModel_private.h"

/* Block signals (default storage) */
B_DemoModel_T DemoModel_B;

/* Block states (default storage) */
DW_DemoModel_T DemoModel_DW;

/* External inputs (root inport signals with default storage) */
ExtU_DemoModel_T DemoModel_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_DemoModel_T DemoModel_Y;

/* Real-time model */
RT_MODEL_DemoModel_T DemoModel_M_ = RT_MODEL_DemoModel_T();
RT_MODEL_DemoModel_T *const DemoModel_M = &DemoModel_M_;
real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/* Model step function */
void DemoModel_step(void)
{
  /* local block i/o variables */
  real_T rtb_Divide;
  real_T rtb_Divide_h;
  real_T rtb_Divide_l;

  {
    NeslSimulationData *simulationData;
    real_T time;
    real_T tmp[184];
    int_T tmp_0[47];
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_1;
    char *msg;
    real_T time_0;
    real_T tmp_2[322];
    int_T tmp_3[48];
    real_T rtb_ORCond2_2;
    real_T rtb_ORCond2_1;
    real_T rtb_Delay_p;
    real_T rtb_OUTPUT_1_0[20];
    boolean_T rtb_Compare_g;
    boolean_T rtb_Compare;
    real_T time_tmp;

    /* Sum: '<S39>/Sum' incorporates:
     *  Constant: '<S42>/Constant'
     *  Constant: '<S43>/Constant'
     *  DataTypeConversion: '<S39>/Cast To Double2'
     *  DataTypeConversion: '<S39>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S39>/Memory'
     *  RelationalOperator: '<S42>/Compare'
     *  RelationalOperator: '<S43>/Compare'
     *  Switch: '<S39>/Switch'
     */
    DemoModel_B.Sum = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond3_1 ==
       DemoModel_P.CompareToConstant3_const) > DemoModel_P.Switch_Threshold)) &&
      DemoModel_DW.Memory_PreviousInput) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond3_1 ==
       DemoModel_P.CompareToConstant2_const);

    /* DataTypeConversion: '<S39>/Cast To Double1' incorporates:
     *  Logic: '<S39>/NOT'
     */
    DemoModel_B.CastToDouble1 = !(DemoModel_B.Sum != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_2_1_1' */
    DemoModel_B.INPUT_2_1_1[0] = DemoModel_B.CastToDouble1;
    DemoModel_B.INPUT_2_1_1[1] = 0.0;
    DemoModel_B.INPUT_2_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_2_1_1_Discrete[0] = !(DemoModel_B.INPUT_2_1_1[0] ==
        DemoModel_DW.INPUT_2_1_1_Discrete[1]);
      DemoModel_DW.INPUT_2_1_1_Discrete[1] = DemoModel_B.INPUT_2_1_1[0];
    }

    DemoModel_B.INPUT_2_1_1[0] = DemoModel_DW.INPUT_2_1_1_Discrete[1];
    DemoModel_B.INPUT_2_1_1[3] = DemoModel_DW.INPUT_2_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_2_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_2_2_1' */
    DemoModel_B.INPUT_2_2_1[0] = DemoModel_B.CastToDouble1;
    DemoModel_B.INPUT_2_2_1[1] = 0.0;
    DemoModel_B.INPUT_2_2_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_2_2_1_Discrete[0] = !(DemoModel_B.INPUT_2_2_1[0] ==
        DemoModel_DW.INPUT_2_2_1_Discrete[1]);
      DemoModel_DW.INPUT_2_2_1_Discrete[1] = DemoModel_B.INPUT_2_2_1[0];
    }

    DemoModel_B.INPUT_2_2_1[0] = DemoModel_DW.INPUT_2_2_1_Discrete[1];
    DemoModel_B.INPUT_2_2_1[3] = DemoModel_DW.INPUT_2_2_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_2_2_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_1_1_1' */
    DemoModel_B.INPUT_1_1_1[0] = DemoModel_B.Sum;
    DemoModel_B.INPUT_1_1_1[1] = 0.0;
    DemoModel_B.INPUT_1_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_1_1_1_Discrete[0] = !(DemoModel_B.INPUT_1_1_1[0] ==
        DemoModel_DW.INPUT_1_1_1_Discrete[1]);
      DemoModel_DW.INPUT_1_1_1_Discrete[1] = DemoModel_B.INPUT_1_1_1[0];
    }

    DemoModel_B.INPUT_1_1_1[0] = DemoModel_DW.INPUT_1_1_1_Discrete[1];
    DemoModel_B.INPUT_1_1_1[3] = DemoModel_DW.INPUT_1_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_1_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_1_2_1' */
    DemoModel_B.INPUT_1_2_1[0] = DemoModel_B.Sum;
    DemoModel_B.INPUT_1_2_1[1] = 0.0;
    DemoModel_B.INPUT_1_2_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_1_2_1_Discrete[0] = !(DemoModel_B.INPUT_1_2_1[0] ==
        DemoModel_DW.INPUT_1_2_1_Discrete[1]);
      DemoModel_DW.INPUT_1_2_1_Discrete[1] = DemoModel_B.INPUT_1_2_1[0];
    }

    DemoModel_B.INPUT_1_2_1[0] = DemoModel_DW.INPUT_1_2_1_Discrete[1];
    DemoModel_B.INPUT_1_2_1[3] = DemoModel_DW.INPUT_1_2_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_1_2_1' */

    /* Sum: '<S50>/Sum' incorporates:
     *  Constant: '<S53>/Constant'
     *  Constant: '<S54>/Constant'
     *  DataTypeConversion: '<S50>/Cast To Double2'
     *  DataTypeConversion: '<S50>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S50>/Memory'
     *  RelationalOperator: '<S53>/Compare'
     *  RelationalOperator: '<S54>/Compare'
     *  Switch: '<S50>/Switch'
     */
    DemoModel_B.Sum_j = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond3_2 ==
       DemoModel_P.CompareToConstant3_const_e) > DemoModel_P.Switch_Threshold_a))
      && DemoModel_DW.Memory_PreviousInput_p) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond3_2 ==
       DemoModel_P.CompareToConstant2_const_p);

    /* DataTypeConversion: '<S50>/Cast To Double1' incorporates:
     *  Logic: '<S50>/NOT'
     */
    DemoModel_B.CastToDouble1_o = !(DemoModel_B.Sum_j != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_4_1_1' */
    DemoModel_B.INPUT_4_1_1[0] = DemoModel_B.CastToDouble1_o;
    DemoModel_B.INPUT_4_1_1[1] = 0.0;
    DemoModel_B.INPUT_4_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_4_1_1_Discrete[0] = !(DemoModel_B.INPUT_4_1_1[0] ==
        DemoModel_DW.INPUT_4_1_1_Discrete[1]);
      DemoModel_DW.INPUT_4_1_1_Discrete[1] = DemoModel_B.INPUT_4_1_1[0];
    }

    DemoModel_B.INPUT_4_1_1[0] = DemoModel_DW.INPUT_4_1_1_Discrete[1];
    DemoModel_B.INPUT_4_1_1[3] = DemoModel_DW.INPUT_4_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_4_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_3_1_1' */
    DemoModel_B.INPUT_3_1_1[0] = DemoModel_B.Sum_j;
    DemoModel_B.INPUT_3_1_1[1] = 0.0;
    DemoModel_B.INPUT_3_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_3_1_1_Discrete[0] = !(DemoModel_B.INPUT_3_1_1[0] ==
        DemoModel_DW.INPUT_3_1_1_Discrete[1]);
      DemoModel_DW.INPUT_3_1_1_Discrete[1] = DemoModel_B.INPUT_3_1_1[0];
    }

    DemoModel_B.INPUT_3_1_1[0] = DemoModel_DW.INPUT_3_1_1_Discrete[1];
    DemoModel_B.INPUT_3_1_1[3] = DemoModel_DW.INPUT_3_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_3_1_1' */

    /* Sum: '<S61>/Sum' incorporates:
     *  Constant: '<S64>/Constant'
     *  Constant: '<S65>/Constant'
     *  DataTypeConversion: '<S61>/Cast To Double2'
     *  DataTypeConversion: '<S61>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S61>/Memory'
     *  RelationalOperator: '<S64>/Compare'
     *  RelationalOperator: '<S65>/Compare'
     *  Switch: '<S61>/Switch'
     */
    DemoModel_B.Sum_p = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond3_3 ==
       DemoModel_P.CompareToConstant3_const_eo) > DemoModel_P.Switch_Threshold_n))
      && DemoModel_DW.Memory_PreviousInput_k) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond3_3 ==
       DemoModel_P.CompareToConstant2_const_f);

    /* DataTypeConversion: '<S61>/Cast To Double1' incorporates:
     *  Logic: '<S61>/NOT'
     */
    DemoModel_B.CastToDouble1_e = !(DemoModel_B.Sum_p != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_6_1_1' */
    DemoModel_B.INPUT_6_1_1[0] = DemoModel_B.CastToDouble1_e;
    DemoModel_B.INPUT_6_1_1[1] = 0.0;
    DemoModel_B.INPUT_6_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_6_1_1_Discrete[0] = !(DemoModel_B.INPUT_6_1_1[0] ==
        DemoModel_DW.INPUT_6_1_1_Discrete[1]);
      DemoModel_DW.INPUT_6_1_1_Discrete[1] = DemoModel_B.INPUT_6_1_1[0];
    }

    DemoModel_B.INPUT_6_1_1[0] = DemoModel_DW.INPUT_6_1_1_Discrete[1];
    DemoModel_B.INPUT_6_1_1[3] = DemoModel_DW.INPUT_6_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_6_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_6_2_1' */
    DemoModel_B.INPUT_6_2_1[0] = DemoModel_B.CastToDouble1_e;
    DemoModel_B.INPUT_6_2_1[1] = 0.0;
    DemoModel_B.INPUT_6_2_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_6_2_1_Discrete[0] = !(DemoModel_B.INPUT_6_2_1[0] ==
        DemoModel_DW.INPUT_6_2_1_Discrete[1]);
      DemoModel_DW.INPUT_6_2_1_Discrete[1] = DemoModel_B.INPUT_6_2_1[0];
    }

    DemoModel_B.INPUT_6_2_1[0] = DemoModel_DW.INPUT_6_2_1_Discrete[1];
    DemoModel_B.INPUT_6_2_1[3] = DemoModel_DW.INPUT_6_2_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_6_2_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_5_1_1' */
    DemoModel_B.INPUT_5_1_1[0] = DemoModel_B.Sum_p;
    DemoModel_B.INPUT_5_1_1[1] = 0.0;
    DemoModel_B.INPUT_5_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_5_1_1_Discrete[0] = !(DemoModel_B.INPUT_5_1_1[0] ==
        DemoModel_DW.INPUT_5_1_1_Discrete[1]);
      DemoModel_DW.INPUT_5_1_1_Discrete[1] = DemoModel_B.INPUT_5_1_1[0];
    }

    DemoModel_B.INPUT_5_1_1[0] = DemoModel_DW.INPUT_5_1_1_Discrete[1];
    DemoModel_B.INPUT_5_1_1[3] = DemoModel_DW.INPUT_5_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_5_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_5_2_1' */
    DemoModel_B.INPUT_5_2_1[0] = DemoModel_B.Sum_p;
    DemoModel_B.INPUT_5_2_1[1] = 0.0;
    DemoModel_B.INPUT_5_2_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_5_2_1_Discrete[0] = !(DemoModel_B.INPUT_5_2_1[0] ==
        DemoModel_DW.INPUT_5_2_1_Discrete[1]);
      DemoModel_DW.INPUT_5_2_1_Discrete[1] = DemoModel_B.INPUT_5_2_1[0];
    }

    DemoModel_B.INPUT_5_2_1[0] = DemoModel_DW.INPUT_5_2_1_Discrete[1];
    DemoModel_B.INPUT_5_2_1[3] = DemoModel_DW.INPUT_5_2_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_5_2_1' */

    /* Sum: '<S72>/Sum' incorporates:
     *  Constant: '<S75>/Constant'
     *  Constant: '<S76>/Constant'
     *  DataTypeConversion: '<S72>/Cast To Double2'
     *  DataTypeConversion: '<S72>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S72>/Memory'
     *  RelationalOperator: '<S75>/Compare'
     *  RelationalOperator: '<S76>/Compare'
     *  Switch: '<S72>/Switch'
     */
    DemoModel_B.Sum_e = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond4 ==
       DemoModel_P.CompareToConstant3_const_i) > DemoModel_P.Switch_Threshold_l))
      && DemoModel_DW.Memory_PreviousInput_pe) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond4 ==
       DemoModel_P.CompareToConstant2_const_n);

    /* DataTypeConversion: '<S72>/Cast To Double1' incorporates:
     *  Logic: '<S72>/NOT'
     */
    DemoModel_B.CastToDouble1_m = !(DemoModel_B.Sum_e != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_8_1_1' */
    DemoModel_B.INPUT_8_1_1[0] = DemoModel_B.CastToDouble1_m;
    DemoModel_B.INPUT_8_1_1[1] = 0.0;
    DemoModel_B.INPUT_8_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_8_1_1_Discrete[0] = !(DemoModel_B.INPUT_8_1_1[0] ==
        DemoModel_DW.INPUT_8_1_1_Discrete[1]);
      DemoModel_DW.INPUT_8_1_1_Discrete[1] = DemoModel_B.INPUT_8_1_1[0];
    }

    DemoModel_B.INPUT_8_1_1[0] = DemoModel_DW.INPUT_8_1_1_Discrete[1];
    DemoModel_B.INPUT_8_1_1[3] = DemoModel_DW.INPUT_8_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_8_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_7_1_1' */
    DemoModel_B.INPUT_7_1_1[0] = DemoModel_B.Sum_e;
    DemoModel_B.INPUT_7_1_1[1] = 0.0;
    DemoModel_B.INPUT_7_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_7_1_1_Discrete[0] = !(DemoModel_B.INPUT_7_1_1[0] ==
        DemoModel_DW.INPUT_7_1_1_Discrete[1]);
      DemoModel_DW.INPUT_7_1_1_Discrete[1] = DemoModel_B.INPUT_7_1_1[0];
    }

    DemoModel_B.INPUT_7_1_1[0] = DemoModel_DW.INPUT_7_1_1_Discrete[1];
    DemoModel_B.INPUT_7_1_1[3] = DemoModel_DW.INPUT_7_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_7_1_1' */

    /* Sum: '<S83>/Sum' incorporates:
     *  Constant: '<S86>/Constant'
     *  Constant: '<S87>/Constant'
     *  DataTypeConversion: '<S83>/Cast To Double2'
     *  DataTypeConversion: '<S83>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S83>/Memory'
     *  RelationalOperator: '<S86>/Compare'
     *  RelationalOperator: '<S87>/Compare'
     *  Switch: '<S83>/Switch'
     */
    DemoModel_B.Sum_m = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond5_12 ==
       DemoModel_P.CompareToConstant3_const_j) > DemoModel_P.Switch_Threshold_o))
      && DemoModel_DW.Memory_PreviousInput_a) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond5_12 ==
       DemoModel_P.CompareToConstant2_const_p2);

    /* DataTypeConversion: '<S83>/Cast To Double1' incorporates:
     *  Logic: '<S83>/NOT'
     */
    DemoModel_B.CastToDouble1_ew = !(DemoModel_B.Sum_m != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_10_1_1' */
    DemoModel_B.INPUT_10_1_1[0] = DemoModel_B.CastToDouble1_ew;
    DemoModel_B.INPUT_10_1_1[1] = 0.0;
    DemoModel_B.INPUT_10_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_10_1_1_Discrete[0] = !(DemoModel_B.INPUT_10_1_1[0] ==
        DemoModel_DW.INPUT_10_1_1_Discrete[1]);
      DemoModel_DW.INPUT_10_1_1_Discrete[1] = DemoModel_B.INPUT_10_1_1[0];
    }

    DemoModel_B.INPUT_10_1_1[0] = DemoModel_DW.INPUT_10_1_1_Discrete[1];
    DemoModel_B.INPUT_10_1_1[3] = DemoModel_DW.INPUT_10_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_10_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_9_1_1' */
    DemoModel_B.INPUT_9_1_1[0] = DemoModel_B.Sum_m;
    DemoModel_B.INPUT_9_1_1[1] = 0.0;
    DemoModel_B.INPUT_9_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_9_1_1_Discrete[0] = !(DemoModel_B.INPUT_9_1_1[0] ==
        DemoModel_DW.INPUT_9_1_1_Discrete[1]);
      DemoModel_DW.INPUT_9_1_1_Discrete[1] = DemoModel_B.INPUT_9_1_1[0];
    }

    DemoModel_B.INPUT_9_1_1[0] = DemoModel_DW.INPUT_9_1_1_Discrete[1];
    DemoModel_B.INPUT_9_1_1[3] = DemoModel_DW.INPUT_9_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_9_1_1' */

    /* Sum: '<S94>/Sum' incorporates:
     *  Constant: '<S97>/Constant'
     *  Constant: '<S98>/Constant'
     *  DataTypeConversion: '<S94>/Cast To Double2'
     *  DataTypeConversion: '<S94>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S94>/Memory'
     *  RelationalOperator: '<S97>/Compare'
     *  RelationalOperator: '<S98>/Compare'
     *  Switch: '<S94>/Switch'
     */
    DemoModel_B.Sum_h = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond5_3 ==
       DemoModel_P.CompareToConstant3_const_en) > DemoModel_P.Switch_Threshold_g))
      && DemoModel_DW.Memory_PreviousInput_d) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond5_3 ==
       DemoModel_P.CompareToConstant2_const_k);

    /* DataTypeConversion: '<S94>/Cast To Double1' incorporates:
     *  Logic: '<S94>/NOT'
     */
    DemoModel_B.CastToDouble1_h = !(DemoModel_B.Sum_h != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_12_1_1' */
    DemoModel_B.INPUT_12_1_1[0] = DemoModel_B.CastToDouble1_h;
    DemoModel_B.INPUT_12_1_1[1] = 0.0;
    DemoModel_B.INPUT_12_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_12_1_1_Discrete[0] = !(DemoModel_B.INPUT_12_1_1[0] ==
        DemoModel_DW.INPUT_12_1_1_Discrete[1]);
      DemoModel_DW.INPUT_12_1_1_Discrete[1] = DemoModel_B.INPUT_12_1_1[0];
    }

    DemoModel_B.INPUT_12_1_1[0] = DemoModel_DW.INPUT_12_1_1_Discrete[1];
    DemoModel_B.INPUT_12_1_1[3] = DemoModel_DW.INPUT_12_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_12_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_11_1_1' */
    DemoModel_B.INPUT_11_1_1[0] = DemoModel_B.Sum_h;
    DemoModel_B.INPUT_11_1_1[1] = 0.0;
    DemoModel_B.INPUT_11_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_11_1_1_Discrete[0] = !(DemoModel_B.INPUT_11_1_1[0] ==
        DemoModel_DW.INPUT_11_1_1_Discrete[1]);
      DemoModel_DW.INPUT_11_1_1_Discrete[1] = DemoModel_B.INPUT_11_1_1[0];
    }

    DemoModel_B.INPUT_11_1_1[0] = DemoModel_DW.INPUT_11_1_1_Discrete[1];
    DemoModel_B.INPUT_11_1_1[3] = DemoModel_DW.INPUT_11_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_11_1_1' */

    /* Sum: '<S105>/Sum' incorporates:
     *  Constant: '<S108>/Constant'
     *  Constant: '<S109>/Constant'
     *  DataTypeConversion: '<S105>/Cast To Double2'
     *  DataTypeConversion: '<S105>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S105>/Memory'
     *  RelationalOperator: '<S108>/Compare'
     *  RelationalOperator: '<S109>/Compare'
     *  Switch: '<S105>/Switch'
     */
    DemoModel_B.Sum_d = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond8 ==
       DemoModel_P.CompareToConstant3_const_c) > DemoModel_P.Switch_Threshold_op))
      && DemoModel_DW.Memory_PreviousInput_pd) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ANDCond8 ==
       DemoModel_P.CompareToConstant2_const_l);

    /* DataTypeConversion: '<S105>/Cast To Double1' incorporates:
     *  Logic: '<S105>/NOT'
     */
    DemoModel_B.CastToDouble1_mt = !(DemoModel_B.Sum_d != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_14_1_1' */
    DemoModel_B.INPUT_14_1_1[0] = DemoModel_B.CastToDouble1_mt;
    DemoModel_B.INPUT_14_1_1[1] = 0.0;
    DemoModel_B.INPUT_14_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_14_1_1_Discrete[0] = !(DemoModel_B.INPUT_14_1_1[0] ==
        DemoModel_DW.INPUT_14_1_1_Discrete[1]);
      DemoModel_DW.INPUT_14_1_1_Discrete[1] = DemoModel_B.INPUT_14_1_1[0];
    }

    DemoModel_B.INPUT_14_1_1[0] = DemoModel_DW.INPUT_14_1_1_Discrete[1];
    DemoModel_B.INPUT_14_1_1[3] = DemoModel_DW.INPUT_14_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_14_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_13_1_1' */
    DemoModel_B.INPUT_13_1_1[0] = DemoModel_B.Sum_d;
    DemoModel_B.INPUT_13_1_1[1] = 0.0;
    DemoModel_B.INPUT_13_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_13_1_1_Discrete[0] = !(DemoModel_B.INPUT_13_1_1[0] ==
        DemoModel_DW.INPUT_13_1_1_Discrete[1]);
      DemoModel_DW.INPUT_13_1_1_Discrete[1] = DemoModel_B.INPUT_13_1_1[0];
    }

    DemoModel_B.INPUT_13_1_1[0] = DemoModel_DW.INPUT_13_1_1_Discrete[1];
    DemoModel_B.INPUT_13_1_1[3] = DemoModel_DW.INPUT_13_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_13_1_1' */

    /* Memory: '<S125>/Memory1' */
    rtb_ORCond2_1 = DemoModel_DW.Memory1_PreviousInput;

    /* DataTypeConversion: '<S125>/Cast To Double2' incorporates:
     *  Constant: '<S128>/Constant'
     *  RelationalOperator: '<S128>/Compare'
     */
    rtb_ORCond2_2 = (rtb_ORCond2_1 == DemoModel_P.CompareToConstant2_const_h);

    /* DataTypeConversion: '<S125>/Cast To Double3' incorporates:
     *  Constant: '<S129>/Constant'
     *  RelationalOperator: '<S129>/Compare'
     */
    rtb_ORCond2_1 = (rtb_ORCond2_1 == DemoModel_P.CompareToConstant3_const_a);

    /* Sum: '<S125>/Sum' incorporates:
     *  Memory: '<S125>/Memory'
     *  Switch: '<S125>/Switch'
     */
    DemoModel_B.Sum_l = static_cast<real_T>((!(rtb_ORCond2_1 >
      DemoModel_P.Switch_Threshold_e)) && DemoModel_DW.Memory_PreviousInput_n) +
      rtb_ORCond2_2;

    /* DataTypeConversion: '<S125>/Cast To Double1' incorporates:
     *  Logic: '<S125>/NOT'
     */
    DemoModel_B.CastToDouble1_c = !(DemoModel_B.Sum_l != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_16_1_1' */
    DemoModel_B.INPUT_16_1_1[0] = DemoModel_B.CastToDouble1_c;
    DemoModel_B.INPUT_16_1_1[1] = 0.0;
    DemoModel_B.INPUT_16_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_16_1_1_Discrete[0] = !(DemoModel_B.INPUT_16_1_1[0] ==
        DemoModel_DW.INPUT_16_1_1_Discrete[1]);
      DemoModel_DW.INPUT_16_1_1_Discrete[1] = DemoModel_B.INPUT_16_1_1[0];
    }

    DemoModel_B.INPUT_16_1_1[0] = DemoModel_DW.INPUT_16_1_1_Discrete[1];
    DemoModel_B.INPUT_16_1_1[3] = DemoModel_DW.INPUT_16_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_16_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_15_1_1' */
    DemoModel_B.INPUT_15_1_1[0] = DemoModel_B.Sum_l;
    DemoModel_B.INPUT_15_1_1[1] = 0.0;
    DemoModel_B.INPUT_15_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_15_1_1_Discrete[0] = !(DemoModel_B.INPUT_15_1_1[0] ==
        DemoModel_DW.INPUT_15_1_1_Discrete[1]);
      DemoModel_DW.INPUT_15_1_1_Discrete[1] = DemoModel_B.INPUT_15_1_1[0];
    }

    DemoModel_B.INPUT_15_1_1[0] = DemoModel_DW.INPUT_15_1_1_Discrete[1];
    DemoModel_B.INPUT_15_1_1[3] = DemoModel_DW.INPUT_15_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_15_1_1' */

    /* Delay: '<S8>/Delay' */
    rtb_ORCond2_1 = DemoModel_DW.Delay_DSTATE;

    /* DataTypeConversion: '<S12>/Cast To Double' incorporates:
     *  Delay: '<S8>/Delay'
     *  Logic: '<S12>/NOT'
     */
    DemoModel_B.CastToDouble = !(DemoModel_DW.Delay_DSTATE != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_17_1_1' */
    DemoModel_B.INPUT_17_1_1[0] = DemoModel_B.CastToDouble;
    DemoModel_B.INPUT_17_1_1[1] = 0.0;
    DemoModel_B.INPUT_17_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_17_1_1_Discrete[0] = !(DemoModel_B.INPUT_17_1_1[0] ==
        DemoModel_DW.INPUT_17_1_1_Discrete[1]);
      DemoModel_DW.INPUT_17_1_1_Discrete[1] = DemoModel_B.INPUT_17_1_1[0];
    }

    DemoModel_B.INPUT_17_1_1[0] = DemoModel_DW.INPUT_17_1_1_Discrete[1];
    DemoModel_B.INPUT_17_1_1[3] = DemoModel_DW.INPUT_17_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_17_1_1' */

    /* Delay: '<S9>/Delay' */
    rtb_ORCond2_2 = DemoModel_DW.Delay_DSTATE_o;

    /* DataTypeConversion: '<S13>/Cast To Double' incorporates:
     *  Delay: '<S9>/Delay'
     *  Logic: '<S13>/NOT'
     */
    DemoModel_B.CastToDouble_b = !(DemoModel_DW.Delay_DSTATE_o != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_18_1_1' */
    DemoModel_B.INPUT_18_1_1[0] = DemoModel_B.CastToDouble_b;
    DemoModel_B.INPUT_18_1_1[1] = 0.0;
    DemoModel_B.INPUT_18_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_18_1_1_Discrete[0] = !(DemoModel_B.INPUT_18_1_1[0] ==
        DemoModel_DW.INPUT_18_1_1_Discrete[1]);
      DemoModel_DW.INPUT_18_1_1_Discrete[1] = DemoModel_B.INPUT_18_1_1[0];
    }

    DemoModel_B.INPUT_18_1_1[0] = DemoModel_DW.INPUT_18_1_1_Discrete[1];
    DemoModel_B.INPUT_18_1_1[3] = DemoModel_DW.INPUT_18_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_18_1_1' */

    /* Delay: '<S10>/Delay' */
    rtb_Delay_p = DemoModel_DW.Delay_DSTATE_c;

    /* DataTypeConversion: '<S14>/Cast To Double' incorporates:
     *  Delay: '<S10>/Delay'
     *  Logic: '<S14>/NOT'
     */
    DemoModel_B.CastToDouble_h = !(DemoModel_DW.Delay_DSTATE_c != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_19_1_1' */
    DemoModel_B.INPUT_19_1_1[0] = DemoModel_B.CastToDouble_h;
    DemoModel_B.INPUT_19_1_1[1] = 0.0;
    DemoModel_B.INPUT_19_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_19_1_1_Discrete[0] = !(DemoModel_B.INPUT_19_1_1[0] ==
        DemoModel_DW.INPUT_19_1_1_Discrete[1]);
      DemoModel_DW.INPUT_19_1_1_Discrete[1] = DemoModel_B.INPUT_19_1_1[0];
    }

    DemoModel_B.INPUT_19_1_1[0] = DemoModel_DW.INPUT_19_1_1_Discrete[1];
    DemoModel_B.INPUT_19_1_1[3] = DemoModel_DW.INPUT_19_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_19_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_20_1_1' incorporates:
     *  Inport: '<Root>/SysCmd'
     */
    DemoModel_B.INPUT_20_1_1[0] = DemoModel_U.SysCmd_i.Master;
    DemoModel_B.INPUT_20_1_1[1] = 0.0;
    DemoModel_B.INPUT_20_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_20_1_1_Discrete[0] = !(DemoModel_B.INPUT_20_1_1[0] ==
        DemoModel_DW.INPUT_20_1_1_Discrete[1]);
      DemoModel_DW.INPUT_20_1_1_Discrete[1] = DemoModel_B.INPUT_20_1_1[0];
    }

    DemoModel_B.INPUT_20_1_1[0] = DemoModel_DW.INPUT_20_1_1_Discrete[1];
    DemoModel_B.INPUT_20_1_1[3] = DemoModel_DW.INPUT_20_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_20_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_20_2_1' incorporates:
     *  Inport: '<Root>/SysCmd'
     */
    DemoModel_B.INPUT_20_2_1[0] = DemoModel_U.SysCmd_i.Master;
    DemoModel_B.INPUT_20_2_1[1] = 0.0;
    DemoModel_B.INPUT_20_2_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_20_2_1_Discrete[0] = !(DemoModel_B.INPUT_20_2_1[0] ==
        DemoModel_DW.INPUT_20_2_1_Discrete[1]);
      DemoModel_DW.INPUT_20_2_1_Discrete[1] = DemoModel_B.INPUT_20_2_1[0];
    }

    DemoModel_B.INPUT_20_2_1[0] = DemoModel_DW.INPUT_20_2_1_Discrete[1];
    DemoModel_B.INPUT_20_2_1[3] = DemoModel_DW.INPUT_20_2_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_20_2_1' */

    /* Sum: '<S153>/Sum' incorporates:
     *  Constant: '<S156>/Constant'
     *  Constant: '<S157>/Constant'
     *  DataTypeConversion: '<S153>/Cast To Double2'
     *  DataTypeConversion: '<S153>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S153>/Memory'
     *  RelationalOperator: '<S156>/Compare'
     *  RelationalOperator: '<S157>/Compare'
     *  Switch: '<S153>/Switch'
     */
    DemoModel_B.Sum_ec = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ORCond2_1 ==
       DemoModel_P.CompareToConstant3_const_io) > DemoModel_P.Switch_Threshold_m))
      && DemoModel_DW.Memory_PreviousInput_px) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ORCond2_1 ==
       DemoModel_P.CompareToConstant2_const_o);

    /* DataTypeConversion: '<S153>/Cast To Double1' incorporates:
     *  Logic: '<S153>/NOT'
     */
    DemoModel_B.CastToDouble1_oj = !(DemoModel_B.Sum_ec != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_22_1_1' */
    DemoModel_B.INPUT_22_1_1[0] = DemoModel_B.CastToDouble1_oj;
    DemoModel_B.INPUT_22_1_1[1] = 0.0;
    DemoModel_B.INPUT_22_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_22_1_1_Discrete[0] = !(DemoModel_B.INPUT_22_1_1[0] ==
        DemoModel_DW.INPUT_22_1_1_Discrete[1]);
      DemoModel_DW.INPUT_22_1_1_Discrete[1] = DemoModel_B.INPUT_22_1_1[0];
    }

    DemoModel_B.INPUT_22_1_1[0] = DemoModel_DW.INPUT_22_1_1_Discrete[1];
    DemoModel_B.INPUT_22_1_1[3] = DemoModel_DW.INPUT_22_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_22_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_21_1_1' */
    DemoModel_B.INPUT_21_1_1[0] = DemoModel_B.Sum_ec;
    DemoModel_B.INPUT_21_1_1[1] = 0.0;
    DemoModel_B.INPUT_21_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_21_1_1_Discrete[0] = !(DemoModel_B.INPUT_21_1_1[0] ==
        DemoModel_DW.INPUT_21_1_1_Discrete[1]);
      DemoModel_DW.INPUT_21_1_1_Discrete[1] = DemoModel_B.INPUT_21_1_1[0];
    }

    DemoModel_B.INPUT_21_1_1[0] = DemoModel_DW.INPUT_21_1_1_Discrete[1];
    DemoModel_B.INPUT_21_1_1[3] = DemoModel_DW.INPUT_21_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_21_1_1' */

    /* Sum: '<S164>/Sum' incorporates:
     *  Constant: '<S167>/Constant'
     *  Constant: '<S168>/Constant'
     *  DataTypeConversion: '<S164>/Cast To Double2'
     *  DataTypeConversion: '<S164>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S164>/Memory'
     *  RelationalOperator: '<S167>/Compare'
     *  RelationalOperator: '<S168>/Compare'
     *  Switch: '<S164>/Switch'
     */
    DemoModel_B.Sum_pp = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ORCond2_2 ==
       DemoModel_P.CompareToConstant3_const_p) > DemoModel_P.Switch_Threshold_o0))
      && DemoModel_DW.Memory_PreviousInput_e) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ORCond2_2 ==
       DemoModel_P.CompareToConstant2_const_nq);

    /* DataTypeConversion: '<S164>/Cast To Double1' incorporates:
     *  Logic: '<S164>/NOT'
     */
    DemoModel_B.CastToDouble1_k = !(DemoModel_B.Sum_pp != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_24_1_1' */
    DemoModel_B.INPUT_24_1_1[0] = DemoModel_B.CastToDouble1_k;
    DemoModel_B.INPUT_24_1_1[1] = 0.0;
    DemoModel_B.INPUT_24_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_24_1_1_Discrete[0] = !(DemoModel_B.INPUT_24_1_1[0] ==
        DemoModel_DW.INPUT_24_1_1_Discrete[1]);
      DemoModel_DW.INPUT_24_1_1_Discrete[1] = DemoModel_B.INPUT_24_1_1[0];
    }

    DemoModel_B.INPUT_24_1_1[0] = DemoModel_DW.INPUT_24_1_1_Discrete[1];
    DemoModel_B.INPUT_24_1_1[3] = DemoModel_DW.INPUT_24_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_24_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_24_2_1' */
    DemoModel_B.INPUT_24_2_1[0] = DemoModel_B.CastToDouble1_k;
    DemoModel_B.INPUT_24_2_1[1] = 0.0;
    DemoModel_B.INPUT_24_2_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_24_2_1_Discrete[0] = !(DemoModel_B.INPUT_24_2_1[0] ==
        DemoModel_DW.INPUT_24_2_1_Discrete[1]);
      DemoModel_DW.INPUT_24_2_1_Discrete[1] = DemoModel_B.INPUT_24_2_1[0];
    }

    DemoModel_B.INPUT_24_2_1[0] = DemoModel_DW.INPUT_24_2_1_Discrete[1];
    DemoModel_B.INPUT_24_2_1[3] = DemoModel_DW.INPUT_24_2_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_24_2_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_23_1_1' */
    DemoModel_B.INPUT_23_1_1[0] = DemoModel_B.Sum_pp;
    DemoModel_B.INPUT_23_1_1[1] = 0.0;
    DemoModel_B.INPUT_23_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_23_1_1_Discrete[0] = !(DemoModel_B.INPUT_23_1_1[0] ==
        DemoModel_DW.INPUT_23_1_1_Discrete[1]);
      DemoModel_DW.INPUT_23_1_1_Discrete[1] = DemoModel_B.INPUT_23_1_1[0];
    }

    DemoModel_B.INPUT_23_1_1[0] = DemoModel_DW.INPUT_23_1_1_Discrete[1];
    DemoModel_B.INPUT_23_1_1[3] = DemoModel_DW.INPUT_23_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_23_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_23_2_1' */
    DemoModel_B.INPUT_23_2_1[0] = DemoModel_B.Sum_pp;
    DemoModel_B.INPUT_23_2_1[1] = 0.0;
    DemoModel_B.INPUT_23_2_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_23_2_1_Discrete[0] = !(DemoModel_B.INPUT_23_2_1[0] ==
        DemoModel_DW.INPUT_23_2_1_Discrete[1]);
      DemoModel_DW.INPUT_23_2_1_Discrete[1] = DemoModel_B.INPUT_23_2_1[0];
    }

    DemoModel_B.INPUT_23_2_1[0] = DemoModel_DW.INPUT_23_2_1_Discrete[1];
    DemoModel_B.INPUT_23_2_1[3] = DemoModel_DW.INPUT_23_2_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_23_2_1' */

    /* Sum: '<S175>/Sum' incorporates:
     *  Constant: '<S178>/Constant'
     *  Constant: '<S179>/Constant'
     *  DataTypeConversion: '<S175>/Cast To Double2'
     *  DataTypeConversion: '<S175>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S175>/Memory'
     *  RelationalOperator: '<S178>/Compare'
     *  RelationalOperator: '<S179>/Compare'
     *  Switch: '<S175>/Switch'
     */
    DemoModel_B.Sum_i = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ORCond7_1 ==
       DemoModel_P.CompareToConstant3_const_o) > DemoModel_P.Switch_Threshold_ad))
      && DemoModel_DW.Memory_PreviousInput_j) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ORCond7_1 ==
       DemoModel_P.CompareToConstant2_const_i);

    /* DataTypeConversion: '<S175>/Cast To Double1' incorporates:
     *  Logic: '<S175>/NOT'
     */
    DemoModel_B.CastToDouble1_hk = !(DemoModel_B.Sum_i != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_26_1_1' */
    DemoModel_B.INPUT_26_1_1[0] = DemoModel_B.CastToDouble1_hk;
    DemoModel_B.INPUT_26_1_1[1] = 0.0;
    DemoModel_B.INPUT_26_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_26_1_1_Discrete[0] = !(DemoModel_B.INPUT_26_1_1[0] ==
        DemoModel_DW.INPUT_26_1_1_Discrete[1]);
      DemoModel_DW.INPUT_26_1_1_Discrete[1] = DemoModel_B.INPUT_26_1_1[0];
    }

    DemoModel_B.INPUT_26_1_1[0] = DemoModel_DW.INPUT_26_1_1_Discrete[1];
    DemoModel_B.INPUT_26_1_1[3] = DemoModel_DW.INPUT_26_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_26_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_25_1_1' */
    DemoModel_B.INPUT_25_1_1[0] = DemoModel_B.Sum_i;
    DemoModel_B.INPUT_25_1_1[1] = 0.0;
    DemoModel_B.INPUT_25_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_25_1_1_Discrete[0] = !(DemoModel_B.INPUT_25_1_1[0] ==
        DemoModel_DW.INPUT_25_1_1_Discrete[1]);
      DemoModel_DW.INPUT_25_1_1_Discrete[1] = DemoModel_B.INPUT_25_1_1[0];
    }

    DemoModel_B.INPUT_25_1_1[0] = DemoModel_DW.INPUT_25_1_1_Discrete[1];
    DemoModel_B.INPUT_25_1_1[3] = DemoModel_DW.INPUT_25_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_25_1_1' */

    /* Sum: '<S186>/Sum' incorporates:
     *  Constant: '<S189>/Constant'
     *  Constant: '<S190>/Constant'
     *  DataTypeConversion: '<S186>/Cast To Double2'
     *  DataTypeConversion: '<S186>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S186>/Memory'
     *  RelationalOperator: '<S189>/Compare'
     *  RelationalOperator: '<S190>/Compare'
     *  Switch: '<S186>/Switch'
     */
    DemoModel_B.Sum_lw = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ORCond7_2 ==
       DemoModel_P.CompareToConstant3_const_g) > DemoModel_P.Switch_Threshold_k))
      && DemoModel_DW.Memory_PreviousInput_nm) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.ORCond7_2 ==
       DemoModel_P.CompareToConstant2_const_kk);

    /* DataTypeConversion: '<S186>/Cast To Double1' incorporates:
     *  Logic: '<S186>/NOT'
     */
    DemoModel_B.CastToDouble1_em = !(DemoModel_B.Sum_lw != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_28_1_1' */
    DemoModel_B.INPUT_28_1_1[0] = DemoModel_B.CastToDouble1_em;
    DemoModel_B.INPUT_28_1_1[1] = 0.0;
    DemoModel_B.INPUT_28_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_28_1_1_Discrete[0] = !(DemoModel_B.INPUT_28_1_1[0] ==
        DemoModel_DW.INPUT_28_1_1_Discrete[1]);
      DemoModel_DW.INPUT_28_1_1_Discrete[1] = DemoModel_B.INPUT_28_1_1[0];
    }

    DemoModel_B.INPUT_28_1_1[0] = DemoModel_DW.INPUT_28_1_1_Discrete[1];
    DemoModel_B.INPUT_28_1_1[3] = DemoModel_DW.INPUT_28_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_28_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_27_1_1' */
    DemoModel_B.INPUT_27_1_1[0] = DemoModel_B.Sum_lw;
    DemoModel_B.INPUT_27_1_1[1] = 0.0;
    DemoModel_B.INPUT_27_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_27_1_1_Discrete[0] = !(DemoModel_B.INPUT_27_1_1[0] ==
        DemoModel_DW.INPUT_27_1_1_Discrete[1]);
      DemoModel_DW.INPUT_27_1_1_Discrete[1] = DemoModel_B.INPUT_27_1_1[0];
    }

    DemoModel_B.INPUT_27_1_1[0] = DemoModel_DW.INPUT_27_1_1_Discrete[1];
    DemoModel_B.INPUT_27_1_1[3] = DemoModel_DW.INPUT_27_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_27_1_1' */

    /* Sum: '<S197>/Sum' incorporates:
     *  Constant: '<S200>/Constant'
     *  Constant: '<S201>/Constant'
     *  DataTypeConversion: '<S197>/Cast To Double2'
     *  DataTypeConversion: '<S197>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S197>/Memory'
     *  RelationalOperator: '<S200>/Compare'
     *  RelationalOperator: '<S201>/Compare'
     *  Switch: '<S197>/Switch'
     */
    DemoModel_B.Sum_dl = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.PrimFailCond ==
       DemoModel_P.CompareToConstant3_const_ca) > DemoModel_P.Switch_Threshold_f))
      && DemoModel_DW.Memory_PreviousInput_jl) + static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.PrimFailCond ==
       DemoModel_P.CompareToConstant2_const_in);

    /* DataTypeConversion: '<S197>/Cast To Double1' incorporates:
     *  Logic: '<S197>/NOT'
     */
    DemoModel_B.CastToDouble1_d = !(DemoModel_B.Sum_dl != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_30_1_1' */
    DemoModel_B.INPUT_30_1_1[0] = DemoModel_B.CastToDouble1_d;
    DemoModel_B.INPUT_30_1_1[1] = 0.0;
    DemoModel_B.INPUT_30_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_30_1_1_Discrete[0] = !(DemoModel_B.INPUT_30_1_1[0] ==
        DemoModel_DW.INPUT_30_1_1_Discrete[1]);
      DemoModel_DW.INPUT_30_1_1_Discrete[1] = DemoModel_B.INPUT_30_1_1[0];
    }

    DemoModel_B.INPUT_30_1_1[0] = DemoModel_DW.INPUT_30_1_1_Discrete[1];
    DemoModel_B.INPUT_30_1_1[3] = DemoModel_DW.INPUT_30_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_30_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_29_1_1' */
    DemoModel_B.INPUT_29_1_1[0] = DemoModel_B.Sum_dl;
    DemoModel_B.INPUT_29_1_1[1] = 0.0;
    DemoModel_B.INPUT_29_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_29_1_1_Discrete[0] = !(DemoModel_B.INPUT_29_1_1[0] ==
        DemoModel_DW.INPUT_29_1_1_Discrete[1]);
      DemoModel_DW.INPUT_29_1_1_Discrete[1] = DemoModel_B.INPUT_29_1_1[0];
    }

    DemoModel_B.INPUT_29_1_1[0] = DemoModel_DW.INPUT_29_1_1_Discrete[1];
    DemoModel_B.INPUT_29_1_1[3] = DemoModel_DW.INPUT_29_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_29_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_31_1_1' incorporates:
     *  Inport: '<Root>/SysCmd'
     */
    DemoModel_B.INPUT_31_1_1[0] = DemoModel_U.SysCmd_i.PrimPwrSupply;
    DemoModel_B.INPUT_31_1_1[1] = 0.0;
    DemoModel_B.INPUT_31_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_31_1_1_Discrete[0] = !(DemoModel_B.INPUT_31_1_1[0] ==
        DemoModel_DW.INPUT_31_1_1_Discrete[1]);
      DemoModel_DW.INPUT_31_1_1_Discrete[1] = DemoModel_B.INPUT_31_1_1[0];
    }

    DemoModel_B.INPUT_31_1_1[0] = DemoModel_DW.INPUT_31_1_1_Discrete[1];
    DemoModel_B.INPUT_31_1_1[3] = DemoModel_DW.INPUT_31_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_31_1_1' */

    /* Sum: '<S210>/Sum' incorporates:
     *  Constant: '<S213>/Constant'
     *  Constant: '<S214>/Constant'
     *  DataTypeConversion: '<S210>/Cast To Double2'
     *  DataTypeConversion: '<S210>/Cast To Double3'
     *  Inport: '<Root>/RelayFailCmd'
     *  Memory: '<S210>/Memory'
     *  RelationalOperator: '<S213>/Compare'
     *  RelationalOperator: '<S214>/Compare'
     *  Switch: '<S210>/Switch'
     */
    DemoModel_B.Sum_o = static_cast<real_T>((!(static_cast<real_T>
      (DemoModel_U.RelayFailCmd_i.SecFailCond ==
       DemoModel_P.CompareToConstant3_const_em) >
      DemoModel_P.Switch_Threshold_ko)) && DemoModel_DW.Memory_PreviousInput_c)
      + static_cast<real_T>(DemoModel_U.RelayFailCmd_i.SecFailCond ==
      DemoModel_P.CompareToConstant2_const_m);

    /* DataTypeConversion: '<S210>/Cast To Double1' incorporates:
     *  Logic: '<S210>/NOT'
     */
    DemoModel_B.CastToDouble1_b = !(DemoModel_B.Sum_o != 0.0);

    /* SimscapeInputBlock: '<S223>/INPUT_33_1_1' */
    DemoModel_B.INPUT_33_1_1[0] = DemoModel_B.CastToDouble1_b;
    DemoModel_B.INPUT_33_1_1[1] = 0.0;
    DemoModel_B.INPUT_33_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_33_1_1_Discrete[0] = !(DemoModel_B.INPUT_33_1_1[0] ==
        DemoModel_DW.INPUT_33_1_1_Discrete[1]);
      DemoModel_DW.INPUT_33_1_1_Discrete[1] = DemoModel_B.INPUT_33_1_1[0];
    }

    DemoModel_B.INPUT_33_1_1[0] = DemoModel_DW.INPUT_33_1_1_Discrete[1];
    DemoModel_B.INPUT_33_1_1[3] = DemoModel_DW.INPUT_33_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_33_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_32_1_1' */
    DemoModel_B.INPUT_32_1_1[0] = DemoModel_B.Sum_o;
    DemoModel_B.INPUT_32_1_1[1] = 0.0;
    DemoModel_B.INPUT_32_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_32_1_1_Discrete[0] = !(DemoModel_B.INPUT_32_1_1[0] ==
        DemoModel_DW.INPUT_32_1_1_Discrete[1]);
      DemoModel_DW.INPUT_32_1_1_Discrete[1] = DemoModel_B.INPUT_32_1_1[0];
    }

    DemoModel_B.INPUT_32_1_1[0] = DemoModel_DW.INPUT_32_1_1_Discrete[1];
    DemoModel_B.INPUT_32_1_1[3] = DemoModel_DW.INPUT_32_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_32_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_34_1_1' incorporates:
     *  Inport: '<Root>/SysCmd'
     */
    DemoModel_B.INPUT_34_1_1[0] = DemoModel_U.SysCmd_i.SecPwrSupply;
    DemoModel_B.INPUT_34_1_1[1] = 0.0;
    DemoModel_B.INPUT_34_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_34_1_1_Discrete[0] = !(DemoModel_B.INPUT_34_1_1[0] ==
        DemoModel_DW.INPUT_34_1_1_Discrete[1]);
      DemoModel_DW.INPUT_34_1_1_Discrete[1] = DemoModel_B.INPUT_34_1_1[0];
    }

    DemoModel_B.INPUT_34_1_1[0] = DemoModel_DW.INPUT_34_1_1_Discrete[1];
    DemoModel_B.INPUT_34_1_1[3] = DemoModel_DW.INPUT_34_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_34_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_35_1_1' incorporates:
     *  Inport: '<Root>/SysFailCmd'
     */
    DemoModel_B.INPUT_35_1_1[0] = DemoModel_U.SysFailCmd_l.OverHeat28;
    DemoModel_B.INPUT_35_1_1[1] = 0.0;
    DemoModel_B.INPUT_35_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_35_1_1_Discrete[0] = !(DemoModel_B.INPUT_35_1_1[0] ==
        DemoModel_DW.INPUT_35_1_1_Discrete[1]);
      DemoModel_DW.INPUT_35_1_1_Discrete[1] = DemoModel_B.INPUT_35_1_1[0];
    }

    DemoModel_B.INPUT_35_1_1[0] = DemoModel_DW.INPUT_35_1_1_Discrete[1];
    DemoModel_B.INPUT_35_1_1[3] = DemoModel_DW.INPUT_35_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_35_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_36_1_1' incorporates:
     *  Inport: '<Root>/SysFailCmd'
     */
    DemoModel_B.INPUT_36_1_1[0] = DemoModel_U.SysFailCmd_l.OverHeat28;
    DemoModel_B.INPUT_36_1_1[1] = 0.0;
    DemoModel_B.INPUT_36_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_36_1_1_Discrete[0] = !(DemoModel_B.INPUT_36_1_1[0] ==
        DemoModel_DW.INPUT_36_1_1_Discrete[1]);
      DemoModel_DW.INPUT_36_1_1_Discrete[1] = DemoModel_B.INPUT_36_1_1[0];
    }

    DemoModel_B.INPUT_36_1_1[0] = DemoModel_DW.INPUT_36_1_1_Discrete[1];
    DemoModel_B.INPUT_36_1_1[3] = DemoModel_DW.INPUT_36_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_36_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_37_1_1' incorporates:
     *  Inport: '<Root>/SysFailCmd'
     */
    DemoModel_B.INPUT_37_1_1[0] = DemoModel_U.SysFailCmd_l.OverHeat26;
    DemoModel_B.INPUT_37_1_1[1] = 0.0;
    DemoModel_B.INPUT_37_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_37_1_1_Discrete[0] = !(DemoModel_B.INPUT_37_1_1[0] ==
        DemoModel_DW.INPUT_37_1_1_Discrete[1]);
      DemoModel_DW.INPUT_37_1_1_Discrete[1] = DemoModel_B.INPUT_37_1_1[0];
    }

    DemoModel_B.INPUT_37_1_1[0] = DemoModel_DW.INPUT_37_1_1_Discrete[1];
    DemoModel_B.INPUT_37_1_1[3] = DemoModel_DW.INPUT_37_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_37_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_38_1_1' incorporates:
     *  Inport: '<Root>/SysFailCmd'
     */
    DemoModel_B.INPUT_38_1_1[0] = DemoModel_U.SysFailCmd_l.OverHeat28;
    DemoModel_B.INPUT_38_1_1[1] = 0.0;
    DemoModel_B.INPUT_38_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_38_1_1_Discrete[0] = !(DemoModel_B.INPUT_38_1_1[0] ==
        DemoModel_DW.INPUT_38_1_1_Discrete[1]);
      DemoModel_DW.INPUT_38_1_1_Discrete[1] = DemoModel_B.INPUT_38_1_1[0];
    }

    DemoModel_B.INPUT_38_1_1[0] = DemoModel_DW.INPUT_38_1_1_Discrete[1];
    DemoModel_B.INPUT_38_1_1[3] = DemoModel_DW.INPUT_38_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_38_1_1' */

    /* SimscapeInputBlock: '<S223>/INPUT_39_1_1' incorporates:
     *  Inport: '<Root>/SysFailCmd'
     */
    DemoModel_B.INPUT_39_1_1[0] = DemoModel_U.SysFailCmd_l.OverHeat26;
    DemoModel_B.INPUT_39_1_1[1] = 0.0;
    DemoModel_B.INPUT_39_1_1[2] = 0.0;
    if (rtmIsMajorTimeStep(DemoModel_M)) {
      DemoModel_DW.INPUT_39_1_1_Discrete[0] = !(DemoModel_B.INPUT_39_1_1[0] ==
        DemoModel_DW.INPUT_39_1_1_Discrete[1]);
      DemoModel_DW.INPUT_39_1_1_Discrete[1] = DemoModel_B.INPUT_39_1_1[0];
    }

    DemoModel_B.INPUT_39_1_1[0] = DemoModel_DW.INPUT_39_1_1_Discrete[1];
    DemoModel_B.INPUT_39_1_1[3] = DemoModel_DW.INPUT_39_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S223>/INPUT_39_1_1' */

    /* SimscapeExecutionBlock: '<S223>/STATE_1' incorporates:
     *  SimscapeExecutionBlock: '<S223>/OUTPUT_1_0'
     */
    simulationData = (NeslSimulationData *)DemoModel_DW.STATE_1_SimData;
    time_tmp = DemoModel_M->Timing.t[0];
    time = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 92;
    simulationData->mData->mDiscStates.mX = &DemoModel_DW.STATE_1_Discrete[0];
    simulationData->mData->mModeVector.mN = 46;
    simulationData->mData->mModeVector.mX = &DemoModel_DW.STATE_1_Modes[0];
    rtb_Compare_g = false;
    simulationData->mData->mFoundZcEvents = rtb_Compare_g;
    rtb_Compare_g = rtmIsMajorTimeStep(DemoModel_M);
    simulationData->mData->mIsMajorTimeStep = rtb_Compare_g;
    rtb_Compare = false;
    simulationData->mData->mIsSolverAssertCheck = rtb_Compare;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_0[0] = 0;
    tmp[0] = DemoModel_B.INPUT_2_1_1[0];
    tmp[1] = DemoModel_B.INPUT_2_1_1[1];
    tmp[2] = DemoModel_B.INPUT_2_1_1[2];
    tmp[3] = DemoModel_B.INPUT_2_1_1[3];
    tmp_0[1] = 4;
    tmp[4] = DemoModel_B.INPUT_2_2_1[0];
    tmp[5] = DemoModel_B.INPUT_2_2_1[1];
    tmp[6] = DemoModel_B.INPUT_2_2_1[2];
    tmp[7] = DemoModel_B.INPUT_2_2_1[3];
    tmp_0[2] = 8;
    tmp[8] = DemoModel_B.INPUT_1_1_1[0];
    tmp[9] = DemoModel_B.INPUT_1_1_1[1];
    tmp[10] = DemoModel_B.INPUT_1_1_1[2];
    tmp[11] = DemoModel_B.INPUT_1_1_1[3];
    tmp_0[3] = 12;
    tmp[12] = DemoModel_B.INPUT_1_2_1[0];
    tmp[13] = DemoModel_B.INPUT_1_2_1[1];
    tmp[14] = DemoModel_B.INPUT_1_2_1[2];
    tmp[15] = DemoModel_B.INPUT_1_2_1[3];
    tmp_0[4] = 16;
    tmp[16] = DemoModel_B.INPUT_4_1_1[0];
    tmp[17] = DemoModel_B.INPUT_4_1_1[1];
    tmp[18] = DemoModel_B.INPUT_4_1_1[2];
    tmp[19] = DemoModel_B.INPUT_4_1_1[3];
    tmp_0[5] = 20;
    tmp[20] = DemoModel_B.INPUT_3_1_1[0];
    tmp[21] = DemoModel_B.INPUT_3_1_1[1];
    tmp[22] = DemoModel_B.INPUT_3_1_1[2];
    tmp[23] = DemoModel_B.INPUT_3_1_1[3];
    tmp_0[6] = 24;
    tmp[24] = DemoModel_B.INPUT_6_1_1[0];
    tmp[25] = DemoModel_B.INPUT_6_1_1[1];
    tmp[26] = DemoModel_B.INPUT_6_1_1[2];
    tmp[27] = DemoModel_B.INPUT_6_1_1[3];
    tmp_0[7] = 28;
    tmp[28] = DemoModel_B.INPUT_6_2_1[0];
    tmp[29] = DemoModel_B.INPUT_6_2_1[1];
    tmp[30] = DemoModel_B.INPUT_6_2_1[2];
    tmp[31] = DemoModel_B.INPUT_6_2_1[3];
    tmp_0[8] = 32;
    tmp[32] = DemoModel_B.INPUT_5_1_1[0];
    tmp[33] = DemoModel_B.INPUT_5_1_1[1];
    tmp[34] = DemoModel_B.INPUT_5_1_1[2];
    tmp[35] = DemoModel_B.INPUT_5_1_1[3];
    tmp_0[9] = 36;
    tmp[36] = DemoModel_B.INPUT_5_2_1[0];
    tmp[37] = DemoModel_B.INPUT_5_2_1[1];
    tmp[38] = DemoModel_B.INPUT_5_2_1[2];
    tmp[39] = DemoModel_B.INPUT_5_2_1[3];
    tmp_0[10] = 40;
    tmp[40] = DemoModel_B.INPUT_8_1_1[0];
    tmp[41] = DemoModel_B.INPUT_8_1_1[1];
    tmp[42] = DemoModel_B.INPUT_8_1_1[2];
    tmp[43] = DemoModel_B.INPUT_8_1_1[3];
    tmp_0[11] = 44;
    tmp[44] = DemoModel_B.INPUT_7_1_1[0];
    tmp[45] = DemoModel_B.INPUT_7_1_1[1];
    tmp[46] = DemoModel_B.INPUT_7_1_1[2];
    tmp[47] = DemoModel_B.INPUT_7_1_1[3];
    tmp_0[12] = 48;
    tmp[48] = DemoModel_B.INPUT_10_1_1[0];
    tmp[49] = DemoModel_B.INPUT_10_1_1[1];
    tmp[50] = DemoModel_B.INPUT_10_1_1[2];
    tmp[51] = DemoModel_B.INPUT_10_1_1[3];
    tmp_0[13] = 52;
    tmp[52] = DemoModel_B.INPUT_9_1_1[0];
    tmp[53] = DemoModel_B.INPUT_9_1_1[1];
    tmp[54] = DemoModel_B.INPUT_9_1_1[2];
    tmp[55] = DemoModel_B.INPUT_9_1_1[3];
    tmp_0[14] = 56;
    tmp[56] = DemoModel_B.INPUT_12_1_1[0];
    tmp[57] = DemoModel_B.INPUT_12_1_1[1];
    tmp[58] = DemoModel_B.INPUT_12_1_1[2];
    tmp[59] = DemoModel_B.INPUT_12_1_1[3];
    tmp_0[15] = 60;
    tmp[60] = DemoModel_B.INPUT_11_1_1[0];
    tmp[61] = DemoModel_B.INPUT_11_1_1[1];
    tmp[62] = DemoModel_B.INPUT_11_1_1[2];
    tmp[63] = DemoModel_B.INPUT_11_1_1[3];
    tmp_0[16] = 64;
    tmp[64] = DemoModel_B.INPUT_14_1_1[0];
    tmp[65] = DemoModel_B.INPUT_14_1_1[1];
    tmp[66] = DemoModel_B.INPUT_14_1_1[2];
    tmp[67] = DemoModel_B.INPUT_14_1_1[3];
    tmp_0[17] = 68;
    tmp[68] = DemoModel_B.INPUT_13_1_1[0];
    tmp[69] = DemoModel_B.INPUT_13_1_1[1];
    tmp[70] = DemoModel_B.INPUT_13_1_1[2];
    tmp[71] = DemoModel_B.INPUT_13_1_1[3];
    tmp_0[18] = 72;
    tmp[72] = DemoModel_B.INPUT_16_1_1[0];
    tmp[73] = DemoModel_B.INPUT_16_1_1[1];
    tmp[74] = DemoModel_B.INPUT_16_1_1[2];
    tmp[75] = DemoModel_B.INPUT_16_1_1[3];
    tmp_0[19] = 76;
    tmp[76] = DemoModel_B.INPUT_15_1_1[0];
    tmp[77] = DemoModel_B.INPUT_15_1_1[1];
    tmp[78] = DemoModel_B.INPUT_15_1_1[2];
    tmp[79] = DemoModel_B.INPUT_15_1_1[3];
    tmp_0[20] = 80;
    tmp[80] = DemoModel_B.INPUT_17_1_1[0];
    tmp[81] = DemoModel_B.INPUT_17_1_1[1];
    tmp[82] = DemoModel_B.INPUT_17_1_1[2];
    tmp[83] = DemoModel_B.INPUT_17_1_1[3];
    tmp_0[21] = 84;
    tmp[84] = DemoModel_B.INPUT_18_1_1[0];
    tmp[85] = DemoModel_B.INPUT_18_1_1[1];
    tmp[86] = DemoModel_B.INPUT_18_1_1[2];
    tmp[87] = DemoModel_B.INPUT_18_1_1[3];
    tmp_0[22] = 88;
    tmp[88] = DemoModel_B.INPUT_19_1_1[0];
    tmp[89] = DemoModel_B.INPUT_19_1_1[1];
    tmp[90] = DemoModel_B.INPUT_19_1_1[2];
    tmp[91] = DemoModel_B.INPUT_19_1_1[3];
    tmp_0[23] = 92;
    tmp[92] = DemoModel_B.INPUT_20_1_1[0];
    tmp[93] = DemoModel_B.INPUT_20_1_1[1];
    tmp[94] = DemoModel_B.INPUT_20_1_1[2];
    tmp[95] = DemoModel_B.INPUT_20_1_1[3];
    tmp_0[24] = 96;
    tmp[96] = DemoModel_B.INPUT_20_2_1[0];
    tmp[97] = DemoModel_B.INPUT_20_2_1[1];
    tmp[98] = DemoModel_B.INPUT_20_2_1[2];
    tmp[99] = DemoModel_B.INPUT_20_2_1[3];
    tmp_0[25] = 100;
    tmp[100] = DemoModel_B.INPUT_22_1_1[0];
    tmp[101] = DemoModel_B.INPUT_22_1_1[1];
    tmp[102] = DemoModel_B.INPUT_22_1_1[2];
    tmp[103] = DemoModel_B.INPUT_22_1_1[3];
    tmp_0[26] = 104;
    tmp[104] = DemoModel_B.INPUT_21_1_1[0];
    tmp[105] = DemoModel_B.INPUT_21_1_1[1];
    tmp[106] = DemoModel_B.INPUT_21_1_1[2];
    tmp[107] = DemoModel_B.INPUT_21_1_1[3];
    tmp_0[27] = 108;
    tmp[108] = DemoModel_B.INPUT_24_1_1[0];
    tmp[109] = DemoModel_B.INPUT_24_1_1[1];
    tmp[110] = DemoModel_B.INPUT_24_1_1[2];
    tmp[111] = DemoModel_B.INPUT_24_1_1[3];
    tmp_0[28] = 112;
    tmp[112] = DemoModel_B.INPUT_24_2_1[0];
    tmp[113] = DemoModel_B.INPUT_24_2_1[1];
    tmp[114] = DemoModel_B.INPUT_24_2_1[2];
    tmp[115] = DemoModel_B.INPUT_24_2_1[3];
    tmp_0[29] = 116;
    tmp[116] = DemoModel_B.INPUT_23_1_1[0];
    tmp[117] = DemoModel_B.INPUT_23_1_1[1];
    tmp[118] = DemoModel_B.INPUT_23_1_1[2];
    tmp[119] = DemoModel_B.INPUT_23_1_1[3];
    tmp_0[30] = 120;
    tmp[120] = DemoModel_B.INPUT_23_2_1[0];
    tmp[121] = DemoModel_B.INPUT_23_2_1[1];
    tmp[122] = DemoModel_B.INPUT_23_2_1[2];
    tmp[123] = DemoModel_B.INPUT_23_2_1[3];
    tmp_0[31] = 124;
    tmp[124] = DemoModel_B.INPUT_26_1_1[0];
    tmp[125] = DemoModel_B.INPUT_26_1_1[1];
    tmp[126] = DemoModel_B.INPUT_26_1_1[2];
    tmp[127] = DemoModel_B.INPUT_26_1_1[3];
    tmp_0[32] = 128;
    tmp[128] = DemoModel_B.INPUT_25_1_1[0];
    tmp[129] = DemoModel_B.INPUT_25_1_1[1];
    tmp[130] = DemoModel_B.INPUT_25_1_1[2];
    tmp[131] = DemoModel_B.INPUT_25_1_1[3];
    tmp_0[33] = 132;
    tmp[132] = DemoModel_B.INPUT_28_1_1[0];
    tmp[133] = DemoModel_B.INPUT_28_1_1[1];
    tmp[134] = DemoModel_B.INPUT_28_1_1[2];
    tmp[135] = DemoModel_B.INPUT_28_1_1[3];
    tmp_0[34] = 136;
    tmp[136] = DemoModel_B.INPUT_27_1_1[0];
    tmp[137] = DemoModel_B.INPUT_27_1_1[1];
    tmp[138] = DemoModel_B.INPUT_27_1_1[2];
    tmp[139] = DemoModel_B.INPUT_27_1_1[3];
    tmp_0[35] = 140;
    tmp[140] = DemoModel_B.INPUT_30_1_1[0];
    tmp[141] = DemoModel_B.INPUT_30_1_1[1];
    tmp[142] = DemoModel_B.INPUT_30_1_1[2];
    tmp[143] = DemoModel_B.INPUT_30_1_1[3];
    tmp_0[36] = 144;
    tmp[144] = DemoModel_B.INPUT_29_1_1[0];
    tmp[145] = DemoModel_B.INPUT_29_1_1[1];
    tmp[146] = DemoModel_B.INPUT_29_1_1[2];
    tmp[147] = DemoModel_B.INPUT_29_1_1[3];
    tmp_0[37] = 148;
    tmp[148] = DemoModel_B.INPUT_31_1_1[0];
    tmp[149] = DemoModel_B.INPUT_31_1_1[1];
    tmp[150] = DemoModel_B.INPUT_31_1_1[2];
    tmp[151] = DemoModel_B.INPUT_31_1_1[3];
    tmp_0[38] = 152;
    tmp[152] = DemoModel_B.INPUT_33_1_1[0];
    tmp[153] = DemoModel_B.INPUT_33_1_1[1];
    tmp[154] = DemoModel_B.INPUT_33_1_1[2];
    tmp[155] = DemoModel_B.INPUT_33_1_1[3];
    tmp_0[39] = 156;
    tmp[156] = DemoModel_B.INPUT_32_1_1[0];
    tmp[157] = DemoModel_B.INPUT_32_1_1[1];
    tmp[158] = DemoModel_B.INPUT_32_1_1[2];
    tmp[159] = DemoModel_B.INPUT_32_1_1[3];
    tmp_0[40] = 160;
    tmp[160] = DemoModel_B.INPUT_34_1_1[0];
    tmp[161] = DemoModel_B.INPUT_34_1_1[1];
    tmp[162] = DemoModel_B.INPUT_34_1_1[2];
    tmp[163] = DemoModel_B.INPUT_34_1_1[3];
    tmp_0[41] = 164;
    tmp[164] = DemoModel_B.INPUT_35_1_1[0];
    tmp[165] = DemoModel_B.INPUT_35_1_1[1];
    tmp[166] = DemoModel_B.INPUT_35_1_1[2];
    tmp[167] = DemoModel_B.INPUT_35_1_1[3];
    tmp_0[42] = 168;
    tmp[168] = DemoModel_B.INPUT_36_1_1[0];
    tmp[169] = DemoModel_B.INPUT_36_1_1[1];
    tmp[170] = DemoModel_B.INPUT_36_1_1[2];
    tmp[171] = DemoModel_B.INPUT_36_1_1[3];
    tmp_0[43] = 172;
    tmp[172] = DemoModel_B.INPUT_37_1_1[0];
    tmp[173] = DemoModel_B.INPUT_37_1_1[1];
    tmp[174] = DemoModel_B.INPUT_37_1_1[2];
    tmp[175] = DemoModel_B.INPUT_37_1_1[3];
    tmp_0[44] = 176;
    tmp[176] = DemoModel_B.INPUT_38_1_1[0];
    tmp[177] = DemoModel_B.INPUT_38_1_1[1];
    tmp[178] = DemoModel_B.INPUT_38_1_1[2];
    tmp[179] = DemoModel_B.INPUT_38_1_1[3];
    tmp_0[45] = 180;
    tmp[180] = DemoModel_B.INPUT_39_1_1[0];
    tmp[181] = DemoModel_B.INPUT_39_1_1[1];
    tmp[182] = DemoModel_B.INPUT_39_1_1[2];
    tmp[183] = DemoModel_B.INPUT_39_1_1[3];
    tmp_0[46] = 184;
    simulationData->mData->mInputValues.mN = 184;
    simulationData->mData->mInputValues.mX = &tmp[0];
    simulationData->mData->mInputOffsets.mN = 47;
    simulationData->mData->mInputOffsets.mX = &tmp_0[0];
    simulationData->mData->mOutputs.mN = 138;
    simulationData->mData->mOutputs.mX = &DemoModel_B.STATE_1[0];
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = NULL;
    simulationData->mData->mIsFundamentalSampleHit = false;
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = NULL;
    simulationData->mData->mCstateHasChanged = false;
    diagnosticManager = (NeuDiagnosticManager *)DemoModel_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_1 = ne_simulator_method((NeslSimulator *)DemoModel_DW.STATE_1_Simulator,
      NESL_SIM_OUTPUTS, simulationData, diagnosticManager);
    if (tmp_1 != 0) {
      rtb_Compare = error_buffer_is_empty(rtmGetErrorStatus(DemoModel_M));
      if (rtb_Compare) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(DemoModel_M, msg);
      }
    }

    /* End of SimscapeExecutionBlock: '<S223>/STATE_1' */

    /* SimscapeExecutionBlock: '<S223>/OUTPUT_1_0' */
    simulationData = (NeslSimulationData *)DemoModel_DW.OUTPUT_1_0_SimData;
    time_0 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = &DemoModel_DW.OUTPUT_1_0_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = &DemoModel_DW.OUTPUT_1_0_Modes;
    rtb_Compare = false;
    simulationData->mData->mFoundZcEvents = rtb_Compare;
    simulationData->mData->mIsMajorTimeStep = rtb_Compare_g;
    rtb_Compare_g = false;
    simulationData->mData->mIsSolverAssertCheck = rtb_Compare_g;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_3[0] = 0;
    tmp_2[0] = DemoModel_B.INPUT_2_1_1[0];
    tmp_2[1] = DemoModel_B.INPUT_2_1_1[1];
    tmp_2[2] = DemoModel_B.INPUT_2_1_1[2];
    tmp_2[3] = DemoModel_B.INPUT_2_1_1[3];
    tmp_3[1] = 4;
    tmp_2[4] = DemoModel_B.INPUT_2_2_1[0];
    tmp_2[5] = DemoModel_B.INPUT_2_2_1[1];
    tmp_2[6] = DemoModel_B.INPUT_2_2_1[2];
    tmp_2[7] = DemoModel_B.INPUT_2_2_1[3];
    tmp_3[2] = 8;
    tmp_2[8] = DemoModel_B.INPUT_1_1_1[0];
    tmp_2[9] = DemoModel_B.INPUT_1_1_1[1];
    tmp_2[10] = DemoModel_B.INPUT_1_1_1[2];
    tmp_2[11] = DemoModel_B.INPUT_1_1_1[3];
    tmp_3[3] = 12;
    tmp_2[12] = DemoModel_B.INPUT_1_2_1[0];
    tmp_2[13] = DemoModel_B.INPUT_1_2_1[1];
    tmp_2[14] = DemoModel_B.INPUT_1_2_1[2];
    tmp_2[15] = DemoModel_B.INPUT_1_2_1[3];
    tmp_3[4] = 16;
    tmp_2[16] = DemoModel_B.INPUT_4_1_1[0];
    tmp_2[17] = DemoModel_B.INPUT_4_1_1[1];
    tmp_2[18] = DemoModel_B.INPUT_4_1_1[2];
    tmp_2[19] = DemoModel_B.INPUT_4_1_1[3];
    tmp_3[5] = 20;
    tmp_2[20] = DemoModel_B.INPUT_3_1_1[0];
    tmp_2[21] = DemoModel_B.INPUT_3_1_1[1];
    tmp_2[22] = DemoModel_B.INPUT_3_1_1[2];
    tmp_2[23] = DemoModel_B.INPUT_3_1_1[3];
    tmp_3[6] = 24;
    tmp_2[24] = DemoModel_B.INPUT_6_1_1[0];
    tmp_2[25] = DemoModel_B.INPUT_6_1_1[1];
    tmp_2[26] = DemoModel_B.INPUT_6_1_1[2];
    tmp_2[27] = DemoModel_B.INPUT_6_1_1[3];
    tmp_3[7] = 28;
    tmp_2[28] = DemoModel_B.INPUT_6_2_1[0];
    tmp_2[29] = DemoModel_B.INPUT_6_2_1[1];
    tmp_2[30] = DemoModel_B.INPUT_6_2_1[2];
    tmp_2[31] = DemoModel_B.INPUT_6_2_1[3];
    tmp_3[8] = 32;
    tmp_2[32] = DemoModel_B.INPUT_5_1_1[0];
    tmp_2[33] = DemoModel_B.INPUT_5_1_1[1];
    tmp_2[34] = DemoModel_B.INPUT_5_1_1[2];
    tmp_2[35] = DemoModel_B.INPUT_5_1_1[3];
    tmp_3[9] = 36;
    tmp_2[36] = DemoModel_B.INPUT_5_2_1[0];
    tmp_2[37] = DemoModel_B.INPUT_5_2_1[1];
    tmp_2[38] = DemoModel_B.INPUT_5_2_1[2];
    tmp_2[39] = DemoModel_B.INPUT_5_2_1[3];
    tmp_3[10] = 40;
    tmp_2[40] = DemoModel_B.INPUT_8_1_1[0];
    tmp_2[41] = DemoModel_B.INPUT_8_1_1[1];
    tmp_2[42] = DemoModel_B.INPUT_8_1_1[2];
    tmp_2[43] = DemoModel_B.INPUT_8_1_1[3];
    tmp_3[11] = 44;
    tmp_2[44] = DemoModel_B.INPUT_7_1_1[0];
    tmp_2[45] = DemoModel_B.INPUT_7_1_1[1];
    tmp_2[46] = DemoModel_B.INPUT_7_1_1[2];
    tmp_2[47] = DemoModel_B.INPUT_7_1_1[3];
    tmp_3[12] = 48;
    tmp_2[48] = DemoModel_B.INPUT_10_1_1[0];
    tmp_2[49] = DemoModel_B.INPUT_10_1_1[1];
    tmp_2[50] = DemoModel_B.INPUT_10_1_1[2];
    tmp_2[51] = DemoModel_B.INPUT_10_1_1[3];
    tmp_3[13] = 52;
    tmp_2[52] = DemoModel_B.INPUT_9_1_1[0];
    tmp_2[53] = DemoModel_B.INPUT_9_1_1[1];
    tmp_2[54] = DemoModel_B.INPUT_9_1_1[2];
    tmp_2[55] = DemoModel_B.INPUT_9_1_1[3];
    tmp_3[14] = 56;
    tmp_2[56] = DemoModel_B.INPUT_12_1_1[0];
    tmp_2[57] = DemoModel_B.INPUT_12_1_1[1];
    tmp_2[58] = DemoModel_B.INPUT_12_1_1[2];
    tmp_2[59] = DemoModel_B.INPUT_12_1_1[3];
    tmp_3[15] = 60;
    tmp_2[60] = DemoModel_B.INPUT_11_1_1[0];
    tmp_2[61] = DemoModel_B.INPUT_11_1_1[1];
    tmp_2[62] = DemoModel_B.INPUT_11_1_1[2];
    tmp_2[63] = DemoModel_B.INPUT_11_1_1[3];
    tmp_3[16] = 64;
    tmp_2[64] = DemoModel_B.INPUT_14_1_1[0];
    tmp_2[65] = DemoModel_B.INPUT_14_1_1[1];
    tmp_2[66] = DemoModel_B.INPUT_14_1_1[2];
    tmp_2[67] = DemoModel_B.INPUT_14_1_1[3];
    tmp_3[17] = 68;
    tmp_2[68] = DemoModel_B.INPUT_13_1_1[0];
    tmp_2[69] = DemoModel_B.INPUT_13_1_1[1];
    tmp_2[70] = DemoModel_B.INPUT_13_1_1[2];
    tmp_2[71] = DemoModel_B.INPUT_13_1_1[3];
    tmp_3[18] = 72;
    tmp_2[72] = DemoModel_B.INPUT_16_1_1[0];
    tmp_2[73] = DemoModel_B.INPUT_16_1_1[1];
    tmp_2[74] = DemoModel_B.INPUT_16_1_1[2];
    tmp_2[75] = DemoModel_B.INPUT_16_1_1[3];
    tmp_3[19] = 76;
    tmp_2[76] = DemoModel_B.INPUT_15_1_1[0];
    tmp_2[77] = DemoModel_B.INPUT_15_1_1[1];
    tmp_2[78] = DemoModel_B.INPUT_15_1_1[2];
    tmp_2[79] = DemoModel_B.INPUT_15_1_1[3];
    tmp_3[20] = 80;
    tmp_2[80] = DemoModel_B.INPUT_17_1_1[0];
    tmp_2[81] = DemoModel_B.INPUT_17_1_1[1];
    tmp_2[82] = DemoModel_B.INPUT_17_1_1[2];
    tmp_2[83] = DemoModel_B.INPUT_17_1_1[3];
    tmp_3[21] = 84;
    tmp_2[84] = DemoModel_B.INPUT_18_1_1[0];
    tmp_2[85] = DemoModel_B.INPUT_18_1_1[1];
    tmp_2[86] = DemoModel_B.INPUT_18_1_1[2];
    tmp_2[87] = DemoModel_B.INPUT_18_1_1[3];
    tmp_3[22] = 88;
    tmp_2[88] = DemoModel_B.INPUT_19_1_1[0];
    tmp_2[89] = DemoModel_B.INPUT_19_1_1[1];
    tmp_2[90] = DemoModel_B.INPUT_19_1_1[2];
    tmp_2[91] = DemoModel_B.INPUT_19_1_1[3];
    tmp_3[23] = 92;
    tmp_2[92] = DemoModel_B.INPUT_20_1_1[0];
    tmp_2[93] = DemoModel_B.INPUT_20_1_1[1];
    tmp_2[94] = DemoModel_B.INPUT_20_1_1[2];
    tmp_2[95] = DemoModel_B.INPUT_20_1_1[3];
    tmp_3[24] = 96;
    tmp_2[96] = DemoModel_B.INPUT_20_2_1[0];
    tmp_2[97] = DemoModel_B.INPUT_20_2_1[1];
    tmp_2[98] = DemoModel_B.INPUT_20_2_1[2];
    tmp_2[99] = DemoModel_B.INPUT_20_2_1[3];
    tmp_3[25] = 100;
    tmp_2[100] = DemoModel_B.INPUT_22_1_1[0];
    tmp_2[101] = DemoModel_B.INPUT_22_1_1[1];
    tmp_2[102] = DemoModel_B.INPUT_22_1_1[2];
    tmp_2[103] = DemoModel_B.INPUT_22_1_1[3];
    tmp_3[26] = 104;
    tmp_2[104] = DemoModel_B.INPUT_21_1_1[0];
    tmp_2[105] = DemoModel_B.INPUT_21_1_1[1];
    tmp_2[106] = DemoModel_B.INPUT_21_1_1[2];
    tmp_2[107] = DemoModel_B.INPUT_21_1_1[3];
    tmp_3[27] = 108;
    tmp_2[108] = DemoModel_B.INPUT_24_1_1[0];
    tmp_2[109] = DemoModel_B.INPUT_24_1_1[1];
    tmp_2[110] = DemoModel_B.INPUT_24_1_1[2];
    tmp_2[111] = DemoModel_B.INPUT_24_1_1[3];
    tmp_3[28] = 112;
    tmp_2[112] = DemoModel_B.INPUT_24_2_1[0];
    tmp_2[113] = DemoModel_B.INPUT_24_2_1[1];
    tmp_2[114] = DemoModel_B.INPUT_24_2_1[2];
    tmp_2[115] = DemoModel_B.INPUT_24_2_1[3];
    tmp_3[29] = 116;
    tmp_2[116] = DemoModel_B.INPUT_23_1_1[0];
    tmp_2[117] = DemoModel_B.INPUT_23_1_1[1];
    tmp_2[118] = DemoModel_B.INPUT_23_1_1[2];
    tmp_2[119] = DemoModel_B.INPUT_23_1_1[3];
    tmp_3[30] = 120;
    tmp_2[120] = DemoModel_B.INPUT_23_2_1[0];
    tmp_2[121] = DemoModel_B.INPUT_23_2_1[1];
    tmp_2[122] = DemoModel_B.INPUT_23_2_1[2];
    tmp_2[123] = DemoModel_B.INPUT_23_2_1[3];
    tmp_3[31] = 124;
    tmp_2[124] = DemoModel_B.INPUT_26_1_1[0];
    tmp_2[125] = DemoModel_B.INPUT_26_1_1[1];
    tmp_2[126] = DemoModel_B.INPUT_26_1_1[2];
    tmp_2[127] = DemoModel_B.INPUT_26_1_1[3];
    tmp_3[32] = 128;
    tmp_2[128] = DemoModel_B.INPUT_25_1_1[0];
    tmp_2[129] = DemoModel_B.INPUT_25_1_1[1];
    tmp_2[130] = DemoModel_B.INPUT_25_1_1[2];
    tmp_2[131] = DemoModel_B.INPUT_25_1_1[3];
    tmp_3[33] = 132;
    tmp_2[132] = DemoModel_B.INPUT_28_1_1[0];
    tmp_2[133] = DemoModel_B.INPUT_28_1_1[1];
    tmp_2[134] = DemoModel_B.INPUT_28_1_1[2];
    tmp_2[135] = DemoModel_B.INPUT_28_1_1[3];
    tmp_3[34] = 136;
    tmp_2[136] = DemoModel_B.INPUT_27_1_1[0];
    tmp_2[137] = DemoModel_B.INPUT_27_1_1[1];
    tmp_2[138] = DemoModel_B.INPUT_27_1_1[2];
    tmp_2[139] = DemoModel_B.INPUT_27_1_1[3];
    tmp_3[35] = 140;
    tmp_2[140] = DemoModel_B.INPUT_30_1_1[0];
    tmp_2[141] = DemoModel_B.INPUT_30_1_1[1];
    tmp_2[142] = DemoModel_B.INPUT_30_1_1[2];
    tmp_2[143] = DemoModel_B.INPUT_30_1_1[3];
    tmp_3[36] = 144;
    tmp_2[144] = DemoModel_B.INPUT_29_1_1[0];
    tmp_2[145] = DemoModel_B.INPUT_29_1_1[1];
    tmp_2[146] = DemoModel_B.INPUT_29_1_1[2];
    tmp_2[147] = DemoModel_B.INPUT_29_1_1[3];
    tmp_3[37] = 148;
    tmp_2[148] = DemoModel_B.INPUT_31_1_1[0];
    tmp_2[149] = DemoModel_B.INPUT_31_1_1[1];
    tmp_2[150] = DemoModel_B.INPUT_31_1_1[2];
    tmp_2[151] = DemoModel_B.INPUT_31_1_1[3];
    tmp_3[38] = 152;
    tmp_2[152] = DemoModel_B.INPUT_33_1_1[0];
    tmp_2[153] = DemoModel_B.INPUT_33_1_1[1];
    tmp_2[154] = DemoModel_B.INPUT_33_1_1[2];
    tmp_2[155] = DemoModel_B.INPUT_33_1_1[3];
    tmp_3[39] = 156;
    tmp_2[156] = DemoModel_B.INPUT_32_1_1[0];
    tmp_2[157] = DemoModel_B.INPUT_32_1_1[1];
    tmp_2[158] = DemoModel_B.INPUT_32_1_1[2];
    tmp_2[159] = DemoModel_B.INPUT_32_1_1[3];
    tmp_3[40] = 160;
    tmp_2[160] = DemoModel_B.INPUT_34_1_1[0];
    tmp_2[161] = DemoModel_B.INPUT_34_1_1[1];
    tmp_2[162] = DemoModel_B.INPUT_34_1_1[2];
    tmp_2[163] = DemoModel_B.INPUT_34_1_1[3];
    tmp_3[41] = 164;
    tmp_2[164] = DemoModel_B.INPUT_35_1_1[0];
    tmp_2[165] = DemoModel_B.INPUT_35_1_1[1];
    tmp_2[166] = DemoModel_B.INPUT_35_1_1[2];
    tmp_2[167] = DemoModel_B.INPUT_35_1_1[3];
    tmp_3[42] = 168;
    tmp_2[168] = DemoModel_B.INPUT_36_1_1[0];
    tmp_2[169] = DemoModel_B.INPUT_36_1_1[1];
    tmp_2[170] = DemoModel_B.INPUT_36_1_1[2];
    tmp_2[171] = DemoModel_B.INPUT_36_1_1[3];
    tmp_3[43] = 172;
    tmp_2[172] = DemoModel_B.INPUT_37_1_1[0];
    tmp_2[173] = DemoModel_B.INPUT_37_1_1[1];
    tmp_2[174] = DemoModel_B.INPUT_37_1_1[2];
    tmp_2[175] = DemoModel_B.INPUT_37_1_1[3];
    tmp_3[44] = 176;
    tmp_2[176] = DemoModel_B.INPUT_38_1_1[0];
    tmp_2[177] = DemoModel_B.INPUT_38_1_1[1];
    tmp_2[178] = DemoModel_B.INPUT_38_1_1[2];
    tmp_2[179] = DemoModel_B.INPUT_38_1_1[3];
    tmp_3[45] = 180;
    tmp_2[180] = DemoModel_B.INPUT_39_1_1[0];
    tmp_2[181] = DemoModel_B.INPUT_39_1_1[1];
    tmp_2[182] = DemoModel_B.INPUT_39_1_1[2];
    tmp_2[183] = DemoModel_B.INPUT_39_1_1[3];
    tmp_3[46] = 184;
    std::memcpy(&tmp_2[184], &DemoModel_B.STATE_1[0], 138U * sizeof(real_T));
    tmp_3[47] = 322;
    simulationData->mData->mInputValues.mN = 322;
    simulationData->mData->mInputValues.mX = &tmp_2[0];
    simulationData->mData->mInputOffsets.mN = 48;
    simulationData->mData->mInputOffsets.mX = &tmp_3[0];
    simulationData->mData->mOutputs.mN = 20;
    simulationData->mData->mOutputs.mX = &rtb_OUTPUT_1_0[0];
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = NULL;
    simulationData->mData->mIsFundamentalSampleHit = false;
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = NULL;
    simulationData->mData->mCstateHasChanged = false;
    diagnosticManager = (NeuDiagnosticManager *)DemoModel_DW.OUTPUT_1_0_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_1 = ne_simulator_method((NeslSimulator *)
      DemoModel_DW.OUTPUT_1_0_Simulator, NESL_SIM_OUTPUTS, simulationData,
      diagnosticManager);
    if (tmp_1 != 0) {
      rtb_Compare_g = error_buffer_is_empty(rtmGetErrorStatus(DemoModel_M));
      if (rtb_Compare_g) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(DemoModel_M, msg);
      }
    }

    /* RelationalOperator: '<S116>/Compare' incorporates:
     *  Constant: '<S116>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[7] >= DemoModel_P.CompareToConstant_const);

    /* DataTypeConversion: '<S8>/Cast To Double' */
    DemoModel_B.CastToDouble_e = rtb_Compare_g;

    /* RelationalOperator: '<S119>/Compare' incorporates:
     *  Constant: '<S119>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[8] >= DemoModel_P.CompareToConstant_const_h);

    /* DataTypeConversion: '<S9>/Cast To Double' */
    DemoModel_B.CastToDouble_j = rtb_Compare_g;

    /* RelationalOperator: '<S122>/Compare' incorporates:
     *  Constant: '<S122>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[9] >= DemoModel_P.CompareToConstant_const_d);

    /* DataTypeConversion: '<S10>/Cast To Double' */
    DemoModel_B.CastToDouble_f = rtb_Compare_g;

    /* BusCreator generated from: '<Root>/FANState' incorporates:
     *  Outport: '<Root>/FANState'
     */
    DemoModel_Y.FANState_b.FAN1Ener = DemoModel_B.CastToDouble_e;
    DemoModel_Y.FANState_b.FAN1State = rtb_ORCond2_1;
    DemoModel_Y.FANState_b.FAN2Ener = DemoModel_B.CastToDouble_j;
    DemoModel_Y.FANState_b.FAN2State = rtb_ORCond2_2;
    DemoModel_Y.FANState_b.FAN3Ener = DemoModel_B.CastToDouble_f;
    DemoModel_Y.FANState_b.FAN3State = rtb_Delay_p;

    /* Outport: '<Root>/RelayState' incorporates:
     *  Memory: '<S105>/Memory1'
     *  Memory: '<S153>/Memory1'
     *  Memory: '<S164>/Memory1'
     *  Memory: '<S175>/Memory1'
     *  Memory: '<S186>/Memory1'
     *  Memory: '<S197>/Memory1'
     *  Memory: '<S210>/Memory1'
     *  Memory: '<S39>/Memory1'
     *  Memory: '<S50>/Memory1'
     *  Memory: '<S61>/Memory1'
     *  Memory: '<S72>/Memory1'
     *  Memory: '<S83>/Memory1'
     *  Memory: '<S94>/Memory1'
     *  Rounding: '<Root>/Round'
     *  Rounding: '<Root>/Round1'
     *  Rounding: '<Root>/Round10'
     *  Rounding: '<Root>/Round11'
     *  Rounding: '<Root>/Round12'
     *  Rounding: '<Root>/Round2'
     *  Rounding: '<Root>/Round3'
     *  Rounding: '<Root>/Round4'
     *  Rounding: '<Root>/Round5'
     *  Rounding: '<Root>/Round6'
     *  Rounding: '<Root>/Round7'
     *  Rounding: '<Root>/Round8'
     *  Rounding: '<Root>/Round9'
     */
    DemoModel_Y.RelayState_k.ORCond2_1 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_o);
    DemoModel_Y.RelayState_k.ORCond2_2 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_h);
    DemoModel_Y.RelayState_k.ANDCond3_1 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_n);
    DemoModel_Y.RelayState_k.ANDCond3_2 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_nz);
    DemoModel_Y.RelayState_k.ANDCond3_3 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_g);
    DemoModel_Y.RelayState_k.ANDCond4 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_p);
    DemoModel_Y.RelayState_k.ANDCond5_12 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_k);
    DemoModel_Y.RelayState_k.ANDCond5_3 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_d);
    DemoModel_Y.RelayState_k.ANDCond7_1 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_j);
    DemoModel_Y.RelayState_k.ANDCond7_2 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_nm);
    DemoModel_Y.RelayState_k.ANDCond8 = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_e);
    DemoModel_Y.RelayState_k.PrimFailCond = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_gf);
    DemoModel_Y.RelayState_k.SecFailCond = rt_roundd_snf
      (DemoModel_DW.Memory1_PreviousInput_p2);

    /* RelationalOperator: '<S142>/Compare' incorporates:
     *  Constant: '<S142>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[11] >= DemoModel_P.CompareToConstant_const_l);

    /* DataTypeConversion: '<S15>/Cast To Double' */
    rtb_ORCond2_1 = rtb_Compare_g;

    /* RelationalOperator: '<S143>/Compare' incorporates:
     *  Constant: '<S143>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[12] >= DemoModel_P.CompareToConstant1_const);

    /* Gain: '<S15>/Multiply' incorporates:
     *  DataTypeConversion: '<S15>/Cast To Double1'
     */
    rtb_ORCond2_2 = DemoModel_P.Multiply_Gain * static_cast<real_T>
      (rtb_Compare_g);

    /* RelationalOperator: '<S144>/Compare' incorporates:
     *  Constant: '<S144>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[13] >=
                     DemoModel_P.CompareToConstant2_const_d);

    /* Sum: '<S15>/Sum' incorporates:
     *  DataTypeConversion: '<S15>/Cast To Double2'
     *  Gain: '<S15>/Multiply1'
     */
    DemoModel_Y.SysState_o.MasterInd = (rtb_ORCond2_1 + rtb_ORCond2_2) +
      DemoModel_P.Multiply1_Gain * static_cast<real_T>(rtb_Compare_g);

    /* RelationalOperator: '<S40>/Compare' incorporates:
     *  Constant: '<S40>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[0] <= DemoModel_P.ANDCond31_MinOpVolt);

    /* RelationalOperator: '<S41>/Compare' incorporates:
     *  Constant: '<S41>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[0] >= DemoModel_P.ANDCond31_MaxOpVolt);

    /* Logic: '<S39>/AND' */
    DemoModel_B.AND = (rtb_Compare_g && rtb_Compare);

    /* RelationalOperator: '<S51>/Compare' incorporates:
     *  Constant: '<S51>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[1] <= DemoModel_P.ANDCond32_MinOpVolt);

    /* RelationalOperator: '<S52>/Compare' incorporates:
     *  Constant: '<S52>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[1] >= DemoModel_P.ANDCond32_MaxOpVolt);

    /* Logic: '<S50>/AND' */
    DemoModel_B.AND_p = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S62>/Compare' incorporates:
     *  Constant: '<S62>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[2] <= DemoModel_P.ANDCond33_MinOpVolt);

    /* RelationalOperator: '<S63>/Compare' incorporates:
     *  Constant: '<S63>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[2] >= DemoModel_P.ANDCond33_MaxOpVolt);

    /* Logic: '<S61>/AND' */
    DemoModel_B.AND_j = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S73>/Compare' incorporates:
     *  Constant: '<S73>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[3] <= DemoModel_P.ANDCond4_MinOpVolt);

    /* RelationalOperator: '<S74>/Compare' incorporates:
     *  Constant: '<S74>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[3] >= DemoModel_P.ANDCond4_MaxOpVolt);

    /* Logic: '<S72>/AND' */
    DemoModel_B.AND_a = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S84>/Compare' incorporates:
     *  Constant: '<S84>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[4] <= DemoModel_P.ANDCond512_MinOpVolt);

    /* RelationalOperator: '<S85>/Compare' incorporates:
     *  Constant: '<S85>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[4] >= DemoModel_P.ANDCond512_MaxOpVolt);

    /* Logic: '<S83>/AND' */
    DemoModel_B.AND_l = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S95>/Compare' incorporates:
     *  Constant: '<S95>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[5] <= DemoModel_P.ANDCond53_MinOpVolt);

    /* RelationalOperator: '<S96>/Compare' incorporates:
     *  Constant: '<S96>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[5] >= DemoModel_P.ANDCond53_MaxOpVolt);

    /* Logic: '<S94>/AND' */
    DemoModel_B.AND_ps = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S106>/Compare' incorporates:
     *  Constant: '<S106>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[6] <= DemoModel_P.ANDCond8_MinOpVolt);

    /* RelationalOperator: '<S107>/Compare' incorporates:
     *  Constant: '<S107>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[6] >= DemoModel_P.ANDCond8_MaxOpVolt);

    /* Logic: '<S105>/AND' */
    DemoModel_B.AND_e = (rtb_Compare && rtb_Compare_g);

    /* Product: '<S8>/Divide' incorporates:
     *  DataTypeConversion: '<S8>/Cast To Boolean'
     *  DataTypeConversion: '<S8>/Cast To Double1'
     *  Inport: '<Root>/SysFailCmd'
     *  Logic: '<S8>/NOT'
     */
    rtb_Divide = static_cast<real_T>(!(DemoModel_U.SysFailCmd_l.FAN1Fail != 0.0))
      * DemoModel_B.CastToDouble_e;

    /* Product: '<S9>/Divide' incorporates:
     *  DataTypeConversion: '<S9>/Cast To Boolean'
     *  DataTypeConversion: '<S9>/Cast To Double1'
     *  Inport: '<Root>/SysFailCmd'
     *  Logic: '<S9>/NOT'
     */
    rtb_Divide_h = static_cast<real_T>(!(DemoModel_U.SysFailCmd_l.FAN2Fail !=
      0.0)) * DemoModel_B.CastToDouble_j;

    /* Product: '<S10>/Divide' incorporates:
     *  DataTypeConversion: '<S10>/Cast To Boolean'
     *  DataTypeConversion: '<S10>/Cast To Double1'
     *  Inport: '<Root>/SysFailCmd'
     *  Logic: '<S10>/NOT'
     */
    rtb_Divide_l = static_cast<real_T>(!(DemoModel_U.SysFailCmd_l.FAN3Fail !=
      0.0)) * DemoModel_B.CastToDouble_f;

    /* RelationalOperator: '<S126>/Compare' incorporates:
     *  Constant: '<S126>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[10] <= DemoModel_P.FAN2PSSwitchRelay_MinOpVolt);

    /* RelationalOperator: '<S127>/Compare' incorporates:
     *  Constant: '<S127>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[10] >=
                     DemoModel_P.FAN2PSSwitchRelay_MaxOpVolt);

    /* Logic: '<S125>/AND' */
    DemoModel_B.AND_h = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S154>/Compare' incorporates:
     *  Constant: '<S154>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[14] <= DemoModel_P.ORCond21_MinOpVolt);

    /* RelationalOperator: '<S155>/Compare' incorporates:
     *  Constant: '<S155>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[14] >= DemoModel_P.ORCond21_MaxOpVolt);

    /* Logic: '<S153>/AND' */
    DemoModel_B.AND_m = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S165>/Compare' incorporates:
     *  Constant: '<S165>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[15] <= DemoModel_P.ORCond22_MinOpVolt);

    /* RelationalOperator: '<S166>/Compare' incorporates:
     *  Constant: '<S166>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[15] >= DemoModel_P.ORCond22_MaxOpVolt);

    /* Logic: '<S164>/AND' */
    DemoModel_B.AND_i = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S176>/Compare' incorporates:
     *  Constant: '<S176>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[16] <= DemoModel_P.ORCond71_MinOpVolt);

    /* RelationalOperator: '<S177>/Compare' incorporates:
     *  Constant: '<S177>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[16] >= DemoModel_P.ORCond71_MaxOpVolt);

    /* Logic: '<S175>/AND' */
    DemoModel_B.AND_hr = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S187>/Compare' incorporates:
     *  Constant: '<S187>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[17] <= DemoModel_P.ORCond72_MinOpVolt);

    /* RelationalOperator: '<S188>/Compare' incorporates:
     *  Constant: '<S188>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[17] >= DemoModel_P.ORCond72_MaxOpVolt);

    /* Logic: '<S186>/AND' */
    DemoModel_B.AND_ew = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S198>/Compare' incorporates:
     *  Constant: '<S198>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[18] <= DemoModel_P.PrimFailCond_MinOpVolt);

    /* RelationalOperator: '<S199>/Compare' incorporates:
     *  Constant: '<S199>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[18] >= DemoModel_P.PrimFailCond_MaxOpVolt);

    /* Logic: '<S197>/AND' */
    DemoModel_B.AND_pl = (rtb_Compare && rtb_Compare_g);

    /* RelationalOperator: '<S211>/Compare' incorporates:
     *  Constant: '<S211>/Constant'
     */
    rtb_Compare = (rtb_OUTPUT_1_0[19] <= DemoModel_P.SecFailCond_MinOpVolt);

    /* RelationalOperator: '<S212>/Compare' incorporates:
     *  Constant: '<S212>/Constant'
     */
    rtb_Compare_g = (rtb_OUTPUT_1_0[19] >= DemoModel_P.SecFailCond_MaxOpVolt);

    /* Logic: '<S210>/AND' */
    DemoModel_B.AND_hl = (rtb_Compare && rtb_Compare_g);
  }

  /* Matfile logging */
  rt_UpdateTXYLogVars(DemoModel_M->rtwLogInfo, (DemoModel_M->Timing.t));

  {
    NeslSimulationData *simulationData;
    real_T time;
    boolean_T tmp;
    real_T tmp_0[184];
    int_T tmp_1[47];
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_2;
    char *msg;

    /* Update for Memory: '<S39>/Memory' */
    DemoModel_DW.Memory_PreviousInput = DemoModel_B.AND;

    /* Update for Memory: '<S50>/Memory' */
    DemoModel_DW.Memory_PreviousInput_p = DemoModel_B.AND_p;

    /* Update for Memory: '<S61>/Memory' */
    DemoModel_DW.Memory_PreviousInput_k = DemoModel_B.AND_j;

    /* Update for Memory: '<S72>/Memory' */
    DemoModel_DW.Memory_PreviousInput_pe = DemoModel_B.AND_a;

    /* Update for Memory: '<S83>/Memory' */
    DemoModel_DW.Memory_PreviousInput_a = DemoModel_B.AND_l;

    /* Update for Memory: '<S94>/Memory' */
    DemoModel_DW.Memory_PreviousInput_d = DemoModel_B.AND_ps;

    /* Update for Memory: '<S105>/Memory' */
    DemoModel_DW.Memory_PreviousInput_pd = DemoModel_B.AND_e;

    /* Update for Memory: '<S125>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput = DemoModel_B.Sum_l;

    /* Update for Memory: '<S125>/Memory' */
    DemoModel_DW.Memory_PreviousInput_n = DemoModel_B.AND_h;

    /* Update for Delay: '<S8>/Delay' */
    DemoModel_DW.Delay_DSTATE = rtb_Divide;

    /* Update for Delay: '<S9>/Delay' */
    DemoModel_DW.Delay_DSTATE_o = rtb_Divide_h;

    /* Update for Delay: '<S10>/Delay' */
    DemoModel_DW.Delay_DSTATE_c = rtb_Divide_l;

    /* Update for Memory: '<S153>/Memory' */
    DemoModel_DW.Memory_PreviousInput_px = DemoModel_B.AND_m;

    /* Update for Memory: '<S164>/Memory' */
    DemoModel_DW.Memory_PreviousInput_e = DemoModel_B.AND_i;

    /* Update for Memory: '<S175>/Memory' */
    DemoModel_DW.Memory_PreviousInput_j = DemoModel_B.AND_hr;

    /* Update for Memory: '<S186>/Memory' */
    DemoModel_DW.Memory_PreviousInput_nm = DemoModel_B.AND_ew;

    /* Update for Memory: '<S197>/Memory' */
    DemoModel_DW.Memory_PreviousInput_jl = DemoModel_B.AND_pl;

    /* Update for Memory: '<S210>/Memory' */
    DemoModel_DW.Memory_PreviousInput_c = DemoModel_B.AND_hl;

    /* Update for SimscapeExecutionBlock: '<S223>/STATE_1' */
    simulationData = (NeslSimulationData *)DemoModel_DW.STATE_1_SimData;
    time = DemoModel_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 92;
    simulationData->mData->mDiscStates.mX = &DemoModel_DW.STATE_1_Discrete[0];
    simulationData->mData->mModeVector.mN = 46;
    simulationData->mData->mModeVector.mX = &DemoModel_DW.STATE_1_Modes[0];
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep(DemoModel_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    tmp_1[0] = 0;
    tmp_0[0] = DemoModel_B.INPUT_2_1_1[0];
    tmp_0[1] = DemoModel_B.INPUT_2_1_1[1];
    tmp_0[2] = DemoModel_B.INPUT_2_1_1[2];
    tmp_0[3] = DemoModel_B.INPUT_2_1_1[3];
    tmp_1[1] = 4;
    tmp_0[4] = DemoModel_B.INPUT_2_2_1[0];
    tmp_0[5] = DemoModel_B.INPUT_2_2_1[1];
    tmp_0[6] = DemoModel_B.INPUT_2_2_1[2];
    tmp_0[7] = DemoModel_B.INPUT_2_2_1[3];
    tmp_1[2] = 8;
    tmp_0[8] = DemoModel_B.INPUT_1_1_1[0];
    tmp_0[9] = DemoModel_B.INPUT_1_1_1[1];
    tmp_0[10] = DemoModel_B.INPUT_1_1_1[2];
    tmp_0[11] = DemoModel_B.INPUT_1_1_1[3];
    tmp_1[3] = 12;
    tmp_0[12] = DemoModel_B.INPUT_1_2_1[0];
    tmp_0[13] = DemoModel_B.INPUT_1_2_1[1];
    tmp_0[14] = DemoModel_B.INPUT_1_2_1[2];
    tmp_0[15] = DemoModel_B.INPUT_1_2_1[3];
    tmp_1[4] = 16;
    tmp_0[16] = DemoModel_B.INPUT_4_1_1[0];
    tmp_0[17] = DemoModel_B.INPUT_4_1_1[1];
    tmp_0[18] = DemoModel_B.INPUT_4_1_1[2];
    tmp_0[19] = DemoModel_B.INPUT_4_1_1[3];
    tmp_1[5] = 20;
    tmp_0[20] = DemoModel_B.INPUT_3_1_1[0];
    tmp_0[21] = DemoModel_B.INPUT_3_1_1[1];
    tmp_0[22] = DemoModel_B.INPUT_3_1_1[2];
    tmp_0[23] = DemoModel_B.INPUT_3_1_1[3];
    tmp_1[6] = 24;
    tmp_0[24] = DemoModel_B.INPUT_6_1_1[0];
    tmp_0[25] = DemoModel_B.INPUT_6_1_1[1];
    tmp_0[26] = DemoModel_B.INPUT_6_1_1[2];
    tmp_0[27] = DemoModel_B.INPUT_6_1_1[3];
    tmp_1[7] = 28;
    tmp_0[28] = DemoModel_B.INPUT_6_2_1[0];
    tmp_0[29] = DemoModel_B.INPUT_6_2_1[1];
    tmp_0[30] = DemoModel_B.INPUT_6_2_1[2];
    tmp_0[31] = DemoModel_B.INPUT_6_2_1[3];
    tmp_1[8] = 32;
    tmp_0[32] = DemoModel_B.INPUT_5_1_1[0];
    tmp_0[33] = DemoModel_B.INPUT_5_1_1[1];
    tmp_0[34] = DemoModel_B.INPUT_5_1_1[2];
    tmp_0[35] = DemoModel_B.INPUT_5_1_1[3];
    tmp_1[9] = 36;
    tmp_0[36] = DemoModel_B.INPUT_5_2_1[0];
    tmp_0[37] = DemoModel_B.INPUT_5_2_1[1];
    tmp_0[38] = DemoModel_B.INPUT_5_2_1[2];
    tmp_0[39] = DemoModel_B.INPUT_5_2_1[3];
    tmp_1[10] = 40;
    tmp_0[40] = DemoModel_B.INPUT_8_1_1[0];
    tmp_0[41] = DemoModel_B.INPUT_8_1_1[1];
    tmp_0[42] = DemoModel_B.INPUT_8_1_1[2];
    tmp_0[43] = DemoModel_B.INPUT_8_1_1[3];
    tmp_1[11] = 44;
    tmp_0[44] = DemoModel_B.INPUT_7_1_1[0];
    tmp_0[45] = DemoModel_B.INPUT_7_1_1[1];
    tmp_0[46] = DemoModel_B.INPUT_7_1_1[2];
    tmp_0[47] = DemoModel_B.INPUT_7_1_1[3];
    tmp_1[12] = 48;
    tmp_0[48] = DemoModel_B.INPUT_10_1_1[0];
    tmp_0[49] = DemoModel_B.INPUT_10_1_1[1];
    tmp_0[50] = DemoModel_B.INPUT_10_1_1[2];
    tmp_0[51] = DemoModel_B.INPUT_10_1_1[3];
    tmp_1[13] = 52;
    tmp_0[52] = DemoModel_B.INPUT_9_1_1[0];
    tmp_0[53] = DemoModel_B.INPUT_9_1_1[1];
    tmp_0[54] = DemoModel_B.INPUT_9_1_1[2];
    tmp_0[55] = DemoModel_B.INPUT_9_1_1[3];
    tmp_1[14] = 56;
    tmp_0[56] = DemoModel_B.INPUT_12_1_1[0];
    tmp_0[57] = DemoModel_B.INPUT_12_1_1[1];
    tmp_0[58] = DemoModel_B.INPUT_12_1_1[2];
    tmp_0[59] = DemoModel_B.INPUT_12_1_1[3];
    tmp_1[15] = 60;
    tmp_0[60] = DemoModel_B.INPUT_11_1_1[0];
    tmp_0[61] = DemoModel_B.INPUT_11_1_1[1];
    tmp_0[62] = DemoModel_B.INPUT_11_1_1[2];
    tmp_0[63] = DemoModel_B.INPUT_11_1_1[3];
    tmp_1[16] = 64;
    tmp_0[64] = DemoModel_B.INPUT_14_1_1[0];
    tmp_0[65] = DemoModel_B.INPUT_14_1_1[1];
    tmp_0[66] = DemoModel_B.INPUT_14_1_1[2];
    tmp_0[67] = DemoModel_B.INPUT_14_1_1[3];
    tmp_1[17] = 68;
    tmp_0[68] = DemoModel_B.INPUT_13_1_1[0];
    tmp_0[69] = DemoModel_B.INPUT_13_1_1[1];
    tmp_0[70] = DemoModel_B.INPUT_13_1_1[2];
    tmp_0[71] = DemoModel_B.INPUT_13_1_1[3];
    tmp_1[18] = 72;
    tmp_0[72] = DemoModel_B.INPUT_16_1_1[0];
    tmp_0[73] = DemoModel_B.INPUT_16_1_1[1];
    tmp_0[74] = DemoModel_B.INPUT_16_1_1[2];
    tmp_0[75] = DemoModel_B.INPUT_16_1_1[3];
    tmp_1[19] = 76;
    tmp_0[76] = DemoModel_B.INPUT_15_1_1[0];
    tmp_0[77] = DemoModel_B.INPUT_15_1_1[1];
    tmp_0[78] = DemoModel_B.INPUT_15_1_1[2];
    tmp_0[79] = DemoModel_B.INPUT_15_1_1[3];
    tmp_1[20] = 80;
    tmp_0[80] = DemoModel_B.INPUT_17_1_1[0];
    tmp_0[81] = DemoModel_B.INPUT_17_1_1[1];
    tmp_0[82] = DemoModel_B.INPUT_17_1_1[2];
    tmp_0[83] = DemoModel_B.INPUT_17_1_1[3];
    tmp_1[21] = 84;
    tmp_0[84] = DemoModel_B.INPUT_18_1_1[0];
    tmp_0[85] = DemoModel_B.INPUT_18_1_1[1];
    tmp_0[86] = DemoModel_B.INPUT_18_1_1[2];
    tmp_0[87] = DemoModel_B.INPUT_18_1_1[3];
    tmp_1[22] = 88;
    tmp_0[88] = DemoModel_B.INPUT_19_1_1[0];
    tmp_0[89] = DemoModel_B.INPUT_19_1_1[1];
    tmp_0[90] = DemoModel_B.INPUT_19_1_1[2];
    tmp_0[91] = DemoModel_B.INPUT_19_1_1[3];
    tmp_1[23] = 92;
    tmp_0[92] = DemoModel_B.INPUT_20_1_1[0];
    tmp_0[93] = DemoModel_B.INPUT_20_1_1[1];
    tmp_0[94] = DemoModel_B.INPUT_20_1_1[2];
    tmp_0[95] = DemoModel_B.INPUT_20_1_1[3];
    tmp_1[24] = 96;
    tmp_0[96] = DemoModel_B.INPUT_20_2_1[0];
    tmp_0[97] = DemoModel_B.INPUT_20_2_1[1];
    tmp_0[98] = DemoModel_B.INPUT_20_2_1[2];
    tmp_0[99] = DemoModel_B.INPUT_20_2_1[3];
    tmp_1[25] = 100;
    tmp_0[100] = DemoModel_B.INPUT_22_1_1[0];
    tmp_0[101] = DemoModel_B.INPUT_22_1_1[1];
    tmp_0[102] = DemoModel_B.INPUT_22_1_1[2];
    tmp_0[103] = DemoModel_B.INPUT_22_1_1[3];
    tmp_1[26] = 104;
    tmp_0[104] = DemoModel_B.INPUT_21_1_1[0];
    tmp_0[105] = DemoModel_B.INPUT_21_1_1[1];
    tmp_0[106] = DemoModel_B.INPUT_21_1_1[2];
    tmp_0[107] = DemoModel_B.INPUT_21_1_1[3];
    tmp_1[27] = 108;
    tmp_0[108] = DemoModel_B.INPUT_24_1_1[0];
    tmp_0[109] = DemoModel_B.INPUT_24_1_1[1];
    tmp_0[110] = DemoModel_B.INPUT_24_1_1[2];
    tmp_0[111] = DemoModel_B.INPUT_24_1_1[3];
    tmp_1[28] = 112;
    tmp_0[112] = DemoModel_B.INPUT_24_2_1[0];
    tmp_0[113] = DemoModel_B.INPUT_24_2_1[1];
    tmp_0[114] = DemoModel_B.INPUT_24_2_1[2];
    tmp_0[115] = DemoModel_B.INPUT_24_2_1[3];
    tmp_1[29] = 116;
    tmp_0[116] = DemoModel_B.INPUT_23_1_1[0];
    tmp_0[117] = DemoModel_B.INPUT_23_1_1[1];
    tmp_0[118] = DemoModel_B.INPUT_23_1_1[2];
    tmp_0[119] = DemoModel_B.INPUT_23_1_1[3];
    tmp_1[30] = 120;
    tmp_0[120] = DemoModel_B.INPUT_23_2_1[0];
    tmp_0[121] = DemoModel_B.INPUT_23_2_1[1];
    tmp_0[122] = DemoModel_B.INPUT_23_2_1[2];
    tmp_0[123] = DemoModel_B.INPUT_23_2_1[3];
    tmp_1[31] = 124;
    tmp_0[124] = DemoModel_B.INPUT_26_1_1[0];
    tmp_0[125] = DemoModel_B.INPUT_26_1_1[1];
    tmp_0[126] = DemoModel_B.INPUT_26_1_1[2];
    tmp_0[127] = DemoModel_B.INPUT_26_1_1[3];
    tmp_1[32] = 128;
    tmp_0[128] = DemoModel_B.INPUT_25_1_1[0];
    tmp_0[129] = DemoModel_B.INPUT_25_1_1[1];
    tmp_0[130] = DemoModel_B.INPUT_25_1_1[2];
    tmp_0[131] = DemoModel_B.INPUT_25_1_1[3];
    tmp_1[33] = 132;
    tmp_0[132] = DemoModel_B.INPUT_28_1_1[0];
    tmp_0[133] = DemoModel_B.INPUT_28_1_1[1];
    tmp_0[134] = DemoModel_B.INPUT_28_1_1[2];
    tmp_0[135] = DemoModel_B.INPUT_28_1_1[3];
    tmp_1[34] = 136;
    tmp_0[136] = DemoModel_B.INPUT_27_1_1[0];
    tmp_0[137] = DemoModel_B.INPUT_27_1_1[1];
    tmp_0[138] = DemoModel_B.INPUT_27_1_1[2];
    tmp_0[139] = DemoModel_B.INPUT_27_1_1[3];
    tmp_1[35] = 140;
    tmp_0[140] = DemoModel_B.INPUT_30_1_1[0];
    tmp_0[141] = DemoModel_B.INPUT_30_1_1[1];
    tmp_0[142] = DemoModel_B.INPUT_30_1_1[2];
    tmp_0[143] = DemoModel_B.INPUT_30_1_1[3];
    tmp_1[36] = 144;
    tmp_0[144] = DemoModel_B.INPUT_29_1_1[0];
    tmp_0[145] = DemoModel_B.INPUT_29_1_1[1];
    tmp_0[146] = DemoModel_B.INPUT_29_1_1[2];
    tmp_0[147] = DemoModel_B.INPUT_29_1_1[3];
    tmp_1[37] = 148;
    tmp_0[148] = DemoModel_B.INPUT_31_1_1[0];
    tmp_0[149] = DemoModel_B.INPUT_31_1_1[1];
    tmp_0[150] = DemoModel_B.INPUT_31_1_1[2];
    tmp_0[151] = DemoModel_B.INPUT_31_1_1[3];
    tmp_1[38] = 152;
    tmp_0[152] = DemoModel_B.INPUT_33_1_1[0];
    tmp_0[153] = DemoModel_B.INPUT_33_1_1[1];
    tmp_0[154] = DemoModel_B.INPUT_33_1_1[2];
    tmp_0[155] = DemoModel_B.INPUT_33_1_1[3];
    tmp_1[39] = 156;
    tmp_0[156] = DemoModel_B.INPUT_32_1_1[0];
    tmp_0[157] = DemoModel_B.INPUT_32_1_1[1];
    tmp_0[158] = DemoModel_B.INPUT_32_1_1[2];
    tmp_0[159] = DemoModel_B.INPUT_32_1_1[3];
    tmp_1[40] = 160;
    tmp_0[160] = DemoModel_B.INPUT_34_1_1[0];
    tmp_0[161] = DemoModel_B.INPUT_34_1_1[1];
    tmp_0[162] = DemoModel_B.INPUT_34_1_1[2];
    tmp_0[163] = DemoModel_B.INPUT_34_1_1[3];
    tmp_1[41] = 164;
    tmp_0[164] = DemoModel_B.INPUT_35_1_1[0];
    tmp_0[165] = DemoModel_B.INPUT_35_1_1[1];
    tmp_0[166] = DemoModel_B.INPUT_35_1_1[2];
    tmp_0[167] = DemoModel_B.INPUT_35_1_1[3];
    tmp_1[42] = 168;
    tmp_0[168] = DemoModel_B.INPUT_36_1_1[0];
    tmp_0[169] = DemoModel_B.INPUT_36_1_1[1];
    tmp_0[170] = DemoModel_B.INPUT_36_1_1[2];
    tmp_0[171] = DemoModel_B.INPUT_36_1_1[3];
    tmp_1[43] = 172;
    tmp_0[172] = DemoModel_B.INPUT_37_1_1[0];
    tmp_0[173] = DemoModel_B.INPUT_37_1_1[1];
    tmp_0[174] = DemoModel_B.INPUT_37_1_1[2];
    tmp_0[175] = DemoModel_B.INPUT_37_1_1[3];
    tmp_1[44] = 176;
    tmp_0[176] = DemoModel_B.INPUT_38_1_1[0];
    tmp_0[177] = DemoModel_B.INPUT_38_1_1[1];
    tmp_0[178] = DemoModel_B.INPUT_38_1_1[2];
    tmp_0[179] = DemoModel_B.INPUT_38_1_1[3];
    tmp_1[45] = 180;
    tmp_0[180] = DemoModel_B.INPUT_39_1_1[0];
    tmp_0[181] = DemoModel_B.INPUT_39_1_1[1];
    tmp_0[182] = DemoModel_B.INPUT_39_1_1[2];
    tmp_0[183] = DemoModel_B.INPUT_39_1_1[3];
    tmp_1[46] = 184;
    simulationData->mData->mInputValues.mN = 184;
    simulationData->mData->mInputValues.mX = &tmp_0[0];
    simulationData->mData->mInputOffsets.mN = 47;
    simulationData->mData->mInputOffsets.mX = &tmp_1[0];
    diagnosticManager = (NeuDiagnosticManager *)DemoModel_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)DemoModel_DW.STATE_1_Simulator,
      NESL_SIM_UPDATE, simulationData, diagnosticManager);
    if (tmp_2 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(DemoModel_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(DemoModel_M, msg);
      }
    }

    /* End of Update for SimscapeExecutionBlock: '<S223>/STATE_1' */

    /* Update for Memory: '<S153>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_o = DemoModel_B.Sum_ec;

    /* Update for Memory: '<S164>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_h = DemoModel_B.Sum_pp;

    /* Update for Memory: '<S39>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_n = DemoModel_B.Sum;

    /* Update for Memory: '<S50>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_nz = DemoModel_B.Sum_j;

    /* Update for Memory: '<S61>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_g = DemoModel_B.Sum_p;

    /* Update for Memory: '<S72>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_p = DemoModel_B.Sum_e;

    /* Update for Memory: '<S83>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_k = DemoModel_B.Sum_m;

    /* Update for Memory: '<S94>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_d = DemoModel_B.Sum_h;

    /* Update for Memory: '<S175>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_j = DemoModel_B.Sum_i;

    /* Update for Memory: '<S186>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_nm = DemoModel_B.Sum_lw;

    /* Update for Memory: '<S105>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_e = DemoModel_B.Sum_d;

    /* Update for Memory: '<S197>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_gf = DemoModel_B.Sum_dl;

    /* Update for Memory: '<S210>/Memory1' */
    DemoModel_DW.Memory1_PreviousInput_p2 = DemoModel_B.Sum_o;
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(DemoModel_M)!=-1) &&
        !((rtmGetTFinal(DemoModel_M)-DemoModel_M->Timing.t[0]) >
          DemoModel_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(DemoModel_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++DemoModel_M->Timing.clockTick0)) {
    ++DemoModel_M->Timing.clockTickH0;
  }

  DemoModel_M->Timing.t[0] = DemoModel_M->Timing.clockTick0 *
    DemoModel_M->Timing.stepSize0 + DemoModel_M->Timing.clockTickH0 *
    DemoModel_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.001, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    DemoModel_M->Timing.clockTick1++;
    if (!DemoModel_M->Timing.clockTick1) {
      DemoModel_M->Timing.clockTickH1++;
    }
  }
}

/* Model initialize function */
void DemoModel_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&DemoModel_M->solverInfo,
                          &DemoModel_M->Timing.simTimeStep);
    rtsiSetTPtr(&DemoModel_M->solverInfo, &rtmGetTPtr(DemoModel_M));
    rtsiSetStepSizePtr(&DemoModel_M->solverInfo, &DemoModel_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&DemoModel_M->solverInfo, (&rtmGetErrorStatus
      (DemoModel_M)));
    rtsiSetRTModelPtr(&DemoModel_M->solverInfo, DemoModel_M);
  }

  rtsiSetSimTimeStep(&DemoModel_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&DemoModel_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(DemoModel_M, &DemoModel_M->Timing.tArray[0]);
  rtmSetTFinal(DemoModel_M, -1);
  DemoModel_M->Timing.stepSize0 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    DemoModel_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(DemoModel_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(DemoModel_M->rtwLogInfo, (NULL));
    rtliSetLogT(DemoModel_M->rtwLogInfo, "tout");
    rtliSetLogX(DemoModel_M->rtwLogInfo, "");
    rtliSetLogXFinal(DemoModel_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(DemoModel_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(DemoModel_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(DemoModel_M->rtwLogInfo, 0);
    rtliSetLogDecimation(DemoModel_M->rtwLogInfo, 1);
    rtliSetLogY(DemoModel_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(DemoModel_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(DemoModel_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) std::memset((static_cast<void *>(&DemoModel_B)), 0,
                     sizeof(B_DemoModel_T));

  /* states (dwork) */
  (void) std::memset(static_cast<void *>(&DemoModel_DW), 0,
                     sizeof(DW_DemoModel_T));

  /* external inputs */
  (void)std::memset(&DemoModel_U, 0, sizeof(ExtU_DemoModel_T));

  /* external outputs */
  (void) std::memset(static_cast<void *>(&DemoModel_Y), 0,
                     sizeof(ExtY_DemoModel_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(DemoModel_M->rtwLogInfo, 0.0, rtmGetTFinal
    (DemoModel_M), DemoModel_M->Timing.stepSize0, (&rtmGetErrorStatus
    (DemoModel_M)));

  {
    NeslSimulator *tmp;
    boolean_T tmp_0;
    NeuDiagnosticManager *diagnosticManager;
    NeModelParameters modelParameters;
    real_T tmp_1;
    NeuDiagnosticTree *diagnosticTree;
    int32_T tmp_2;
    char *msg;
    NeslSimulationData *simulationData;
    real_T time;
    boolean_T tmp_3;
    NeModelParameters modelParameters_0;
    real_T time_0;
    NeParameterBundle expl_temp;
    real_T time_tmp;

    /* Start for SimscapeExecutionBlock: '<S223>/STATE_1' incorporates:
     *  SimscapeExecutionBlock: '<S223>/OUTPUT_1_0'
     */
    tmp = nesl_lease_simulator("DemoModel/Solver Configuration_1", 0, 0);
    DemoModel_DW.STATE_1_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(DemoModel_DW.STATE_1_Simulator);
    if (tmp_0) {
      DemoModel_1d0f24d5_1_gateway();
      tmp = nesl_lease_simulator("DemoModel/Solver Configuration_1", 0, 0);
      DemoModel_DW.STATE_1_Simulator = (void *)tmp;
    }

    simulationData = nesl_create_simulation_data();
    DemoModel_DW.STATE_1_SimData = (void *)simulationData;
    diagnosticManager = rtw_create_diagnostics();
    DemoModel_DW.STATE_1_DiagMgr = (void *)diagnosticManager;
    modelParameters.mSolverType = NE_SOLVER_TYPE_ODE;
    modelParameters.mSolverTolerance = 0.001;
    modelParameters.mVariableStepSolver = false;
    modelParameters.mFixedStepSize = 0.001;
    modelParameters.mStartTime = 0.0;
    modelParameters.mLoadInitialState = false;
    modelParameters.mUseSimState = false;
    modelParameters.mLinTrimCompile = false;
    modelParameters.mLoggingMode = SSC_LOGGING_NONE;
    modelParameters.mRTWModifiedTimeStamp = 5.35719559E+8;
    tmp_1 = 0.001;
    modelParameters.mSolverTolerance = tmp_1;
    tmp_1 = 0.001;
    modelParameters.mFixedStepSize = tmp_1;
    tmp_0 = false;
    modelParameters.mVariableStepSolver = tmp_0;
    diagnosticManager = (NeuDiagnosticManager *)DemoModel_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = nesl_initialize_simulator((NeslSimulator *)
      DemoModel_DW.STATE_1_Simulator, &modelParameters, diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus(DemoModel_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(DemoModel_M, msg);
      }
    }

    expl_temp.mRealParameters.mN = 0;
    expl_temp.mRealParameters.mX = NULL;
    expl_temp.mLogicalParameters.mN = 0;
    expl_temp.mLogicalParameters.mX = NULL;
    expl_temp.mIntegerParameters.mN = 0;
    expl_temp.mIntegerParameters.mX = NULL;
    expl_temp.mIndexParameters.mN = 0;
    expl_temp.mIndexParameters.mX = NULL;
    nesl_simulator_set_rtps((NeslSimulator *)DemoModel_DW.STATE_1_Simulator,
      expl_temp);
    simulationData = (NeslSimulationData *)DemoModel_DW.STATE_1_SimData;
    time_tmp = DemoModel_M->Timing.t[0];
    time = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 92;
    simulationData->mData->mDiscStates.mX = &DemoModel_DW.STATE_1_Discrete[0];
    simulationData->mData->mModeVector.mN = 46;
    simulationData->mData->mModeVector.mX = &DemoModel_DW.STATE_1_Modes[0];
    tmp_0 = false;
    simulationData->mData->mFoundZcEvents = tmp_0;
    tmp_0 = rtmIsMajorTimeStep(DemoModel_M);
    simulationData->mData->mIsMajorTimeStep = tmp_0;
    tmp_3 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_3;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    diagnosticManager = (NeuDiagnosticManager *)DemoModel_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)DemoModel_DW.STATE_1_Simulator,
      NESL_SIM_INITIALIZEONCE, simulationData, diagnosticManager);
    if (tmp_2 != 0) {
      tmp_3 = error_buffer_is_empty(rtmGetErrorStatus(DemoModel_M));
      if (tmp_3) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(DemoModel_M, msg);
      }
    }

    /* End of Start for SimscapeExecutionBlock: '<S223>/STATE_1' */

    /* Start for SimscapeExecutionBlock: '<S223>/OUTPUT_1_0' */
    tmp = nesl_lease_simulator("DemoModel/Solver Configuration_1", 1, 0);
    DemoModel_DW.OUTPUT_1_0_Simulator = (void *)tmp;
    tmp_3 = pointer_is_null(DemoModel_DW.OUTPUT_1_0_Simulator);
    if (tmp_3) {
      DemoModel_1d0f24d5_1_gateway();
      tmp = nesl_lease_simulator("DemoModel/Solver Configuration_1", 1, 0);
      DemoModel_DW.OUTPUT_1_0_Simulator = (void *)tmp;
    }

    simulationData = nesl_create_simulation_data();
    DemoModel_DW.OUTPUT_1_0_SimData = (void *)simulationData;
    diagnosticManager = rtw_create_diagnostics();
    DemoModel_DW.OUTPUT_1_0_DiagMgr = (void *)diagnosticManager;
    modelParameters_0.mSolverType = NE_SOLVER_TYPE_ODE;
    modelParameters_0.mSolverTolerance = 0.001;
    modelParameters_0.mVariableStepSolver = false;
    modelParameters_0.mFixedStepSize = 0.001;
    modelParameters_0.mStartTime = 0.0;
    modelParameters_0.mLoadInitialState = false;
    modelParameters_0.mUseSimState = false;
    modelParameters_0.mLinTrimCompile = false;
    modelParameters_0.mLoggingMode = SSC_LOGGING_NONE;
    modelParameters_0.mRTWModifiedTimeStamp = 5.35719559E+8;
    tmp_1 = 0.001;
    modelParameters_0.mSolverTolerance = tmp_1;
    tmp_1 = 0.001;
    modelParameters_0.mFixedStepSize = tmp_1;
    tmp_3 = false;
    modelParameters_0.mVariableStepSolver = tmp_3;
    diagnosticManager = (NeuDiagnosticManager *)DemoModel_DW.OUTPUT_1_0_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = nesl_initialize_simulator((NeslSimulator *)
      DemoModel_DW.OUTPUT_1_0_Simulator, &modelParameters_0, diagnosticManager);
    if (tmp_2 != 0) {
      tmp_3 = error_buffer_is_empty(rtmGetErrorStatus(DemoModel_M));
      if (tmp_3) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(DemoModel_M, msg);
      }
    }

    simulationData = (NeslSimulationData *)DemoModel_DW.OUTPUT_1_0_SimData;
    time_0 = time_tmp;
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = &DemoModel_DW.OUTPUT_1_0_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = &DemoModel_DW.OUTPUT_1_0_Modes;
    tmp_3 = false;
    simulationData->mData->mFoundZcEvents = tmp_3;
    simulationData->mData->mIsMajorTimeStep = tmp_0;
    tmp_0 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_0;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    diagnosticManager = (NeuDiagnosticManager *)DemoModel_DW.OUTPUT_1_0_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method((NeslSimulator *)
      DemoModel_DW.OUTPUT_1_0_Simulator, NESL_SIM_INITIALIZEONCE, simulationData,
      diagnosticManager);
    if (tmp_2 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus(DemoModel_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(DemoModel_M, msg);
      }
    }
  }

  /* InitializeConditions for Memory: '<S39>/Memory' */
  DemoModel_DW.Memory_PreviousInput = DemoModel_P.Memory_InitialCondition;

  /* InitializeConditions for Memory: '<S50>/Memory' */
  DemoModel_DW.Memory_PreviousInput_p = DemoModel_P.Memory_InitialCondition_h;

  /* InitializeConditions for Memory: '<S61>/Memory' */
  DemoModel_DW.Memory_PreviousInput_k = DemoModel_P.Memory_InitialCondition_b;

  /* InitializeConditions for Memory: '<S72>/Memory' */
  DemoModel_DW.Memory_PreviousInput_pe = DemoModel_P.Memory_InitialCondition_j;

  /* InitializeConditions for Memory: '<S83>/Memory' */
  DemoModel_DW.Memory_PreviousInput_a = DemoModel_P.Memory_InitialCondition_p;

  /* InitializeConditions for Memory: '<S94>/Memory' */
  DemoModel_DW.Memory_PreviousInput_d = DemoModel_P.Memory_InitialCondition_f;

  /* InitializeConditions for Memory: '<S105>/Memory' */
  DemoModel_DW.Memory_PreviousInput_pd = DemoModel_P.Memory_InitialCondition_k;

  /* InitializeConditions for Memory: '<S125>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput = DemoModel_P.Memory1_InitialCondition;

  /* InitializeConditions for Memory: '<S125>/Memory' */
  DemoModel_DW.Memory_PreviousInput_n = DemoModel_P.Memory_InitialCondition_kj;

  /* InitializeConditions for Delay: '<S8>/Delay' */
  DemoModel_DW.Delay_DSTATE = DemoModel_P.Delay_InitialCondition;

  /* InitializeConditions for Delay: '<S9>/Delay' */
  DemoModel_DW.Delay_DSTATE_o = DemoModel_P.Delay_InitialCondition_h;

  /* InitializeConditions for Delay: '<S10>/Delay' */
  DemoModel_DW.Delay_DSTATE_c = DemoModel_P.Delay_InitialCondition_d;

  /* InitializeConditions for Memory: '<S153>/Memory' */
  DemoModel_DW.Memory_PreviousInput_px = DemoModel_P.Memory_InitialCondition_m;

  /* InitializeConditions for Memory: '<S164>/Memory' */
  DemoModel_DW.Memory_PreviousInput_e = DemoModel_P.Memory_InitialCondition_n;

  /* InitializeConditions for Memory: '<S175>/Memory' */
  DemoModel_DW.Memory_PreviousInput_j = DemoModel_P.Memory_InitialCondition_i;

  /* InitializeConditions for Memory: '<S186>/Memory' */
  DemoModel_DW.Memory_PreviousInput_nm = DemoModel_P.Memory_InitialCondition_me;

  /* InitializeConditions for Memory: '<S197>/Memory' */
  DemoModel_DW.Memory_PreviousInput_jl = DemoModel_P.Memory_InitialCondition_jd;

  /* InitializeConditions for Memory: '<S210>/Memory' */
  DemoModel_DW.Memory_PreviousInput_c = DemoModel_P.Memory_InitialCondition_d;

  /* InitializeConditions for Memory: '<S153>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_o = DemoModel_P.Memory1_InitialCondition_m;

  /* InitializeConditions for Memory: '<S164>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_h = DemoModel_P.Memory1_InitialCondition_h;

  /* InitializeConditions for Memory: '<S39>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_n = DemoModel_P.Memory1_InitialCondition_d;

  /* InitializeConditions for Memory: '<S50>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_nz = DemoModel_P.Memory1_InitialCondition_g;

  /* InitializeConditions for Memory: '<S61>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_g = DemoModel_P.Memory1_InitialCondition_dv;

  /* InitializeConditions for Memory: '<S72>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_p = DemoModel_P.Memory1_InitialCondition_i;

  /* InitializeConditions for Memory: '<S83>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_k = DemoModel_P.Memory1_InitialCondition_c;

  /* InitializeConditions for Memory: '<S94>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_d = DemoModel_P.Memory1_InitialCondition_o;

  /* InitializeConditions for Memory: '<S175>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_j = DemoModel_P.Memory1_InitialCondition_l;

  /* InitializeConditions for Memory: '<S186>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_nm =
    DemoModel_P.Memory1_InitialCondition_da;

  /* InitializeConditions for Memory: '<S105>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_e = DemoModel_P.Memory1_InitialCondition_mr;

  /* InitializeConditions for Memory: '<S197>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_gf =
    DemoModel_P.Memory1_InitialCondition_ms;

  /* InitializeConditions for Memory: '<S210>/Memory1' */
  DemoModel_DW.Memory1_PreviousInput_p2 = DemoModel_P.Memory1_InitialCondition_a;
}

/* Model terminate function */
void DemoModel_terminate(void)
{
  /* Terminate for SimscapeExecutionBlock: '<S223>/STATE_1' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    DemoModel_DW.STATE_1_DiagMgr);
  nesl_destroy_simulation_data((NeslSimulationData *)
    DemoModel_DW.STATE_1_SimData);
  nesl_erase_simulator("DemoModel/Solver Configuration_1");

  /* Terminate for SimscapeExecutionBlock: '<S223>/OUTPUT_1_0' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    DemoModel_DW.OUTPUT_1_0_DiagMgr);
  nesl_destroy_simulation_data((NeslSimulationData *)
    DemoModel_DW.OUTPUT_1_0_SimData);
  nesl_erase_simulator("DemoModel/Solver Configuration_1");
}
