/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#include "ne_ds.h"
#include "DemoModel_1d0f24d5_1_ds_mode.h"
#include "DemoModel_1d0f24d5_1_ds_sys_struct.h"
#include "DemoModel_1d0f24d5_1_ds_externals.h"
#include "DemoModel_1d0f24d5_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T DemoModel_1d0f24d5_1_ds_mode(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t1, NeDsMethodOutput *t2)
{
  PmIntVector out;
  real_T U_idx_0;
  real_T U_idx_1;
  real_T U_idx_10;
  real_T U_idx_11;
  real_T U_idx_12;
  real_T U_idx_13;
  real_T U_idx_14;
  real_T U_idx_15;
  real_T U_idx_16;
  real_T U_idx_17;
  real_T U_idx_18;
  real_T U_idx_19;
  real_T U_idx_2;
  real_T U_idx_20;
  real_T U_idx_21;
  real_T U_idx_22;
  real_T U_idx_23;
  real_T U_idx_24;
  real_T U_idx_25;
  real_T U_idx_26;
  real_T U_idx_27;
  real_T U_idx_28;
  real_T U_idx_29;
  real_T U_idx_3;
  real_T U_idx_30;
  real_T U_idx_31;
  real_T U_idx_32;
  real_T U_idx_33;
  real_T U_idx_34;
  real_T U_idx_35;
  real_T U_idx_36;
  real_T U_idx_37;
  real_T U_idx_38;
  real_T U_idx_39;
  real_T U_idx_4;
  real_T U_idx_40;
  real_T U_idx_41;
  real_T U_idx_42;
  real_T U_idx_43;
  real_T U_idx_44;
  real_T U_idx_45;
  real_T U_idx_5;
  real_T U_idx_6;
  real_T U_idx_7;
  real_T U_idx_8;
  real_T U_idx_9;
  U_idx_0 = t1->mU.mX[0];
  U_idx_1 = t1->mU.mX[1];
  U_idx_2 = t1->mU.mX[2];
  U_idx_3 = t1->mU.mX[3];
  U_idx_4 = t1->mU.mX[4];
  U_idx_5 = t1->mU.mX[5];
  U_idx_6 = t1->mU.mX[6];
  U_idx_7 = t1->mU.mX[7];
  U_idx_8 = t1->mU.mX[8];
  U_idx_9 = t1->mU.mX[9];
  U_idx_10 = t1->mU.mX[10];
  U_idx_11 = t1->mU.mX[11];
  U_idx_12 = t1->mU.mX[12];
  U_idx_13 = t1->mU.mX[13];
  U_idx_14 = t1->mU.mX[14];
  U_idx_15 = t1->mU.mX[15];
  U_idx_16 = t1->mU.mX[16];
  U_idx_17 = t1->mU.mX[17];
  U_idx_18 = t1->mU.mX[18];
  U_idx_19 = t1->mU.mX[19];
  U_idx_20 = t1->mU.mX[20];
  U_idx_21 = t1->mU.mX[21];
  U_idx_22 = t1->mU.mX[22];
  U_idx_23 = t1->mU.mX[23];
  U_idx_24 = t1->mU.mX[24];
  U_idx_25 = t1->mU.mX[25];
  U_idx_26 = t1->mU.mX[26];
  U_idx_27 = t1->mU.mX[27];
  U_idx_28 = t1->mU.mX[28];
  U_idx_29 = t1->mU.mX[29];
  U_idx_30 = t1->mU.mX[30];
  U_idx_31 = t1->mU.mX[31];
  U_idx_32 = t1->mU.mX[32];
  U_idx_33 = t1->mU.mX[33];
  U_idx_34 = t1->mU.mX[34];
  U_idx_35 = t1->mU.mX[35];
  U_idx_36 = t1->mU.mX[36];
  U_idx_37 = t1->mU.mX[37];
  U_idx_38 = t1->mU.mX[38];
  U_idx_39 = t1->mU.mX[39];
  U_idx_40 = t1->mU.mX[40];
  U_idx_41 = t1->mU.mX[41];
  U_idx_42 = t1->mU.mX[42];
  U_idx_43 = t1->mU.mX[43];
  U_idx_44 = t1->mU.mX[44];
  U_idx_45 = t1->mU.mX[45];
  out = t2->mMODE;
  out.mX[0] = (int32_T)(U_idx_0 > 0.5);
  out.mX[1] = (int32_T)(U_idx_1 > 0.5);
  out.mX[2] = (int32_T)(U_idx_10 > 0.5);
  out.mX[3] = (int32_T)(U_idx_11 > 0.5);
  out.mX[4] = (int32_T)(U_idx_12 > 0.5);
  out.mX[5] = (int32_T)(U_idx_13 > 0.5);
  out.mX[6] = (int32_T)(U_idx_14 > 0.5);
  out.mX[7] = (int32_T)(U_idx_15 > 0.5);
  out.mX[8] = (int32_T)(U_idx_16 > 0.5);
  out.mX[9] = (int32_T)(U_idx_17 > 0.5);
  out.mX[10] = (int32_T)(U_idx_18 > 0.5);
  out.mX[11] = (int32_T)(U_idx_19 > 0.5);
  out.mX[12] = (int32_T)(U_idx_2 > 0.5);
  out.mX[13] = (int32_T)(U_idx_20 > 0.5);
  out.mX[14] = (int32_T)(U_idx_21 > 0.5);
  out.mX[15] = (int32_T)(U_idx_22 > 0.5);
  out.mX[16] = (int32_T)(U_idx_23 > 0.5);
  out.mX[17] = (int32_T)(U_idx_24 > 0.5);
  out.mX[18] = (int32_T)(U_idx_25 > 0.5);
  out.mX[19] = (int32_T)(U_idx_26 > 0.5);
  out.mX[20] = (int32_T)(U_idx_27 > 0.5);
  out.mX[21] = (int32_T)(U_idx_28 > 0.5);
  out.mX[22] = (int32_T)(U_idx_29 > 0.5);
  out.mX[23] = (int32_T)(U_idx_3 > 0.5);
  out.mX[24] = (int32_T)(U_idx_30 > 0.5);
  out.mX[25] = (int32_T)(U_idx_31 > 0.5);
  out.mX[26] = (int32_T)(U_idx_32 > 0.5);
  out.mX[27] = (int32_T)(U_idx_33 > 0.5);
  out.mX[28] = (int32_T)(U_idx_34 > 0.5);
  out.mX[29] = (int32_T)(U_idx_35 > 0.5);
  out.mX[30] = (int32_T)(U_idx_36 > 0.5);
  out.mX[31] = (int32_T)(U_idx_37 > 0.5);
  out.mX[32] = (int32_T)(U_idx_38 > 0.5);
  out.mX[33] = (int32_T)(U_idx_39 > 0.5);
  out.mX[34] = (int32_T)(U_idx_4 > 0.5);
  out.mX[35] = (int32_T)(U_idx_40 > 0.5);
  out.mX[36] = (int32_T)(U_idx_41 > 0.5);
  out.mX[37] = (int32_T)(U_idx_42 > 0.5);
  out.mX[38] = (int32_T)(U_idx_43 > 0.5);
  out.mX[39] = (int32_T)(U_idx_44 > 0.5);
  out.mX[40] = (int32_T)(U_idx_45 > 0.5);
  out.mX[41] = (int32_T)(U_idx_5 > 0.5);
  out.mX[42] = (int32_T)(U_idx_6 > 0.5);
  out.mX[43] = (int32_T)(U_idx_7 > 0.5);
  out.mX[44] = (int32_T)(U_idx_8 > 0.5);
  out.mX[45] = (int32_T)(U_idx_9 > 0.5);
  (void)sys;
  (void)t2;
  return 0;
}
