/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#include "ne_ds.h"
#include "DemoModel_1d0f24d5_1_ds_f.h"
#include "DemoModel_1d0f24d5_1_ds_sys_struct.h"
#include "DemoModel_1d0f24d5_1_ds_externals.h"
#include "DemoModel_1d0f24d5_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T DemoModel_1d0f24d5_1_ds_f(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t46, NeDsMethodOutput *t47)
{
  PmRealVector out;
  real_T Subsystem2_Switch_v;
  real_T Subsystem5_Switch_i;
  real_T t0;
  real_T t1;
  real_T t2;
  real_T t3;
  real_T t4;
  real_T t5;
  real_T t6;
  real_T t7;
  real_T t9;
  real_T t11;
  real_T t13;
  real_T t14;
  real_T t15;
  real_T t16;
  real_T t17;
  real_T t18;
  real_T t19;
  real_T t20;
  real_T t21;
  real_T t23;
  real_T t25;
  real_T t26;
  real_T t27;
  real_T t28;
  real_T t30;
  real_T t31;
  real_T t32;
  real_T t33;
  real_T t34;
  real_T X_idx_6;
  real_T X_idx_3;
  real_T X_idx_0;
  real_T X_idx_1;
  real_T X_idx_4;
  real_T X_idx_7;
  real_T X_idx_10;
  real_T X_idx_8;
  real_T X_idx_12;
  real_T X_idx_9;
  real_T X_idx_16;
  real_T X_idx_17;
  real_T X_idx_18;
  real_T X_idx_21;
  real_T X_idx_20;
  real_T X_idx_22;
  real_T X_idx_27;
  real_T X_idx_28;
  real_T X_idx_25;
  real_T X_idx_29;
  real_T X_idx_30;
  real_T X_idx_31;
  real_T X_idx_32;
  real_T X_idx_33;
  real_T X_idx_34;
  real_T X_idx_26;
  real_T X_idx_35;
  real_T X_idx_11;
  real_T X_idx_14;
  real_T X_idx_36;
  real_T X_idx_37;
  real_T X_idx_38;
  real_T X_idx_39;
  real_T X_idx_40;
  real_T X_idx_44;
  int32_T M_idx_12;
  int32_T M_idx_23;
  int32_T M_idx_34;
  int32_T M_idx_41;
  int32_T M_idx_42;
  int32_T M_idx_44;
  int32_T M_idx_45;
  int32_T M_idx_3;
  int32_T M_idx_5;
  int32_T M_idx_7;
  int32_T M_idx_9;
  int32_T M_idx_10;
  int32_T M_idx_11;
  int32_T M_idx_13;
  int32_T M_idx_14;
  int32_T M_idx_15;
  int32_T M_idx_16;
  int32_T M_idx_17;
  int32_T M_idx_18;
  int32_T M_idx_19;
  int32_T M_idx_22;
  int32_T M_idx_24;
  int32_T M_idx_26;
  int32_T M_idx_28;
  int32_T M_idx_29;
  int32_T M_idx_30;
  int32_T M_idx_31;
  int32_T M_idx_32;
  int32_T M_idx_33;
  int32_T M_idx_35;
  int32_T M_idx_36;
  int32_T M_idx_37;
  int32_T M_idx_38;
  int32_T M_idx_39;
  int32_T M_idx_40;
  real_T X_idx_2;
  real_T X_idx_5;
  real_T X_idx_13;
  real_T X_idx_15;
  real_T X_idx_19;
  real_T X_idx_23;
  real_T X_idx_24;
  real_T X_idx_41;
  real_T X_idx_42;
  real_T X_idx_43;
  real_T X_idx_45;
  M_idx_3 = t46->mM.mX[3];
  M_idx_5 = t46->mM.mX[5];
  M_idx_7 = t46->mM.mX[7];
  M_idx_9 = t46->mM.mX[9];
  M_idx_10 = t46->mM.mX[10];
  M_idx_11 = t46->mM.mX[11];
  M_idx_12 = t46->mM.mX[12];
  M_idx_13 = t46->mM.mX[13];
  M_idx_14 = t46->mM.mX[14];
  M_idx_15 = t46->mM.mX[15];
  M_idx_16 = t46->mM.mX[16];
  M_idx_17 = t46->mM.mX[17];
  M_idx_18 = t46->mM.mX[18];
  M_idx_19 = t46->mM.mX[19];
  M_idx_22 = t46->mM.mX[22];
  M_idx_23 = t46->mM.mX[23];
  M_idx_24 = t46->mM.mX[24];
  M_idx_26 = t46->mM.mX[26];
  M_idx_28 = t46->mM.mX[28];
  M_idx_29 = t46->mM.mX[29];
  M_idx_30 = t46->mM.mX[30];
  M_idx_31 = t46->mM.mX[31];
  M_idx_32 = t46->mM.mX[32];
  M_idx_33 = t46->mM.mX[33];
  M_idx_34 = t46->mM.mX[34];
  M_idx_35 = t46->mM.mX[35];
  M_idx_36 = t46->mM.mX[36];
  M_idx_37 = t46->mM.mX[37];
  M_idx_38 = t46->mM.mX[38];
  M_idx_39 = t46->mM.mX[39];
  M_idx_40 = t46->mM.mX[40];
  M_idx_41 = t46->mM.mX[41];
  M_idx_42 = t46->mM.mX[42];
  M_idx_44 = t46->mM.mX[44];
  M_idx_45 = t46->mM.mX[45];
  X_idx_0 = t46->mX.mX[0];
  X_idx_1 = t46->mX.mX[1];
  X_idx_2 = t46->mX.mX[2];
  X_idx_3 = t46->mX.mX[3];
  X_idx_4 = t46->mX.mX[4];
  X_idx_5 = t46->mX.mX[5];
  X_idx_6 = t46->mX.mX[6];
  X_idx_7 = t46->mX.mX[7];
  X_idx_8 = t46->mX.mX[8];
  X_idx_9 = t46->mX.mX[9];
  X_idx_10 = t46->mX.mX[10];
  X_idx_11 = t46->mX.mX[11];
  X_idx_12 = t46->mX.mX[12];
  X_idx_13 = t46->mX.mX[13];
  X_idx_14 = t46->mX.mX[14];
  X_idx_15 = t46->mX.mX[15];
  X_idx_16 = t46->mX.mX[16];
  X_idx_17 = t46->mX.mX[17];
  X_idx_18 = t46->mX.mX[18];
  X_idx_19 = t46->mX.mX[19];
  X_idx_20 = t46->mX.mX[20];
  X_idx_21 = t46->mX.mX[21];
  X_idx_22 = t46->mX.mX[22];
  X_idx_23 = t46->mX.mX[23];
  X_idx_24 = t46->mX.mX[24];
  X_idx_25 = t46->mX.mX[25];
  X_idx_26 = t46->mX.mX[26];
  X_idx_27 = t46->mX.mX[27];
  X_idx_28 = t46->mX.mX[28];
  X_idx_29 = t46->mX.mX[29];
  X_idx_30 = t46->mX.mX[30];
  X_idx_31 = t46->mX.mX[31];
  X_idx_32 = t46->mX.mX[32];
  X_idx_33 = t46->mX.mX[33];
  X_idx_34 = t46->mX.mX[34];
  X_idx_35 = t46->mX.mX[35];
  X_idx_36 = t46->mX.mX[36];
  X_idx_37 = t46->mX.mX[37];
  X_idx_38 = t46->mX.mX[38];
  X_idx_39 = t46->mX.mX[39];
  X_idx_40 = t46->mX.mX[40];
  X_idx_41 = t46->mX.mX[41];
  X_idx_42 = t46->mX.mX[42];
  X_idx_43 = t46->mX.mX[43];
  X_idx_44 = t46->mX.mX[44];
  X_idx_45 = t46->mX.mX[45];
  out = t47->mF;
  t6 = ((X_idx_6 * 0.01 + X_idx_3 * -0.01) + X_idx_0 * -0.01) + X_idx_1 * -0.01;
  t2 = -X_idx_4 + X_idx_6;
  t3 = (X_idx_7 * 0.01 + X_idx_0 * -0.01) + X_idx_10 * -0.01;
  t4 = X_idx_7 * 0.02 + X_idx_8 * -0.03;
  t5 = -X_idx_0 + X_idx_8;
  t7 = X_idx_0 * -0.01 + X_idx_12 * -0.01;
  t9 = ((((((X_idx_6 * -0.02 + X_idx_3 * 0.01) + -X_idx_9) + X_idx_0 * 0.01) +
          X_idx_1 * 0.01) + X_idx_16 * 0.01) + X_idx_17) + X_idx_18;
  t11 = -X_idx_21 + X_idx_20;
  t13 = ((((X_idx_0 * 0.01 + X_idx_20 * -0.01) + -X_idx_22) + -X_idx_27) +
         -X_idx_17) + X_idx_28;
  t27 = (((((((X_idx_7 * 0.01 + X_idx_25 * -0.01) + X_idx_29 *
              -0.060000000000000005) + X_idx_30 * 0.01) + -X_idx_31) + X_idx_32 *
           0.01) + X_idx_33 * -0.01) + X_idx_34 * -0.01) + X_idx_26 * -0.01;
  t30 = (((((((((((((X_idx_6 * 0.02 + X_idx_7 * 0.03) + X_idx_8 * -0.03) +
                   X_idx_3 * -0.01) + X_idx_0 * -0.09) + X_idx_10 * -0.01) +
                X_idx_12 * -0.01) + X_idx_1 * -0.01) + X_idx_20 * 0.01) +
             X_idx_16 * -0.01) + X_idx_35 * -0.01) + X_idx_11 * -0.01) +
          X_idx_14 * -0.01) + X_idx_36 * 0.01) + X_idx_31;
  t14 = (X_idx_6 * -0.01 + X_idx_16 * 0.01) + -X_idx_31;
  t15 = -X_idx_16 + X_idx_0;
  t16 = -X_idx_16 + X_idx_29;
  t17 = X_idx_0 * -0.01 + X_idx_35 * -0.01;
  t18 = X_idx_0 * -0.01 + X_idx_11 * -0.01;
  t19 = X_idx_0 * -0.01 + X_idx_14 * -0.01;
  t26 = (X_idx_29 * 0.01 + X_idx_32 * -0.01) + X_idx_34 * 0.01;
  t25 = X_idx_0 * 0.01 + X_idx_36 * -0.01;
  t20 = (-X_idx_37 + X_idx_29) + -28.0;
  t21 = (-X_idx_38 + X_idx_0) + -28.0;
  t23 = ((X_idx_29 * 0.01 + X_idx_30 * -0.01) + -X_idx_39) + X_idx_40;
  t28 = (((X_idx_7 * -0.04 + X_idx_8 * 0.02) + X_idx_0 * 0.01) + X_idx_10 * 0.01)
    + X_idx_29 * 0.01;
  t31 = (X_idx_25 * -0.01 + -X_idx_44) + X_idx_26 * -0.01;
  t32 = -X_idx_29 + X_idx_25;
  t33 = X_idx_29 * -0.01 + X_idx_33 * -0.01;
  t34 = (X_idx_29 * -0.01 + X_idx_32 * 0.01) + X_idx_34 * -0.01;
  Subsystem2_Switch_v = -X_idx_6 + X_idx_20;
  Subsystem5_Switch_i = X_idx_25 * -0.01 + X_idx_26 * -0.01;
  if (M_idx_12 != 0) {
    t0 = X_idx_3 - t6 * 0.01;
  } else {
    t0 = X_idx_3 - t6 / 1.0E-8;
  }

  if (M_idx_23 != 0) {
    t1 = t2 - X_idx_9 * 0.01;
  } else {
    t1 = t2 - X_idx_9 / 1.0E-8;
  }

  if (M_idx_34 != 0) {
    t2 = X_idx_10 - t3 * 0.01;
  } else {
    t2 = X_idx_10 - t3 / 1.0E-8;
  }

  if (M_idx_41 != 0) {
    t3 = t5 - t4 * 0.01;
  } else {
    t3 = t5 - t4 / 1.0E-8;
  }

  if (M_idx_42 != 0) {
    t4 = X_idx_12 - t7 * 0.01;
  } else {
    t4 = X_idx_12 - t7 / 1.0E-8;
  }

  if (M_idx_44 != 0) {
    t5 = X_idx_1 - t6 * 0.01;
  } else {
    t5 = X_idx_1 - t6 / 1.0E-8;
  }

  if (M_idx_45 != 0) {
    t6 = X_idx_4 - X_idx_9 * 0.01;
  } else {
    t6 = X_idx_4 - X_idx_9 / 1.0E-8;
  }

  if (M_idx_3 != 0) {
    t7 = X_idx_6 - t9 * 0.01;
  } else {
    t7 = X_idx_6 - t9 / 1.0E-8;
  }

  if (M_idx_5 != 0) {
    X_idx_3 = t11 - X_idx_22 * 0.01;
  } else {
    X_idx_3 = t11 - X_idx_22 / 1.0E-8;
  }

  if (M_idx_7 != 0) {
    t9 = X_idx_21 - X_idx_22 * 0.01;
  } else {
    t9 = X_idx_21 - X_idx_22 / 1.0E-8;
  }

  if (M_idx_9 != 0) {
    X_idx_25 = X_idx_20 - t13 * 0.01;
  } else {
    X_idx_25 = X_idx_20 - t13 / 1.0E-8;
  }

  if (M_idx_10 != 0) {
    t11 = t15 - t14 * 0.01;
  } else {
    t11 = t15 - t14 / 1.0E-8;
  }

  if (M_idx_11 != 0) {
    X_idx_29 = t16 - X_idx_31 * 0.01;
  } else {
    X_idx_29 = t16 - X_idx_31 / 1.0E-8;
  }

  if (M_idx_13 != 0) {
    t13 = X_idx_35 - t17 * 0.01;
  } else {
    t13 = X_idx_35 - t17 / 1.0E-8;
  }

  if (M_idx_14 != 0) {
    t14 = X_idx_11 - t18 * 0.01;
  } else {
    t14 = X_idx_11 - t18 / 1.0E-8;
  }

  if (M_idx_15 != 0) {
    t15 = X_idx_14 - t19 * 0.01;
  } else {
    t15 = X_idx_14 - t19 / 1.0E-8;
  }

  if (M_idx_16 != 0) {
    t16 = t20 - t27 * 0.01;
  } else {
    t16 = t20 - t27 / 1.0E-8;
  }

  if (M_idx_17 != 0) {
    t17 = t21 - t30 * 0.01;
  } else {
    t17 = t21 - t30 / 1.0E-8;
  }

  if (M_idx_18 != 0) {
    t18 = X_idx_30 - t23 * 0.01;
  } else {
    t18 = X_idx_30 - t23 / 1.0E-8;
  }

  if (M_idx_19 != 0) {
    t19 = X_idx_7 - t28 * 0.01;
  } else {
    t19 = X_idx_7 - t28 / 1.0E-8;
  }

  if (M_idx_22 != 0) {
    t20 = X_idx_30 - X_idx_39 * 0.01;
  } else {
    t20 = X_idx_30 - X_idx_39 / 1.0E-8;
  }

  if (M_idx_24 != 0) {
    t21 = X_idx_20 - X_idx_27 * 0.01;
  } else {
    t21 = X_idx_20 - X_idx_27 / 1.0E-8;
  }

  if (M_idx_26 != 0) {
    X_idx_8 = t32 - t31 * 0.01;
  } else {
    X_idx_8 = t32 - t31 / 1.0E-8;
  }

  if (M_idx_28 != 0) {
    t23 = t32 - X_idx_44 * 0.01;
  } else {
    t23 = t32 - X_idx_44 / 1.0E-8;
  }

  if (M_idx_29 != 0) {
    X_idx_0 = X_idx_36 - t25 * 0.01;
  } else {
    X_idx_0 = X_idx_36 - t25 / 1.0E-8;
  }

  if (M_idx_30 != 0) {
    t25 = X_idx_32 - t26 * 0.01;
  } else {
    t25 = X_idx_32 - t26 / 1.0E-8;
  }

  if (M_idx_31 != 0) {
    t26 = X_idx_37 - t27 * 0.01;
  } else {
    t26 = X_idx_37 - t27 / 1.0E-8;
  }

  if (M_idx_32 != 0) {
    t27 = X_idx_33 - t33 * 0.01;
  } else {
    t27 = X_idx_33 - t33 / 1.0E-8;
  }

  if (M_idx_33 != 0) {
    t28 = X_idx_34 - t34 * 0.01;
  } else {
    t28 = X_idx_34 - t34 / 1.0E-8;
  }

  if (M_idx_35 != 0) {
    X_idx_16 = X_idx_38 - t30 * 0.01;
  } else {
    X_idx_16 = X_idx_38 - t30 / 1.0E-8;
  }

  if (M_idx_36 != 0) {
    t30 = -X_idx_20 - X_idx_28 * 0.01;
  } else {
    t30 = -X_idx_20 - X_idx_28 / 1.0E-8;
  }

  if (M_idx_37 != 0) {
    t31 = Subsystem2_Switch_v - X_idx_17 * 0.01;
  } else {
    t31 = Subsystem2_Switch_v - X_idx_17 / 1.0E-8;
  }

  if (M_idx_38 != 0) {
    t32 = X_idx_26 - Subsystem5_Switch_i * 0.01;
  } else {
    t32 = X_idx_26 - Subsystem5_Switch_i / 1.0E-8;
  }

  if (M_idx_39 != 0) {
    t33 = -X_idx_30 - X_idx_40 * 0.01;
  } else {
    t33 = -X_idx_30 - X_idx_40 / 1.0E-8;
  }

  if (M_idx_40 != 0) {
    t34 = -X_idx_6 - X_idx_18 * 0.01;
  } else {
    t34 = -X_idx_6 - X_idx_18 / 1.0E-8;
  }

  out.mX[0] = X_idx_2;
  out.mX[1] = X_idx_5;
  out.mX[2] = t0 / 1.0E+8;
  out.mX[3] = t1 / 1.0E+8;
  out.mX[4] = t2 / 1.0E+8;
  out.mX[5] = t3 / 1.0E+8;
  out.mX[6] = t4 / 1.0E+8;
  out.mX[7] = X_idx_13;
  out.mX[8] = t5 / 1.0E+8;
  out.mX[9] = t6 / 1.0E+8;
  out.mX[10] = X_idx_15;
  out.mX[11] = t7 / 1.0E+8;
  out.mX[12] = X_idx_19;
  out.mX[13] = X_idx_3 / 1.0E+8;
  out.mX[14] = X_idx_23;
  out.mX[15] = t9 / 1.0E+8;
  out.mX[16] = X_idx_24;
  out.mX[17] = X_idx_25 / 1.0E+8;
  out.mX[18] = t11 / 1.0E+8;
  out.mX[19] = X_idx_29 / 1.0E+8;
  out.mX[20] = t13 / 1.0E+8;
  out.mX[21] = t14 / 1.0E+8;
  out.mX[22] = t15 / 1.0E+8;
  out.mX[23] = t16 / 1.0E+8;
  out.mX[24] = t17 / 1.0E+8;
  out.mX[25] = t18 / 1.0E+8;
  out.mX[26] = t19 / 1.0E+8;
  out.mX[27] = X_idx_41;
  out.mX[28] = X_idx_42;
  out.mX[29] = t20 / 1.0E+8;
  out.mX[30] = t21 / 1.0E+8;
  out.mX[31] = X_idx_43;
  out.mX[32] = X_idx_8 / 1.0E+8;
  out.mX[33] = X_idx_45;
  out.mX[34] = t23 / 1.0E+8;
  out.mX[35] = X_idx_0 / 1.0E+8;
  out.mX[36] = t25 / 1.0E+8;
  out.mX[37] = t26 / 1.0E+8;
  out.mX[38] = t27 / 1.0E+8;
  out.mX[39] = t28 / 1.0E+8;
  out.mX[40] = X_idx_16 / 1.0E+8;
  out.mX[41] = t30 / 1.0E+8;
  out.mX[42] = t31 / 1.0E+8;
  out.mX[43] = t32 / 1.0E+8;
  out.mX[44] = t33 / 1.0E+8;
  out.mX[45] = t34 / 1.0E+8;
  (void)sys;
  (void)t47;
  return 0;
}
