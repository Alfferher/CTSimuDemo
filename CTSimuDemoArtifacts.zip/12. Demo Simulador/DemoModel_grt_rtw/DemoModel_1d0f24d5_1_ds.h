/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */
/* DemoModel_1d0f24d5_1_ds.h - header for module DemoModel_1d0f24d5_1_ds */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef DEMOMODEL_1D0F24D5_1_DS_H
#define DEMOMODEL_1D0F24D5_1_DS_H      1

  extern NeDynamicSystem *DemoModel_1d0f24d5_1_dae_ds(PmAllocator *allocator );

#endif                                 /* #ifndef DEMOMODEL_1D0F24D5_1_DS_H */

#ifdef __cplusplus

}
#endif
