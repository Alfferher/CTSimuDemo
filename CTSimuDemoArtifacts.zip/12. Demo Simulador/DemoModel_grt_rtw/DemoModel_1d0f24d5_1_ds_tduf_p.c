/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#include "ne_ds.h"
#include "DemoModel_1d0f24d5_1_ds_tduf_p.h"
#include "DemoModel_1d0f24d5_1_ds_sys_struct.h"
#include "DemoModel_1d0f24d5_1_ds_externals.h"
#include "DemoModel_1d0f24d5_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T DemoModel_1d0f24d5_1_ds_tduf_p(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t1, NeDsMethodOutput *t2)
{
  PmSparsityPattern out;
  (void)t1;
  out = t2->mTDUF_P;
  out.mNumCol = 46ULL;
  out.mNumRow = 46ULL;
  out.mJc[0] = 0;
  out.mJc[1] = 1;
  out.mJc[2] = 2;
  out.mJc[3] = 3;
  out.mJc[4] = 4;
  out.mJc[5] = 5;
  out.mJc[6] = 6;
  out.mJc[7] = 7;
  out.mJc[8] = 8;
  out.mJc[9] = 9;
  out.mJc[10] = 10;
  out.mJc[11] = 11;
  out.mJc[12] = 12;
  out.mJc[13] = 13;
  out.mJc[14] = 14;
  out.mJc[15] = 15;
  out.mJc[16] = 16;
  out.mJc[17] = 17;
  out.mJc[18] = 18;
  out.mJc[19] = 19;
  out.mJc[20] = 20;
  out.mJc[21] = 21;
  out.mJc[22] = 22;
  out.mJc[23] = 23;
  out.mJc[24] = 24;
  out.mJc[25] = 25;
  out.mJc[26] = 26;
  out.mJc[27] = 27;
  out.mJc[28] = 28;
  out.mJc[29] = 29;
  out.mJc[30] = 30;
  out.mJc[31] = 31;
  out.mJc[32] = 32;
  out.mJc[33] = 33;
  out.mJc[34] = 34;
  out.mJc[35] = 35;
  out.mJc[36] = 36;
  out.mJc[37] = 37;
  out.mJc[38] = 38;
  out.mJc[39] = 39;
  out.mJc[40] = 40;
  out.mJc[41] = 41;
  out.mJc[42] = 42;
  out.mJc[43] = 43;
  out.mJc[44] = 44;
  out.mJc[45] = 45;
  out.mJc[46] = 46;
  out.mIr[0] = 0;
  out.mIr[1] = 1;
  out.mIr[2] = 2;
  out.mIr[3] = 3;
  out.mIr[4] = 4;
  out.mIr[5] = 5;
  out.mIr[6] = 6;
  out.mIr[7] = 7;
  out.mIr[8] = 8;
  out.mIr[9] = 9;
  out.mIr[10] = 10;
  out.mIr[11] = 11;
  out.mIr[12] = 12;
  out.mIr[13] = 13;
  out.mIr[14] = 14;
  out.mIr[15] = 15;
  out.mIr[16] = 16;
  out.mIr[17] = 17;
  out.mIr[18] = 18;
  out.mIr[19] = 19;
  out.mIr[20] = 20;
  out.mIr[21] = 21;
  out.mIr[22] = 22;
  out.mIr[23] = 23;
  out.mIr[24] = 24;
  out.mIr[25] = 25;
  out.mIr[26] = 26;
  out.mIr[27] = 27;
  out.mIr[28] = 28;
  out.mIr[29] = 29;
  out.mIr[30] = 30;
  out.mIr[31] = 31;
  out.mIr[32] = 32;
  out.mIr[33] = 33;
  out.mIr[34] = 34;
  out.mIr[35] = 35;
  out.mIr[36] = 36;
  out.mIr[37] = 37;
  out.mIr[38] = 38;
  out.mIr[39] = 39;
  out.mIr[40] = 40;
  out.mIr[41] = 41;
  out.mIr[42] = 42;
  out.mIr[43] = 43;
  out.mIr[44] = 44;
  out.mIr[45] = 45;
  (void)sys;
  (void)t2;
  return 0;
}
