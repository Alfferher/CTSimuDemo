/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#include "ne_ds.h"
#include "DemoModel_1d0f24d5_1_ds_imin.h"
#include "DemoModel_1d0f24d5_1_ds_sys_struct.h"
#include "DemoModel_1d0f24d5_1_ds_externals.h"
#include "DemoModel_1d0f24d5_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T DemoModel_1d0f24d5_1_ds_imin(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t1, NeDsMethodOutput *t2)
{
  PmRealVector out;
  (void)t1;
  out = t2->mIMIN;
  out.mX[0] = -pmf_get_inf();
  out.mX[1] = -pmf_get_inf();
  out.mX[2] = -pmf_get_inf();
  out.mX[3] = -pmf_get_inf();
  out.mX[4] = -pmf_get_inf();
  out.mX[5] = -pmf_get_inf();
  out.mX[6] = -pmf_get_inf();
  out.mX[7] = -pmf_get_inf();
  out.mX[8] = -pmf_get_inf();
  out.mX[9] = -pmf_get_inf();
  out.mX[10] = -pmf_get_inf();
  out.mX[11] = -pmf_get_inf();
  out.mX[12] = -pmf_get_inf();
  out.mX[13] = -pmf_get_inf();
  out.mX[14] = -pmf_get_inf();
  out.mX[15] = -pmf_get_inf();
  out.mX[16] = -pmf_get_inf();
  out.mX[17] = -pmf_get_inf();
  out.mX[18] = -pmf_get_inf();
  out.mX[19] = -pmf_get_inf();
  out.mX[20] = -pmf_get_inf();
  out.mX[21] = -pmf_get_inf();
  out.mX[22] = -pmf_get_inf();
  out.mX[23] = -pmf_get_inf();
  out.mX[24] = -pmf_get_inf();
  out.mX[25] = -pmf_get_inf();
  out.mX[26] = -pmf_get_inf();
  out.mX[27] = -pmf_get_inf();
  out.mX[28] = -pmf_get_inf();
  out.mX[29] = -pmf_get_inf();
  out.mX[30] = -pmf_get_inf();
  out.mX[31] = -pmf_get_inf();
  out.mX[32] = -pmf_get_inf();
  out.mX[33] = -pmf_get_inf();
  out.mX[34] = -pmf_get_inf();
  out.mX[35] = -pmf_get_inf();
  out.mX[36] = -pmf_get_inf();
  out.mX[37] = -pmf_get_inf();
  out.mX[38] = -pmf_get_inf();
  out.mX[39] = -pmf_get_inf();
  out.mX[40] = -pmf_get_inf();
  out.mX[41] = -pmf_get_inf();
  out.mX[42] = -pmf_get_inf();
  out.mX[43] = -pmf_get_inf();
  out.mX[44] = -pmf_get_inf();
  out.mX[45] = -pmf_get_inf();
  (void)sys;
  (void)t2;
  return 0;
}
