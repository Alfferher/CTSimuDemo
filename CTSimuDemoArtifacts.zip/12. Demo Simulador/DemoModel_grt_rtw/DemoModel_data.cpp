/*
 * DemoModel_data.cpp
 *
 * Code generation for model "DemoModel".
 *
 * Model version              : 1.69
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Sun Feb 21 10:18:30 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "DemoModel.h"
#include "DemoModel_private.h"

/* Block parameters (default storage) */
P_DemoModel_T DemoModel_P = {
  /* Mask Parameter: ANDCond31_MaxOpVolt
   * Referenced by: '<S41>/Constant'
   */
  22.0,

  /* Mask Parameter: ANDCond32_MaxOpVolt
   * Referenced by: '<S52>/Constant'
   */
  22.0,

  /* Mask Parameter: ANDCond33_MaxOpVolt
   * Referenced by: '<S63>/Constant'
   */
  22.0,

  /* Mask Parameter: ANDCond4_MaxOpVolt
   * Referenced by: '<S74>/Constant'
   */
  22.0,

  /* Mask Parameter: ANDCond512_MaxOpVolt
   * Referenced by: '<S85>/Constant'
   */
  22.0,

  /* Mask Parameter: ANDCond53_MaxOpVolt
   * Referenced by: '<S96>/Constant'
   */
  22.0,

  /* Mask Parameter: ANDCond8_MaxOpVolt
   * Referenced by: '<S107>/Constant'
   */
  22.0,

  /* Mask Parameter: FAN2PSSwitchRelay_MaxOpVolt
   * Referenced by: '<S127>/Constant'
   */
  22.0,

  /* Mask Parameter: ORCond21_MaxOpVolt
   * Referenced by: '<S155>/Constant'
   */
  22.0,

  /* Mask Parameter: ORCond22_MaxOpVolt
   * Referenced by: '<S166>/Constant'
   */
  22.0,

  /* Mask Parameter: ORCond71_MaxOpVolt
   * Referenced by: '<S177>/Constant'
   */
  22.0,

  /* Mask Parameter: ORCond72_MaxOpVolt
   * Referenced by: '<S188>/Constant'
   */
  22.0,

  /* Mask Parameter: PrimFailCond_MaxOpVolt
   * Referenced by: '<S199>/Constant'
   */
  22.0,

  /* Mask Parameter: SecFailCond_MaxOpVolt
   * Referenced by: '<S212>/Constant'
   */
  22.0,

  /* Mask Parameter: ANDCond31_MinOpVolt
   * Referenced by: '<S40>/Constant'
   */
  32.0,

  /* Mask Parameter: ANDCond32_MinOpVolt
   * Referenced by: '<S51>/Constant'
   */
  32.0,

  /* Mask Parameter: ANDCond33_MinOpVolt
   * Referenced by: '<S62>/Constant'
   */
  32.0,

  /* Mask Parameter: ANDCond4_MinOpVolt
   * Referenced by: '<S73>/Constant'
   */
  32.0,

  /* Mask Parameter: ANDCond512_MinOpVolt
   * Referenced by: '<S84>/Constant'
   */
  32.0,

  /* Mask Parameter: ANDCond53_MinOpVolt
   * Referenced by: '<S95>/Constant'
   */
  32.0,

  /* Mask Parameter: ANDCond8_MinOpVolt
   * Referenced by: '<S106>/Constant'
   */
  32.0,

  /* Mask Parameter: FAN2PSSwitchRelay_MinOpVolt
   * Referenced by: '<S126>/Constant'
   */
  32.0,

  /* Mask Parameter: ORCond21_MinOpVolt
   * Referenced by: '<S154>/Constant'
   */
  32.0,

  /* Mask Parameter: ORCond22_MinOpVolt
   * Referenced by: '<S165>/Constant'
   */
  32.0,

  /* Mask Parameter: ORCond71_MinOpVolt
   * Referenced by: '<S176>/Constant'
   */
  32.0,

  /* Mask Parameter: ORCond72_MinOpVolt
   * Referenced by: '<S187>/Constant'
   */
  32.0,

  /* Mask Parameter: PrimFailCond_MinOpVolt
   * Referenced by: '<S198>/Constant'
   */
  32.0,

  /* Mask Parameter: SecFailCond_MinOpVolt
   * Referenced by: '<S211>/Constant'
   */
  32.0,

  /* Mask Parameter: CompareToConstant2_const
   * Referenced by: '<S42>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const
   * Referenced by: '<S43>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_p
   * Referenced by: '<S53>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_e
   * Referenced by: '<S54>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_f
   * Referenced by: '<S64>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_eo
   * Referenced by: '<S65>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_n
   * Referenced by: '<S75>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_i
   * Referenced by: '<S76>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_p2
   * Referenced by: '<S86>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_j
   * Referenced by: '<S87>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_k
   * Referenced by: '<S97>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_en
   * Referenced by: '<S98>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_l
   * Referenced by: '<S108>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_c
   * Referenced by: '<S109>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_h
   * Referenced by: '<S128>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_a
   * Referenced by: '<S129>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_o
   * Referenced by: '<S156>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_io
   * Referenced by: '<S157>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_nq
   * Referenced by: '<S167>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_p
   * Referenced by: '<S168>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_i
   * Referenced by: '<S178>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_o
   * Referenced by: '<S179>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_kk
   * Referenced by: '<S189>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_g
   * Referenced by: '<S190>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_in
   * Referenced by: '<S200>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_ca
   * Referenced by: '<S201>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant2_const_m
   * Referenced by: '<S213>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant3_const_em
   * Referenced by: '<S214>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S116>/Constant'
   */
  22.0,

  /* Mask Parameter: CompareToConstant_const_h
   * Referenced by: '<S119>/Constant'
   */
  22.0,

  /* Mask Parameter: CompareToConstant_const_d
   * Referenced by: '<S122>/Constant'
   */
  22.0,

  /* Mask Parameter: CompareToConstant_const_l
   * Referenced by: '<S142>/Constant'
   */
  22.0,

  /* Mask Parameter: CompareToConstant1_const
   * Referenced by: '<S143>/Constant'
   */
  22.0,

  /* Mask Parameter: CompareToConstant2_const_d
   * Referenced by: '<S144>/Constant'
   */
  22.0,

  /* Expression: 0
   * Referenced by: '<S39>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S50>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S61>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S72>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S83>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S94>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S105>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S125>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S125>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S8>/Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S9>/Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S10>/Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S153>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S164>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S175>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S186>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S197>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S210>/Switch'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S153>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S164>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S39>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S50>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S61>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S72>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S83>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S94>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S175>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S186>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S105>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S197>/Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S210>/Memory1'
   */
  0.0,

  /* Expression: 2
   * Referenced by: '<S15>/Multiply'
   */
  2.0,

  /* Expression: 3
   * Referenced by: '<S15>/Multiply1'
   */
  3.0,

  /* Computed Parameter: Memory_InitialCondition
   * Referenced by: '<S39>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_h
   * Referenced by: '<S50>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_b
   * Referenced by: '<S61>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_j
   * Referenced by: '<S72>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_p
   * Referenced by: '<S83>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_f
   * Referenced by: '<S94>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_k
   * Referenced by: '<S105>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_kj
   * Referenced by: '<S125>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_m
   * Referenced by: '<S153>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_n
   * Referenced by: '<S164>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_i
   * Referenced by: '<S175>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_me
   * Referenced by: '<S186>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_jd
   * Referenced by: '<S197>/Memory'
   */
  0,

  /* Computed Parameter: Memory_InitialCondition_d
   * Referenced by: '<S210>/Memory'
   */
  0
};
