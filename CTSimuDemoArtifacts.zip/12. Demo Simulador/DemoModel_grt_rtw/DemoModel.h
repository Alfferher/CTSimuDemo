/*
 * DemoModel.h
 *
 * Code generation for model "DemoModel".
 *
 * Model version              : 1.69
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Sun Feb 21 10:18:30 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_DemoModel_h_
#define RTW_HEADER_DemoModel_h_
#include <cmath>
#include <cstring>
#include <cfloat>
#include <stddef.h>
#ifndef DemoModel_COMMON_INCLUDES_
# define DemoModel_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#include "nesl_rtw.h"
#include "DemoModel_1d0f24d5_1_gateway.h"
#endif                                 /* DemoModel_COMMON_INCLUDES_ */

#include "DemoModel_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Sum;                          /* '<S39>/Sum' */
  real_T CastToDouble1;                /* '<S39>/Cast To Double1' */
  real_T INPUT_2_1_1[4];               /* '<S223>/INPUT_2_1_1' */
  real_T INPUT_2_2_1[4];               /* '<S223>/INPUT_2_2_1' */
  real_T INPUT_1_1_1[4];               /* '<S223>/INPUT_1_1_1' */
  real_T INPUT_1_2_1[4];               /* '<S223>/INPUT_1_2_1' */
  real_T Sum_j;                        /* '<S50>/Sum' */
  real_T CastToDouble1_o;              /* '<S50>/Cast To Double1' */
  real_T INPUT_4_1_1[4];               /* '<S223>/INPUT_4_1_1' */
  real_T INPUT_3_1_1[4];               /* '<S223>/INPUT_3_1_1' */
  real_T Sum_p;                        /* '<S61>/Sum' */
  real_T CastToDouble1_e;              /* '<S61>/Cast To Double1' */
  real_T INPUT_6_1_1[4];               /* '<S223>/INPUT_6_1_1' */
  real_T INPUT_6_2_1[4];               /* '<S223>/INPUT_6_2_1' */
  real_T INPUT_5_1_1[4];               /* '<S223>/INPUT_5_1_1' */
  real_T INPUT_5_2_1[4];               /* '<S223>/INPUT_5_2_1' */
  real_T Sum_e;                        /* '<S72>/Sum' */
  real_T CastToDouble1_m;              /* '<S72>/Cast To Double1' */
  real_T INPUT_8_1_1[4];               /* '<S223>/INPUT_8_1_1' */
  real_T INPUT_7_1_1[4];               /* '<S223>/INPUT_7_1_1' */
  real_T Sum_m;                        /* '<S83>/Sum' */
  real_T CastToDouble1_ew;             /* '<S83>/Cast To Double1' */
  real_T INPUT_10_1_1[4];              /* '<S223>/INPUT_10_1_1' */
  real_T INPUT_9_1_1[4];               /* '<S223>/INPUT_9_1_1' */
  real_T Sum_h;                        /* '<S94>/Sum' */
  real_T CastToDouble1_h;              /* '<S94>/Cast To Double1' */
  real_T INPUT_12_1_1[4];              /* '<S223>/INPUT_12_1_1' */
  real_T INPUT_11_1_1[4];              /* '<S223>/INPUT_11_1_1' */
  real_T Sum_d;                        /* '<S105>/Sum' */
  real_T CastToDouble1_mt;             /* '<S105>/Cast To Double1' */
  real_T INPUT_14_1_1[4];              /* '<S223>/INPUT_14_1_1' */
  real_T INPUT_13_1_1[4];              /* '<S223>/INPUT_13_1_1' */
  real_T Sum_l;                        /* '<S125>/Sum' */
  real_T CastToDouble1_c;              /* '<S125>/Cast To Double1' */
  real_T INPUT_16_1_1[4];              /* '<S223>/INPUT_16_1_1' */
  real_T INPUT_15_1_1[4];              /* '<S223>/INPUT_15_1_1' */
  real_T CastToDouble;                 /* '<S12>/Cast To Double' */
  real_T INPUT_17_1_1[4];              /* '<S223>/INPUT_17_1_1' */
  real_T CastToDouble_b;               /* '<S13>/Cast To Double' */
  real_T INPUT_18_1_1[4];              /* '<S223>/INPUT_18_1_1' */
  real_T CastToDouble_h;               /* '<S14>/Cast To Double' */
  real_T INPUT_19_1_1[4];              /* '<S223>/INPUT_19_1_1' */
  real_T INPUT_20_1_1[4];              /* '<S223>/INPUT_20_1_1' */
  real_T INPUT_20_2_1[4];              /* '<S223>/INPUT_20_2_1' */
  real_T Sum_ec;                       /* '<S153>/Sum' */
  real_T CastToDouble1_oj;             /* '<S153>/Cast To Double1' */
  real_T INPUT_22_1_1[4];              /* '<S223>/INPUT_22_1_1' */
  real_T INPUT_21_1_1[4];              /* '<S223>/INPUT_21_1_1' */
  real_T Sum_pp;                       /* '<S164>/Sum' */
  real_T CastToDouble1_k;              /* '<S164>/Cast To Double1' */
  real_T INPUT_24_1_1[4];              /* '<S223>/INPUT_24_1_1' */
  real_T INPUT_24_2_1[4];              /* '<S223>/INPUT_24_2_1' */
  real_T INPUT_23_1_1[4];              /* '<S223>/INPUT_23_1_1' */
  real_T INPUT_23_2_1[4];              /* '<S223>/INPUT_23_2_1' */
  real_T Sum_i;                        /* '<S175>/Sum' */
  real_T CastToDouble1_hk;             /* '<S175>/Cast To Double1' */
  real_T INPUT_26_1_1[4];              /* '<S223>/INPUT_26_1_1' */
  real_T INPUT_25_1_1[4];              /* '<S223>/INPUT_25_1_1' */
  real_T Sum_lw;                       /* '<S186>/Sum' */
  real_T CastToDouble1_em;             /* '<S186>/Cast To Double1' */
  real_T INPUT_28_1_1[4];              /* '<S223>/INPUT_28_1_1' */
  real_T INPUT_27_1_1[4];              /* '<S223>/INPUT_27_1_1' */
  real_T Sum_dl;                       /* '<S197>/Sum' */
  real_T CastToDouble1_d;              /* '<S197>/Cast To Double1' */
  real_T INPUT_30_1_1[4];              /* '<S223>/INPUT_30_1_1' */
  real_T INPUT_29_1_1[4];              /* '<S223>/INPUT_29_1_1' */
  real_T INPUT_31_1_1[4];              /* '<S223>/INPUT_31_1_1' */
  real_T Sum_o;                        /* '<S210>/Sum' */
  real_T CastToDouble1_b;              /* '<S210>/Cast To Double1' */
  real_T INPUT_33_1_1[4];              /* '<S223>/INPUT_33_1_1' */
  real_T INPUT_32_1_1[4];              /* '<S223>/INPUT_32_1_1' */
  real_T INPUT_34_1_1[4];              /* '<S223>/INPUT_34_1_1' */
  real_T INPUT_35_1_1[4];              /* '<S223>/INPUT_35_1_1' */
  real_T INPUT_36_1_1[4];              /* '<S223>/INPUT_36_1_1' */
  real_T INPUT_37_1_1[4];              /* '<S223>/INPUT_37_1_1' */
  real_T INPUT_38_1_1[4];              /* '<S223>/INPUT_38_1_1' */
  real_T INPUT_39_1_1[4];              /* '<S223>/INPUT_39_1_1' */
  real_T STATE_1[138];                 /* '<S223>/STATE_1' */
  real_T CastToDouble_e;               /* '<S8>/Cast To Double' */
  real_T CastToDouble_j;               /* '<S9>/Cast To Double' */
  real_T CastToDouble_f;               /* '<S10>/Cast To Double' */
  boolean_T AND;                       /* '<S39>/AND' */
  boolean_T AND_p;                     /* '<S50>/AND' */
  boolean_T AND_j;                     /* '<S61>/AND' */
  boolean_T AND_a;                     /* '<S72>/AND' */
  boolean_T AND_l;                     /* '<S83>/AND' */
  boolean_T AND_ps;                    /* '<S94>/AND' */
  boolean_T AND_e;                     /* '<S105>/AND' */
  boolean_T AND_h;                     /* '<S125>/AND' */
  boolean_T AND_m;                     /* '<S153>/AND' */
  boolean_T AND_i;                     /* '<S164>/AND' */
  boolean_T AND_hr;                    /* '<S175>/AND' */
  boolean_T AND_ew;                    /* '<S186>/AND' */
  boolean_T AND_pl;                    /* '<S197>/AND' */
  boolean_T AND_hl;                    /* '<S210>/AND' */
} B_DemoModel_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T INPUT_2_1_1_Discrete[2];      /* '<S223>/INPUT_2_1_1' */
  real_T INPUT_2_2_1_Discrete[2];      /* '<S223>/INPUT_2_2_1' */
  real_T INPUT_1_1_1_Discrete[2];      /* '<S223>/INPUT_1_1_1' */
  real_T INPUT_1_2_1_Discrete[2];      /* '<S223>/INPUT_1_2_1' */
  real_T INPUT_4_1_1_Discrete[2];      /* '<S223>/INPUT_4_1_1' */
  real_T INPUT_3_1_1_Discrete[2];      /* '<S223>/INPUT_3_1_1' */
  real_T INPUT_6_1_1_Discrete[2];      /* '<S223>/INPUT_6_1_1' */
  real_T INPUT_6_2_1_Discrete[2];      /* '<S223>/INPUT_6_2_1' */
  real_T INPUT_5_1_1_Discrete[2];      /* '<S223>/INPUT_5_1_1' */
  real_T INPUT_5_2_1_Discrete[2];      /* '<S223>/INPUT_5_2_1' */
  real_T INPUT_8_1_1_Discrete[2];      /* '<S223>/INPUT_8_1_1' */
  real_T INPUT_7_1_1_Discrete[2];      /* '<S223>/INPUT_7_1_1' */
  real_T INPUT_10_1_1_Discrete[2];     /* '<S223>/INPUT_10_1_1' */
  real_T INPUT_9_1_1_Discrete[2];      /* '<S223>/INPUT_9_1_1' */
  real_T INPUT_12_1_1_Discrete[2];     /* '<S223>/INPUT_12_1_1' */
  real_T INPUT_11_1_1_Discrete[2];     /* '<S223>/INPUT_11_1_1' */
  real_T INPUT_14_1_1_Discrete[2];     /* '<S223>/INPUT_14_1_1' */
  real_T INPUT_13_1_1_Discrete[2];     /* '<S223>/INPUT_13_1_1' */
  real_T INPUT_16_1_1_Discrete[2];     /* '<S223>/INPUT_16_1_1' */
  real_T INPUT_15_1_1_Discrete[2];     /* '<S223>/INPUT_15_1_1' */
  real_T Delay_DSTATE;                 /* '<S8>/Delay' */
  real_T INPUT_17_1_1_Discrete[2];     /* '<S223>/INPUT_17_1_1' */
  real_T Delay_DSTATE_o;               /* '<S9>/Delay' */
  real_T INPUT_18_1_1_Discrete[2];     /* '<S223>/INPUT_18_1_1' */
  real_T Delay_DSTATE_c;               /* '<S10>/Delay' */
  real_T INPUT_19_1_1_Discrete[2];     /* '<S223>/INPUT_19_1_1' */
  real_T INPUT_20_1_1_Discrete[2];     /* '<S223>/INPUT_20_1_1' */
  real_T INPUT_20_2_1_Discrete[2];     /* '<S223>/INPUT_20_2_1' */
  real_T INPUT_22_1_1_Discrete[2];     /* '<S223>/INPUT_22_1_1' */
  real_T INPUT_21_1_1_Discrete[2];     /* '<S223>/INPUT_21_1_1' */
  real_T INPUT_24_1_1_Discrete[2];     /* '<S223>/INPUT_24_1_1' */
  real_T INPUT_24_2_1_Discrete[2];     /* '<S223>/INPUT_24_2_1' */
  real_T INPUT_23_1_1_Discrete[2];     /* '<S223>/INPUT_23_1_1' */
  real_T INPUT_23_2_1_Discrete[2];     /* '<S223>/INPUT_23_2_1' */
  real_T INPUT_26_1_1_Discrete[2];     /* '<S223>/INPUT_26_1_1' */
  real_T INPUT_25_1_1_Discrete[2];     /* '<S223>/INPUT_25_1_1' */
  real_T INPUT_28_1_1_Discrete[2];     /* '<S223>/INPUT_28_1_1' */
  real_T INPUT_27_1_1_Discrete[2];     /* '<S223>/INPUT_27_1_1' */
  real_T INPUT_30_1_1_Discrete[2];     /* '<S223>/INPUT_30_1_1' */
  real_T INPUT_29_1_1_Discrete[2];     /* '<S223>/INPUT_29_1_1' */
  real_T INPUT_31_1_1_Discrete[2];     /* '<S223>/INPUT_31_1_1' */
  real_T INPUT_33_1_1_Discrete[2];     /* '<S223>/INPUT_33_1_1' */
  real_T INPUT_32_1_1_Discrete[2];     /* '<S223>/INPUT_32_1_1' */
  real_T INPUT_34_1_1_Discrete[2];     /* '<S223>/INPUT_34_1_1' */
  real_T INPUT_35_1_1_Discrete[2];     /* '<S223>/INPUT_35_1_1' */
  real_T INPUT_36_1_1_Discrete[2];     /* '<S223>/INPUT_36_1_1' */
  real_T INPUT_37_1_1_Discrete[2];     /* '<S223>/INPUT_37_1_1' */
  real_T INPUT_38_1_1_Discrete[2];     /* '<S223>/INPUT_38_1_1' */
  real_T INPUT_39_1_1_Discrete[2];     /* '<S223>/INPUT_39_1_1' */
  real_T STATE_1_Discrete[92];         /* '<S223>/STATE_1' */
  real_T Memory1_PreviousInput;        /* '<S125>/Memory1' */
  real_T OUTPUT_1_0_Discrete;          /* '<S223>/OUTPUT_1_0' */
  real_T Memory1_PreviousInput_o;      /* '<S153>/Memory1' */
  real_T Memory1_PreviousInput_h;      /* '<S164>/Memory1' */
  real_T Memory1_PreviousInput_n;      /* '<S39>/Memory1' */
  real_T Memory1_PreviousInput_nz;     /* '<S50>/Memory1' */
  real_T Memory1_PreviousInput_g;      /* '<S61>/Memory1' */
  real_T Memory1_PreviousInput_p;      /* '<S72>/Memory1' */
  real_T Memory1_PreviousInput_k;      /* '<S83>/Memory1' */
  real_T Memory1_PreviousInput_d;      /* '<S94>/Memory1' */
  real_T Memory1_PreviousInput_j;      /* '<S175>/Memory1' */
  real_T Memory1_PreviousInput_nm;     /* '<S186>/Memory1' */
  real_T Memory1_PreviousInput_e;      /* '<S105>/Memory1' */
  real_T Memory1_PreviousInput_gf;     /* '<S197>/Memory1' */
  real_T Memory1_PreviousInput_p2;     /* '<S210>/Memory1' */
  void* STATE_1_Simulator;             /* '<S223>/STATE_1' */
  void* STATE_1_SimData;               /* '<S223>/STATE_1' */
  void* STATE_1_DiagMgr;               /* '<S223>/STATE_1' */
  void* STATE_1_ZcLogger;              /* '<S223>/STATE_1' */
  void* STATE_1_TsIndex;               /* '<S223>/STATE_1' */
  void* OUTPUT_1_0_Simulator;          /* '<S223>/OUTPUT_1_0' */
  void* OUTPUT_1_0_SimData;            /* '<S223>/OUTPUT_1_0' */
  void* OUTPUT_1_0_DiagMgr;            /* '<S223>/OUTPUT_1_0' */
  void* OUTPUT_1_0_ZcLogger;           /* '<S223>/OUTPUT_1_0' */
  void* OUTPUT_1_0_TsIndex;            /* '<S223>/OUTPUT_1_0' */
  int_T STATE_1_Modes[46];             /* '<S223>/STATE_1' */
  int_T OUTPUT_1_0_Modes;              /* '<S223>/OUTPUT_1_0' */
  boolean_T Memory_PreviousInput;      /* '<S39>/Memory' */
  boolean_T Memory_PreviousInput_p;    /* '<S50>/Memory' */
  boolean_T Memory_PreviousInput_k;    /* '<S61>/Memory' */
  boolean_T Memory_PreviousInput_pe;   /* '<S72>/Memory' */
  boolean_T Memory_PreviousInput_a;    /* '<S83>/Memory' */
  boolean_T Memory_PreviousInput_d;    /* '<S94>/Memory' */
  boolean_T Memory_PreviousInput_pd;   /* '<S105>/Memory' */
  boolean_T Memory_PreviousInput_n;    /* '<S125>/Memory' */
  boolean_T Memory_PreviousInput_px;   /* '<S153>/Memory' */
  boolean_T Memory_PreviousInput_e;    /* '<S164>/Memory' */
  boolean_T Memory_PreviousInput_j;    /* '<S175>/Memory' */
  boolean_T Memory_PreviousInput_nm;   /* '<S186>/Memory' */
  boolean_T Memory_PreviousInput_jl;   /* '<S197>/Memory' */
  boolean_T Memory_PreviousInput_c;    /* '<S210>/Memory' */
  boolean_T STATE_1_FirstOutput;       /* '<S223>/STATE_1' */
  boolean_T OUTPUT_1_0_FirstOutput;    /* '<S223>/OUTPUT_1_0' */
} DW_DemoModel_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  SysCmd SysCmd_i;                     /* '<Root>/SysCmd' */
  SysFailCmd SysFailCmd_l;             /* '<Root>/SysFailCmd' */
  RelayFailCmd RelayFailCmd_i;         /* '<Root>/RelayFailCmd' */
} ExtU_DemoModel_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  FANState FANState_b;                 /* '<Root>/FANState' */
  RelayState RelayState_k;             /* '<Root>/RelayState' */
  SysState SysState_o;                 /* '<Root>/SysState' */
} ExtY_DemoModel_T;

/* Parameters (default storage) */
struct P_DemoModel_T_ {
  real_T ANDCond31_MaxOpVolt;          /* Mask Parameter: ANDCond31_MaxOpVolt
                                        * Referenced by: '<S41>/Constant'
                                        */
  real_T ANDCond32_MaxOpVolt;          /* Mask Parameter: ANDCond32_MaxOpVolt
                                        * Referenced by: '<S52>/Constant'
                                        */
  real_T ANDCond33_MaxOpVolt;          /* Mask Parameter: ANDCond33_MaxOpVolt
                                        * Referenced by: '<S63>/Constant'
                                        */
  real_T ANDCond4_MaxOpVolt;           /* Mask Parameter: ANDCond4_MaxOpVolt
                                        * Referenced by: '<S74>/Constant'
                                        */
  real_T ANDCond512_MaxOpVolt;         /* Mask Parameter: ANDCond512_MaxOpVolt
                                        * Referenced by: '<S85>/Constant'
                                        */
  real_T ANDCond53_MaxOpVolt;          /* Mask Parameter: ANDCond53_MaxOpVolt
                                        * Referenced by: '<S96>/Constant'
                                        */
  real_T ANDCond8_MaxOpVolt;           /* Mask Parameter: ANDCond8_MaxOpVolt
                                        * Referenced by: '<S107>/Constant'
                                        */
  real_T FAN2PSSwitchRelay_MaxOpVolt;
                                  /* Mask Parameter: FAN2PSSwitchRelay_MaxOpVolt
                                   * Referenced by: '<S127>/Constant'
                                   */
  real_T ORCond21_MaxOpVolt;           /* Mask Parameter: ORCond21_MaxOpVolt
                                        * Referenced by: '<S155>/Constant'
                                        */
  real_T ORCond22_MaxOpVolt;           /* Mask Parameter: ORCond22_MaxOpVolt
                                        * Referenced by: '<S166>/Constant'
                                        */
  real_T ORCond71_MaxOpVolt;           /* Mask Parameter: ORCond71_MaxOpVolt
                                        * Referenced by: '<S177>/Constant'
                                        */
  real_T ORCond72_MaxOpVolt;           /* Mask Parameter: ORCond72_MaxOpVolt
                                        * Referenced by: '<S188>/Constant'
                                        */
  real_T PrimFailCond_MaxOpVolt;       /* Mask Parameter: PrimFailCond_MaxOpVolt
                                        * Referenced by: '<S199>/Constant'
                                        */
  real_T SecFailCond_MaxOpVolt;        /* Mask Parameter: SecFailCond_MaxOpVolt
                                        * Referenced by: '<S212>/Constant'
                                        */
  real_T ANDCond31_MinOpVolt;          /* Mask Parameter: ANDCond31_MinOpVolt
                                        * Referenced by: '<S40>/Constant'
                                        */
  real_T ANDCond32_MinOpVolt;          /* Mask Parameter: ANDCond32_MinOpVolt
                                        * Referenced by: '<S51>/Constant'
                                        */
  real_T ANDCond33_MinOpVolt;          /* Mask Parameter: ANDCond33_MinOpVolt
                                        * Referenced by: '<S62>/Constant'
                                        */
  real_T ANDCond4_MinOpVolt;           /* Mask Parameter: ANDCond4_MinOpVolt
                                        * Referenced by: '<S73>/Constant'
                                        */
  real_T ANDCond512_MinOpVolt;         /* Mask Parameter: ANDCond512_MinOpVolt
                                        * Referenced by: '<S84>/Constant'
                                        */
  real_T ANDCond53_MinOpVolt;          /* Mask Parameter: ANDCond53_MinOpVolt
                                        * Referenced by: '<S95>/Constant'
                                        */
  real_T ANDCond8_MinOpVolt;           /* Mask Parameter: ANDCond8_MinOpVolt
                                        * Referenced by: '<S106>/Constant'
                                        */
  real_T FAN2PSSwitchRelay_MinOpVolt;
                                  /* Mask Parameter: FAN2PSSwitchRelay_MinOpVolt
                                   * Referenced by: '<S126>/Constant'
                                   */
  real_T ORCond21_MinOpVolt;           /* Mask Parameter: ORCond21_MinOpVolt
                                        * Referenced by: '<S154>/Constant'
                                        */
  real_T ORCond22_MinOpVolt;           /* Mask Parameter: ORCond22_MinOpVolt
                                        * Referenced by: '<S165>/Constant'
                                        */
  real_T ORCond71_MinOpVolt;           /* Mask Parameter: ORCond71_MinOpVolt
                                        * Referenced by: '<S176>/Constant'
                                        */
  real_T ORCond72_MinOpVolt;           /* Mask Parameter: ORCond72_MinOpVolt
                                        * Referenced by: '<S187>/Constant'
                                        */
  real_T PrimFailCond_MinOpVolt;       /* Mask Parameter: PrimFailCond_MinOpVolt
                                        * Referenced by: '<S198>/Constant'
                                        */
  real_T SecFailCond_MinOpVolt;        /* Mask Parameter: SecFailCond_MinOpVolt
                                        * Referenced by: '<S211>/Constant'
                                        */
  real_T CompareToConstant2_const;   /* Mask Parameter: CompareToConstant2_const
                                      * Referenced by: '<S42>/Constant'
                                      */
  real_T CompareToConstant3_const;   /* Mask Parameter: CompareToConstant3_const
                                      * Referenced by: '<S43>/Constant'
                                      */
  real_T CompareToConstant2_const_p;
                                   /* Mask Parameter: CompareToConstant2_const_p
                                    * Referenced by: '<S53>/Constant'
                                    */
  real_T CompareToConstant3_const_e;
                                   /* Mask Parameter: CompareToConstant3_const_e
                                    * Referenced by: '<S54>/Constant'
                                    */
  real_T CompareToConstant2_const_f;
                                   /* Mask Parameter: CompareToConstant2_const_f
                                    * Referenced by: '<S64>/Constant'
                                    */
  real_T CompareToConstant3_const_eo;
                                  /* Mask Parameter: CompareToConstant3_const_eo
                                   * Referenced by: '<S65>/Constant'
                                   */
  real_T CompareToConstant2_const_n;
                                   /* Mask Parameter: CompareToConstant2_const_n
                                    * Referenced by: '<S75>/Constant'
                                    */
  real_T CompareToConstant3_const_i;
                                   /* Mask Parameter: CompareToConstant3_const_i
                                    * Referenced by: '<S76>/Constant'
                                    */
  real_T CompareToConstant2_const_p2;
                                  /* Mask Parameter: CompareToConstant2_const_p2
                                   * Referenced by: '<S86>/Constant'
                                   */
  real_T CompareToConstant3_const_j;
                                   /* Mask Parameter: CompareToConstant3_const_j
                                    * Referenced by: '<S87>/Constant'
                                    */
  real_T CompareToConstant2_const_k;
                                   /* Mask Parameter: CompareToConstant2_const_k
                                    * Referenced by: '<S97>/Constant'
                                    */
  real_T CompareToConstant3_const_en;
                                  /* Mask Parameter: CompareToConstant3_const_en
                                   * Referenced by: '<S98>/Constant'
                                   */
  real_T CompareToConstant2_const_l;
                                   /* Mask Parameter: CompareToConstant2_const_l
                                    * Referenced by: '<S108>/Constant'
                                    */
  real_T CompareToConstant3_const_c;
                                   /* Mask Parameter: CompareToConstant3_const_c
                                    * Referenced by: '<S109>/Constant'
                                    */
  real_T CompareToConstant2_const_h;
                                   /* Mask Parameter: CompareToConstant2_const_h
                                    * Referenced by: '<S128>/Constant'
                                    */
  real_T CompareToConstant3_const_a;
                                   /* Mask Parameter: CompareToConstant3_const_a
                                    * Referenced by: '<S129>/Constant'
                                    */
  real_T CompareToConstant2_const_o;
                                   /* Mask Parameter: CompareToConstant2_const_o
                                    * Referenced by: '<S156>/Constant'
                                    */
  real_T CompareToConstant3_const_io;
                                  /* Mask Parameter: CompareToConstant3_const_io
                                   * Referenced by: '<S157>/Constant'
                                   */
  real_T CompareToConstant2_const_nq;
                                  /* Mask Parameter: CompareToConstant2_const_nq
                                   * Referenced by: '<S167>/Constant'
                                   */
  real_T CompareToConstant3_const_p;
                                   /* Mask Parameter: CompareToConstant3_const_p
                                    * Referenced by: '<S168>/Constant'
                                    */
  real_T CompareToConstant2_const_i;
                                   /* Mask Parameter: CompareToConstant2_const_i
                                    * Referenced by: '<S178>/Constant'
                                    */
  real_T CompareToConstant3_const_o;
                                   /* Mask Parameter: CompareToConstant3_const_o
                                    * Referenced by: '<S179>/Constant'
                                    */
  real_T CompareToConstant2_const_kk;
                                  /* Mask Parameter: CompareToConstant2_const_kk
                                   * Referenced by: '<S189>/Constant'
                                   */
  real_T CompareToConstant3_const_g;
                                   /* Mask Parameter: CompareToConstant3_const_g
                                    * Referenced by: '<S190>/Constant'
                                    */
  real_T CompareToConstant2_const_in;
                                  /* Mask Parameter: CompareToConstant2_const_in
                                   * Referenced by: '<S200>/Constant'
                                   */
  real_T CompareToConstant3_const_ca;
                                  /* Mask Parameter: CompareToConstant3_const_ca
                                   * Referenced by: '<S201>/Constant'
                                   */
  real_T CompareToConstant2_const_m;
                                   /* Mask Parameter: CompareToConstant2_const_m
                                    * Referenced by: '<S213>/Constant'
                                    */
  real_T CompareToConstant3_const_em;
                                  /* Mask Parameter: CompareToConstant3_const_em
                                   * Referenced by: '<S214>/Constant'
                                   */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S116>/Constant'
                                       */
  real_T CompareToConstant_const_h; /* Mask Parameter: CompareToConstant_const_h
                                     * Referenced by: '<S119>/Constant'
                                     */
  real_T CompareToConstant_const_d; /* Mask Parameter: CompareToConstant_const_d
                                     * Referenced by: '<S122>/Constant'
                                     */
  real_T CompareToConstant_const_l; /* Mask Parameter: CompareToConstant_const_l
                                     * Referenced by: '<S142>/Constant'
                                     */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S143>/Constant'
                                      */
  real_T CompareToConstant2_const_d;
                                   /* Mask Parameter: CompareToConstant2_const_d
                                    * Referenced by: '<S144>/Constant'
                                    */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S39>/Switch'
                                        */
  real_T Switch_Threshold_a;           /* Expression: 0
                                        * Referenced by: '<S50>/Switch'
                                        */
  real_T Switch_Threshold_n;           /* Expression: 0
                                        * Referenced by: '<S61>/Switch'
                                        */
  real_T Switch_Threshold_l;           /* Expression: 0
                                        * Referenced by: '<S72>/Switch'
                                        */
  real_T Switch_Threshold_o;           /* Expression: 0
                                        * Referenced by: '<S83>/Switch'
                                        */
  real_T Switch_Threshold_g;           /* Expression: 0
                                        * Referenced by: '<S94>/Switch'
                                        */
  real_T Switch_Threshold_op;          /* Expression: 0
                                        * Referenced by: '<S105>/Switch'
                                        */
  real_T Memory1_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S125>/Memory1'
                                        */
  real_T Switch_Threshold_e;           /* Expression: 0
                                        * Referenced by: '<S125>/Switch'
                                        */
  real_T Delay_InitialCondition;       /* Expression: 0
                                        * Referenced by: '<S8>/Delay'
                                        */
  real_T Delay_InitialCondition_h;     /* Expression: 0
                                        * Referenced by: '<S9>/Delay'
                                        */
  real_T Delay_InitialCondition_d;     /* Expression: 0
                                        * Referenced by: '<S10>/Delay'
                                        */
  real_T Switch_Threshold_m;           /* Expression: 0
                                        * Referenced by: '<S153>/Switch'
                                        */
  real_T Switch_Threshold_o0;          /* Expression: 0
                                        * Referenced by: '<S164>/Switch'
                                        */
  real_T Switch_Threshold_ad;          /* Expression: 0
                                        * Referenced by: '<S175>/Switch'
                                        */
  real_T Switch_Threshold_k;           /* Expression: 0
                                        * Referenced by: '<S186>/Switch'
                                        */
  real_T Switch_Threshold_f;           /* Expression: 0
                                        * Referenced by: '<S197>/Switch'
                                        */
  real_T Switch_Threshold_ko;          /* Expression: 0
                                        * Referenced by: '<S210>/Switch'
                                        */
  real_T Memory1_InitialCondition_m;   /* Expression: 0
                                        * Referenced by: '<S153>/Memory1'
                                        */
  real_T Memory1_InitialCondition_h;   /* Expression: 0
                                        * Referenced by: '<S164>/Memory1'
                                        */
  real_T Memory1_InitialCondition_d;   /* Expression: 0
                                        * Referenced by: '<S39>/Memory1'
                                        */
  real_T Memory1_InitialCondition_g;   /* Expression: 0
                                        * Referenced by: '<S50>/Memory1'
                                        */
  real_T Memory1_InitialCondition_dv;  /* Expression: 0
                                        * Referenced by: '<S61>/Memory1'
                                        */
  real_T Memory1_InitialCondition_i;   /* Expression: 0
                                        * Referenced by: '<S72>/Memory1'
                                        */
  real_T Memory1_InitialCondition_c;   /* Expression: 0
                                        * Referenced by: '<S83>/Memory1'
                                        */
  real_T Memory1_InitialCondition_o;   /* Expression: 0
                                        * Referenced by: '<S94>/Memory1'
                                        */
  real_T Memory1_InitialCondition_l;   /* Expression: 0
                                        * Referenced by: '<S175>/Memory1'
                                        */
  real_T Memory1_InitialCondition_da;  /* Expression: 0
                                        * Referenced by: '<S186>/Memory1'
                                        */
  real_T Memory1_InitialCondition_mr;  /* Expression: 0
                                        * Referenced by: '<S105>/Memory1'
                                        */
  real_T Memory1_InitialCondition_ms;  /* Expression: 0
                                        * Referenced by: '<S197>/Memory1'
                                        */
  real_T Memory1_InitialCondition_a;   /* Expression: 0
                                        * Referenced by: '<S210>/Memory1'
                                        */
  real_T Multiply_Gain;                /* Expression: 2
                                        * Referenced by: '<S15>/Multiply'
                                        */
  real_T Multiply1_Gain;               /* Expression: 3
                                        * Referenced by: '<S15>/Multiply1'
                                        */
  boolean_T Memory_InitialCondition;
                                  /* Computed Parameter: Memory_InitialCondition
                                   * Referenced by: '<S39>/Memory'
                                   */
  boolean_T Memory_InitialCondition_h;
                                /* Computed Parameter: Memory_InitialCondition_h
                                 * Referenced by: '<S50>/Memory'
                                 */
  boolean_T Memory_InitialCondition_b;
                                /* Computed Parameter: Memory_InitialCondition_b
                                 * Referenced by: '<S61>/Memory'
                                 */
  boolean_T Memory_InitialCondition_j;
                                /* Computed Parameter: Memory_InitialCondition_j
                                 * Referenced by: '<S72>/Memory'
                                 */
  boolean_T Memory_InitialCondition_p;
                                /* Computed Parameter: Memory_InitialCondition_p
                                 * Referenced by: '<S83>/Memory'
                                 */
  boolean_T Memory_InitialCondition_f;
                                /* Computed Parameter: Memory_InitialCondition_f
                                 * Referenced by: '<S94>/Memory'
                                 */
  boolean_T Memory_InitialCondition_k;
                                /* Computed Parameter: Memory_InitialCondition_k
                                 * Referenced by: '<S105>/Memory'
                                 */
  boolean_T Memory_InitialCondition_kj;
                               /* Computed Parameter: Memory_InitialCondition_kj
                                * Referenced by: '<S125>/Memory'
                                */
  boolean_T Memory_InitialCondition_m;
                                /* Computed Parameter: Memory_InitialCondition_m
                                 * Referenced by: '<S153>/Memory'
                                 */
  boolean_T Memory_InitialCondition_n;
                                /* Computed Parameter: Memory_InitialCondition_n
                                 * Referenced by: '<S164>/Memory'
                                 */
  boolean_T Memory_InitialCondition_i;
                                /* Computed Parameter: Memory_InitialCondition_i
                                 * Referenced by: '<S175>/Memory'
                                 */
  boolean_T Memory_InitialCondition_me;
                               /* Computed Parameter: Memory_InitialCondition_me
                                * Referenced by: '<S186>/Memory'
                                */
  boolean_T Memory_InitialCondition_jd;
                               /* Computed Parameter: Memory_InitialCondition_jd
                                * Referenced by: '<S197>/Memory'
                                */
  boolean_T Memory_InitialCondition_d;
                                /* Computed Parameter: Memory_InitialCondition_d
                                 * Referenced by: '<S210>/Memory'
                                 */
};

/* Real-time Model Data Structure */
struct tag_RTM_DemoModel_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
#ifdef __cplusplus

extern "C" {

#endif

  extern P_DemoModel_T DemoModel_P;

#ifdef __cplusplus

}
#endif

/* Block signals (default storage) */
#ifdef __cplusplus

extern "C" {

#endif

  extern B_DemoModel_T DemoModel_B;

#ifdef __cplusplus

}
#endif

/* Block states (default storage) */
extern DW_DemoModel_T DemoModel_DW;

#ifdef __cplusplus

extern "C" {

#endif

  /* External inputs (root inport signals with default storage) */
  extern ExtU_DemoModel_T DemoModel_U;

  /* External outputs (root outports fed by signals with default storage) */
  extern ExtY_DemoModel_T DemoModel_Y;

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  /* Model entry point functions */
  extern void DemoModel_initialize(void);
  extern void DemoModel_step(void);
  extern void DemoModel_terminate(void);

#ifdef __cplusplus

}
#endif

/* Real-time Model object */
#ifdef __cplusplus

extern "C" {

#endif

  extern RT_MODEL_DemoModel_T *const DemoModel_M;

#ifdef __cplusplus

}
#endif

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'DemoModel'
 * '<S1>'   : 'DemoModel/ANDCond3.1'
 * '<S2>'   : 'DemoModel/ANDCond3.2'
 * '<S3>'   : 'DemoModel/ANDCond3.3'
 * '<S4>'   : 'DemoModel/ANDCond4'
 * '<S5>'   : 'DemoModel/ANDCond5.12'
 * '<S6>'   : 'DemoModel/ANDCond5.3'
 * '<S7>'   : 'DemoModel/ANDCond8'
 * '<S8>'   : 'DemoModel/FAN'
 * '<S9>'   : 'DemoModel/FAN1'
 * '<S10>'  : 'DemoModel/FAN2'
 * '<S11>'  : 'DemoModel/FAN2PSSwitchRelay'
 * '<S12>'  : 'DemoModel/InverseSwitch1'
 * '<S13>'  : 'DemoModel/InverseSwitch2'
 * '<S14>'  : 'DemoModel/InverseSwitch3'
 * '<S15>'  : 'DemoModel/Master'
 * '<S16>'  : 'DemoModel/ORCond2.1'
 * '<S17>'  : 'DemoModel/ORCond2.2'
 * '<S18>'  : 'DemoModel/ORCond7.1'
 * '<S19>'  : 'DemoModel/ORCond7.2'
 * '<S20>'  : 'DemoModel/PrimFailCond'
 * '<S21>'  : 'DemoModel/PrimaryBreaker'
 * '<S22>'  : 'DemoModel/SecFailCond'
 * '<S23>'  : 'DemoModel/Secondary Breaker'
 * '<S24>'  : 'DemoModel/Solver Configuration'
 * '<S25>'  : 'DemoModel/Subsystem'
 * '<S26>'  : 'DemoModel/Subsystem2'
 * '<S27>'  : 'DemoModel/Subsystem5'
 * '<S28>'  : 'DemoModel/Subsystem6'
 * '<S29>'  : 'DemoModel/TermBlock'
 * '<S30>'  : 'DemoModel/TermBlock1'
 * '<S31>'  : 'DemoModel/TermBlock2'
 * '<S32>'  : 'DemoModel/TermBlock3'
 * '<S33>'  : 'DemoModel/TermBlock4'
 * '<S34>'  : 'DemoModel/TermBlock5'
 * '<S35>'  : 'DemoModel/TermBlock6'
 * '<S36>'  : 'DemoModel/TermBlock7'
 * '<S37>'  : 'DemoModel/TermBlock8'
 * '<S38>'  : 'DemoModel/subsystem'
 * '<S39>'  : 'DemoModel/ANDCond3.1/Coil'
 * '<S40>'  : 'DemoModel/ANDCond3.1/Coil/Compare To Constant'
 * '<S41>'  : 'DemoModel/ANDCond3.1/Coil/Compare To Constant1'
 * '<S42>'  : 'DemoModel/ANDCond3.1/Coil/Compare To Constant2'
 * '<S43>'  : 'DemoModel/ANDCond3.1/Coil/Compare To Constant3'
 * '<S44>'  : 'DemoModel/ANDCond3.1/Coil/PS-Simulink Converter'
 * '<S45>'  : 'DemoModel/ANDCond3.1/Coil/Simulink-PS Converter'
 * '<S46>'  : 'DemoModel/ANDCond3.1/Coil/Simulink-PS Converter2'
 * '<S47>'  : 'DemoModel/ANDCond3.1/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S48>'  : 'DemoModel/ANDCond3.1/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S49>'  : 'DemoModel/ANDCond3.1/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S50>'  : 'DemoModel/ANDCond3.2/Coil'
 * '<S51>'  : 'DemoModel/ANDCond3.2/Coil/Compare To Constant'
 * '<S52>'  : 'DemoModel/ANDCond3.2/Coil/Compare To Constant1'
 * '<S53>'  : 'DemoModel/ANDCond3.2/Coil/Compare To Constant2'
 * '<S54>'  : 'DemoModel/ANDCond3.2/Coil/Compare To Constant3'
 * '<S55>'  : 'DemoModel/ANDCond3.2/Coil/PS-Simulink Converter'
 * '<S56>'  : 'DemoModel/ANDCond3.2/Coil/Simulink-PS Converter'
 * '<S57>'  : 'DemoModel/ANDCond3.2/Coil/Simulink-PS Converter2'
 * '<S58>'  : 'DemoModel/ANDCond3.2/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S59>'  : 'DemoModel/ANDCond3.2/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S60>'  : 'DemoModel/ANDCond3.2/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S61>'  : 'DemoModel/ANDCond3.3/Coil'
 * '<S62>'  : 'DemoModel/ANDCond3.3/Coil/Compare To Constant'
 * '<S63>'  : 'DemoModel/ANDCond3.3/Coil/Compare To Constant1'
 * '<S64>'  : 'DemoModel/ANDCond3.3/Coil/Compare To Constant2'
 * '<S65>'  : 'DemoModel/ANDCond3.3/Coil/Compare To Constant3'
 * '<S66>'  : 'DemoModel/ANDCond3.3/Coil/PS-Simulink Converter'
 * '<S67>'  : 'DemoModel/ANDCond3.3/Coil/Simulink-PS Converter'
 * '<S68>'  : 'DemoModel/ANDCond3.3/Coil/Simulink-PS Converter2'
 * '<S69>'  : 'DemoModel/ANDCond3.3/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S70>'  : 'DemoModel/ANDCond3.3/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S71>'  : 'DemoModel/ANDCond3.3/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S72>'  : 'DemoModel/ANDCond4/Coil'
 * '<S73>'  : 'DemoModel/ANDCond4/Coil/Compare To Constant'
 * '<S74>'  : 'DemoModel/ANDCond4/Coil/Compare To Constant1'
 * '<S75>'  : 'DemoModel/ANDCond4/Coil/Compare To Constant2'
 * '<S76>'  : 'DemoModel/ANDCond4/Coil/Compare To Constant3'
 * '<S77>'  : 'DemoModel/ANDCond4/Coil/PS-Simulink Converter'
 * '<S78>'  : 'DemoModel/ANDCond4/Coil/Simulink-PS Converter'
 * '<S79>'  : 'DemoModel/ANDCond4/Coil/Simulink-PS Converter2'
 * '<S80>'  : 'DemoModel/ANDCond4/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S81>'  : 'DemoModel/ANDCond4/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S82>'  : 'DemoModel/ANDCond4/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S83>'  : 'DemoModel/ANDCond5.12/Coil'
 * '<S84>'  : 'DemoModel/ANDCond5.12/Coil/Compare To Constant'
 * '<S85>'  : 'DemoModel/ANDCond5.12/Coil/Compare To Constant1'
 * '<S86>'  : 'DemoModel/ANDCond5.12/Coil/Compare To Constant2'
 * '<S87>'  : 'DemoModel/ANDCond5.12/Coil/Compare To Constant3'
 * '<S88>'  : 'DemoModel/ANDCond5.12/Coil/PS-Simulink Converter'
 * '<S89>'  : 'DemoModel/ANDCond5.12/Coil/Simulink-PS Converter'
 * '<S90>'  : 'DemoModel/ANDCond5.12/Coil/Simulink-PS Converter2'
 * '<S91>'  : 'DemoModel/ANDCond5.12/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S92>'  : 'DemoModel/ANDCond5.12/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S93>'  : 'DemoModel/ANDCond5.12/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S94>'  : 'DemoModel/ANDCond5.3/Coil'
 * '<S95>'  : 'DemoModel/ANDCond5.3/Coil/Compare To Constant'
 * '<S96>'  : 'DemoModel/ANDCond5.3/Coil/Compare To Constant1'
 * '<S97>'  : 'DemoModel/ANDCond5.3/Coil/Compare To Constant2'
 * '<S98>'  : 'DemoModel/ANDCond5.3/Coil/Compare To Constant3'
 * '<S99>'  : 'DemoModel/ANDCond5.3/Coil/PS-Simulink Converter'
 * '<S100>' : 'DemoModel/ANDCond5.3/Coil/Simulink-PS Converter'
 * '<S101>' : 'DemoModel/ANDCond5.3/Coil/Simulink-PS Converter2'
 * '<S102>' : 'DemoModel/ANDCond5.3/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S103>' : 'DemoModel/ANDCond5.3/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S104>' : 'DemoModel/ANDCond5.3/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S105>' : 'DemoModel/ANDCond8/Coil'
 * '<S106>' : 'DemoModel/ANDCond8/Coil/Compare To Constant'
 * '<S107>' : 'DemoModel/ANDCond8/Coil/Compare To Constant1'
 * '<S108>' : 'DemoModel/ANDCond8/Coil/Compare To Constant2'
 * '<S109>' : 'DemoModel/ANDCond8/Coil/Compare To Constant3'
 * '<S110>' : 'DemoModel/ANDCond8/Coil/PS-Simulink Converter'
 * '<S111>' : 'DemoModel/ANDCond8/Coil/Simulink-PS Converter'
 * '<S112>' : 'DemoModel/ANDCond8/Coil/Simulink-PS Converter2'
 * '<S113>' : 'DemoModel/ANDCond8/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S114>' : 'DemoModel/ANDCond8/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S115>' : 'DemoModel/ANDCond8/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S116>' : 'DemoModel/FAN/Compare To Constant'
 * '<S117>' : 'DemoModel/FAN/PS-Simulink Converter'
 * '<S118>' : 'DemoModel/FAN/PS-Simulink Converter/EVAL_KEY'
 * '<S119>' : 'DemoModel/FAN1/Compare To Constant'
 * '<S120>' : 'DemoModel/FAN1/PS-Simulink Converter'
 * '<S121>' : 'DemoModel/FAN1/PS-Simulink Converter/EVAL_KEY'
 * '<S122>' : 'DemoModel/FAN2/Compare To Constant'
 * '<S123>' : 'DemoModel/FAN2/PS-Simulink Converter'
 * '<S124>' : 'DemoModel/FAN2/PS-Simulink Converter/EVAL_KEY'
 * '<S125>' : 'DemoModel/FAN2PSSwitchRelay/Coil'
 * '<S126>' : 'DemoModel/FAN2PSSwitchRelay/Coil/Compare To Constant'
 * '<S127>' : 'DemoModel/FAN2PSSwitchRelay/Coil/Compare To Constant1'
 * '<S128>' : 'DemoModel/FAN2PSSwitchRelay/Coil/Compare To Constant2'
 * '<S129>' : 'DemoModel/FAN2PSSwitchRelay/Coil/Compare To Constant3'
 * '<S130>' : 'DemoModel/FAN2PSSwitchRelay/Coil/PS-Simulink Converter'
 * '<S131>' : 'DemoModel/FAN2PSSwitchRelay/Coil/Simulink-PS Converter'
 * '<S132>' : 'DemoModel/FAN2PSSwitchRelay/Coil/Simulink-PS Converter2'
 * '<S133>' : 'DemoModel/FAN2PSSwitchRelay/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S134>' : 'DemoModel/FAN2PSSwitchRelay/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S135>' : 'DemoModel/FAN2PSSwitchRelay/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S136>' : 'DemoModel/InverseSwitch1/Simulink-PS Converter'
 * '<S137>' : 'DemoModel/InverseSwitch1/Simulink-PS Converter/EVAL_KEY'
 * '<S138>' : 'DemoModel/InverseSwitch2/Simulink-PS Converter'
 * '<S139>' : 'DemoModel/InverseSwitch2/Simulink-PS Converter/EVAL_KEY'
 * '<S140>' : 'DemoModel/InverseSwitch3/Simulink-PS Converter'
 * '<S141>' : 'DemoModel/InverseSwitch3/Simulink-PS Converter/EVAL_KEY'
 * '<S142>' : 'DemoModel/Master/Compare To Constant'
 * '<S143>' : 'DemoModel/Master/Compare To Constant1'
 * '<S144>' : 'DemoModel/Master/Compare To Constant2'
 * '<S145>' : 'DemoModel/Master/PS-Simulink Converter'
 * '<S146>' : 'DemoModel/Master/PS-Simulink Converter1'
 * '<S147>' : 'DemoModel/Master/PS-Simulink Converter2'
 * '<S148>' : 'DemoModel/Master/Simulink-PS Converter'
 * '<S149>' : 'DemoModel/Master/PS-Simulink Converter/EVAL_KEY'
 * '<S150>' : 'DemoModel/Master/PS-Simulink Converter1/EVAL_KEY'
 * '<S151>' : 'DemoModel/Master/PS-Simulink Converter2/EVAL_KEY'
 * '<S152>' : 'DemoModel/Master/Simulink-PS Converter/EVAL_KEY'
 * '<S153>' : 'DemoModel/ORCond2.1/Coil'
 * '<S154>' : 'DemoModel/ORCond2.1/Coil/Compare To Constant'
 * '<S155>' : 'DemoModel/ORCond2.1/Coil/Compare To Constant1'
 * '<S156>' : 'DemoModel/ORCond2.1/Coil/Compare To Constant2'
 * '<S157>' : 'DemoModel/ORCond2.1/Coil/Compare To Constant3'
 * '<S158>' : 'DemoModel/ORCond2.1/Coil/PS-Simulink Converter'
 * '<S159>' : 'DemoModel/ORCond2.1/Coil/Simulink-PS Converter'
 * '<S160>' : 'DemoModel/ORCond2.1/Coil/Simulink-PS Converter2'
 * '<S161>' : 'DemoModel/ORCond2.1/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S162>' : 'DemoModel/ORCond2.1/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S163>' : 'DemoModel/ORCond2.1/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S164>' : 'DemoModel/ORCond2.2/Coil'
 * '<S165>' : 'DemoModel/ORCond2.2/Coil/Compare To Constant'
 * '<S166>' : 'DemoModel/ORCond2.2/Coil/Compare To Constant1'
 * '<S167>' : 'DemoModel/ORCond2.2/Coil/Compare To Constant2'
 * '<S168>' : 'DemoModel/ORCond2.2/Coil/Compare To Constant3'
 * '<S169>' : 'DemoModel/ORCond2.2/Coil/PS-Simulink Converter'
 * '<S170>' : 'DemoModel/ORCond2.2/Coil/Simulink-PS Converter'
 * '<S171>' : 'DemoModel/ORCond2.2/Coil/Simulink-PS Converter2'
 * '<S172>' : 'DemoModel/ORCond2.2/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S173>' : 'DemoModel/ORCond2.2/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S174>' : 'DemoModel/ORCond2.2/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S175>' : 'DemoModel/ORCond7.1/Coil'
 * '<S176>' : 'DemoModel/ORCond7.1/Coil/Compare To Constant'
 * '<S177>' : 'DemoModel/ORCond7.1/Coil/Compare To Constant1'
 * '<S178>' : 'DemoModel/ORCond7.1/Coil/Compare To Constant2'
 * '<S179>' : 'DemoModel/ORCond7.1/Coil/Compare To Constant3'
 * '<S180>' : 'DemoModel/ORCond7.1/Coil/PS-Simulink Converter'
 * '<S181>' : 'DemoModel/ORCond7.1/Coil/Simulink-PS Converter'
 * '<S182>' : 'DemoModel/ORCond7.1/Coil/Simulink-PS Converter2'
 * '<S183>' : 'DemoModel/ORCond7.1/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S184>' : 'DemoModel/ORCond7.1/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S185>' : 'DemoModel/ORCond7.1/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S186>' : 'DemoModel/ORCond7.2/Coil'
 * '<S187>' : 'DemoModel/ORCond7.2/Coil/Compare To Constant'
 * '<S188>' : 'DemoModel/ORCond7.2/Coil/Compare To Constant1'
 * '<S189>' : 'DemoModel/ORCond7.2/Coil/Compare To Constant2'
 * '<S190>' : 'DemoModel/ORCond7.2/Coil/Compare To Constant3'
 * '<S191>' : 'DemoModel/ORCond7.2/Coil/PS-Simulink Converter'
 * '<S192>' : 'DemoModel/ORCond7.2/Coil/Simulink-PS Converter'
 * '<S193>' : 'DemoModel/ORCond7.2/Coil/Simulink-PS Converter2'
 * '<S194>' : 'DemoModel/ORCond7.2/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S195>' : 'DemoModel/ORCond7.2/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S196>' : 'DemoModel/ORCond7.2/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S197>' : 'DemoModel/PrimFailCond/Coil'
 * '<S198>' : 'DemoModel/PrimFailCond/Coil/Compare To Constant'
 * '<S199>' : 'DemoModel/PrimFailCond/Coil/Compare To Constant1'
 * '<S200>' : 'DemoModel/PrimFailCond/Coil/Compare To Constant2'
 * '<S201>' : 'DemoModel/PrimFailCond/Coil/Compare To Constant3'
 * '<S202>' : 'DemoModel/PrimFailCond/Coil/PS-Simulink Converter'
 * '<S203>' : 'DemoModel/PrimFailCond/Coil/Simulink-PS Converter'
 * '<S204>' : 'DemoModel/PrimFailCond/Coil/Simulink-PS Converter2'
 * '<S205>' : 'DemoModel/PrimFailCond/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S206>' : 'DemoModel/PrimFailCond/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S207>' : 'DemoModel/PrimFailCond/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S208>' : 'DemoModel/PrimaryBreaker/Simulink-PS Converter'
 * '<S209>' : 'DemoModel/PrimaryBreaker/Simulink-PS Converter/EVAL_KEY'
 * '<S210>' : 'DemoModel/SecFailCond/Coil'
 * '<S211>' : 'DemoModel/SecFailCond/Coil/Compare To Constant'
 * '<S212>' : 'DemoModel/SecFailCond/Coil/Compare To Constant1'
 * '<S213>' : 'DemoModel/SecFailCond/Coil/Compare To Constant2'
 * '<S214>' : 'DemoModel/SecFailCond/Coil/Compare To Constant3'
 * '<S215>' : 'DemoModel/SecFailCond/Coil/PS-Simulink Converter'
 * '<S216>' : 'DemoModel/SecFailCond/Coil/Simulink-PS Converter'
 * '<S217>' : 'DemoModel/SecFailCond/Coil/Simulink-PS Converter2'
 * '<S218>' : 'DemoModel/SecFailCond/Coil/PS-Simulink Converter/EVAL_KEY'
 * '<S219>' : 'DemoModel/SecFailCond/Coil/Simulink-PS Converter/EVAL_KEY'
 * '<S220>' : 'DemoModel/SecFailCond/Coil/Simulink-PS Converter2/EVAL_KEY'
 * '<S221>' : 'DemoModel/Secondary Breaker/Simulink-PS Converter'
 * '<S222>' : 'DemoModel/Secondary Breaker/Simulink-PS Converter/EVAL_KEY'
 * '<S223>' : 'DemoModel/Solver Configuration/EVAL_KEY'
 * '<S224>' : 'DemoModel/Subsystem/Simulink-PS Converter'
 * '<S225>' : 'DemoModel/Subsystem/Simulink-PS Converter/EVAL_KEY'
 * '<S226>' : 'DemoModel/Subsystem2/Simulink-PS Converter'
 * '<S227>' : 'DemoModel/Subsystem2/Simulink-PS Converter/EVAL_KEY'
 * '<S228>' : 'DemoModel/Subsystem5/Simulink-PS Converter'
 * '<S229>' : 'DemoModel/Subsystem5/Simulink-PS Converter/EVAL_KEY'
 * '<S230>' : 'DemoModel/Subsystem6/Simulink-PS Converter'
 * '<S231>' : 'DemoModel/Subsystem6/Simulink-PS Converter/EVAL_KEY'
 * '<S232>' : 'DemoModel/subsystem/Simulink-PS Converter'
 * '<S233>' : 'DemoModel/subsystem/Simulink-PS Converter/EVAL_KEY'
 */
#endif                                 /* RTW_HEADER_DemoModel_h_ */
