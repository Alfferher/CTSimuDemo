/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#include "ne_ds.h"
#include "DemoModel_1d0f24d5_1_ds_y.h"
#include "DemoModel_1d0f24d5_1_ds_sys_struct.h"
#include "DemoModel_1d0f24d5_1_ds_externals.h"
#include "DemoModel_1d0f24d5_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T DemoModel_1d0f24d5_1_ds_y(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t19, NeDsMethodOutput *t20)
{
  PmRealVector out;
  real_T ANDCond3_1_Coil_Voltage_Sensor_V;
  real_T t7;
  real_T X_idx_3;
  real_T X_idx_0;
  real_T X_idx_1;
  real_T X_idx_8;
  real_T X_idx_7;
  real_T X_idx_10;
  real_T X_idx_11;
  real_T X_idx_12;
  real_T X_idx_14;
  real_T X_idx_26;
  real_T X_idx_25;
  real_T X_idx_29;
  real_T X_idx_30;
  real_T X_idx_16;
  real_T X_idx_6;
  real_T X_idx_20;
  real_T X_idx_35;
  real_T X_idx_34;
  real_T X_idx_32;
  real_T X_idx_36;
  real_T X_idx_33;
  X_idx_0 = t19->mX.mX[0];
  X_idx_1 = t19->mX.mX[1];
  X_idx_3 = t19->mX.mX[3];
  X_idx_6 = t19->mX.mX[6];
  X_idx_7 = t19->mX.mX[7];
  X_idx_8 = t19->mX.mX[8];
  X_idx_10 = t19->mX.mX[10];
  X_idx_11 = t19->mX.mX[11];
  X_idx_12 = t19->mX.mX[12];
  X_idx_14 = t19->mX.mX[14];
  X_idx_16 = t19->mX.mX[16];
  X_idx_20 = t19->mX.mX[20];
  X_idx_25 = t19->mX.mX[25];
  X_idx_26 = t19->mX.mX[26];
  X_idx_29 = t19->mX.mX[29];
  X_idx_30 = t19->mX.mX[30];
  X_idx_32 = t19->mX.mX[32];
  X_idx_33 = t19->mX.mX[33];
  X_idx_34 = t19->mX.mX[34];
  X_idx_35 = t19->mX.mX[35];
  X_idx_36 = t19->mX.mX[36];
  out = t20->mY;
  ANDCond3_1_Coil_Voltage_Sensor_V = -(X_idx_8 - X_idx_7) / -1.0;
  t7 = -X_idx_29 / -1.0;
  out.mX[0] = ANDCond3_1_Coil_Voltage_Sensor_V;
  out.mX[1] = -(X_idx_0 - (-X_idx_11)) / -1.0;
  out.mX[2] = -(X_idx_0 - (-X_idx_14)) / -1.0;
  out.mX[3] = -((X_idx_0 + X_idx_10) - X_idx_7) / -1.0;
  out.mX[4] = ANDCond3_1_Coil_Voltage_Sensor_V;
  out.mX[5] = -(X_idx_0 + X_idx_12) / -1.0;
  out.mX[6] = -(X_idx_25 - (-X_idx_26)) / -1.0;
  out.mX[7] = -(X_idx_29 - X_idx_30) / -1.0;
  out.mX[8] = -(X_idx_16 - X_idx_6) / -1.0;
  out.mX[9] = -(X_idx_0 - X_idx_20) / -1.0;
  out.mX[10] = t7;
  out.mX[11] = -((X_idx_29 + X_idx_34) - X_idx_32) / -1.0;
  out.mX[12] = -(X_idx_0 - X_idx_36) / -1.0;
  out.mX[13] = -(X_idx_29 + X_idx_33) / -1.0;
  out.mX[14] = -(X_idx_0 - (-X_idx_35)) / -1.0;
  out.mX[15] = -(((X_idx_3 + X_idx_0) + X_idx_1) - X_idx_6) / -1.0;
  out.mX[16] = -(X_idx_29 - X_idx_7) / -1.0;
  out.mX[17] = -X_idx_8 / -1.0;
  out.mX[18] = t7;
  out.mX[19] = -X_idx_0 / -1.0;
  (void)sys;
  (void)t20;
  return 0;
}
