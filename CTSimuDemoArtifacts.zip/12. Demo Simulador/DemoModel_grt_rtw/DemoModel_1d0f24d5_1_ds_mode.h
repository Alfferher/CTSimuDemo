/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */
/* DemoModel_1d0f24d5_1_ds_mode.h - header for method DemoModel_1d0f24d5_1_ds_mode */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef DEMOMODEL_1D0F24D5_1_DS_MODE_H
#define DEMOMODEL_1D0F24D5_1_DS_MODE_H 1

  extern int32_T DemoModel_1d0f24d5_1_ds_mode(const NeDynamicSystem *sys, const
    NeDynamicSystemInput *in,NeDsMethodOutput *ou );

#endif                              /* #ifndef DEMOMODEL_1D0F24D5_1_DS_MODE_H */

#ifdef __cplusplus

}
#endif
