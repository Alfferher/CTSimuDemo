/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#ifndef __DemoModel_1d0f24d5_1_gateway_h__
#define __DemoModel_1d0f24d5_1_gateway_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern void DemoModel_1d0f24d5_1_gateway(void);

#ifdef __cplusplus

}
#endif
#endif                          /* #ifndef __DemoModel_1d0f24d5_1_gateway_h__ */
