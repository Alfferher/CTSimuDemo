/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'DemoModel/Solver Configuration'.
 */

#ifndef struct__ExternalFunctionStructTag
#define struct__ExternalFunctionStructTag
#endif
