#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
real_T ex_kpX___S1Lgx3hu0ti95uMw(const real_T*a,const size_t n);real_T
ex_VCMYZqH7FzWLWPHooBByoI(const real_T x);void ex_ktEh0_dPE7WMZaXpgviZfL(
real_T*fx1,real_T*ex__rg5CXJeg_Cndu5WDoxbMl,real_T*ex_V5xxz05F7a_ihqj30K8FAv,
real_T*ex_FNXAh_ftg_KpWeXlYDyRqE,const real_T*x1,const real_T*f,const size_t n1
,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex__dZ6arJEU5pmV9XKy8etwi,const size_t ex_VvovjV_Yc_G4fP1XodrLft,const size_t
ex_VhUgI4c0k9GOgm8dFTThdK,const size_t ex_Fsdzbs_wz00cfyfchwr6K7,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS);void ex_VKUiWhgLteGl_1sCHRJXum(real_T*
ex_k8zBiCVRtSWw_L3ohL9ZU6,real_T*ex__q3Je3USIpxhYaV_bmlNgE,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF);void ex_F7_9Sgo0sqlceT8kkrDtm9(real_T*
ex_kESK0x0mPXxyfXNDYQuNSo,real_T*ex__idLDQm5dX_uePEg9ek_dK,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t ex__Et5EUn_AfCGcaoPYM3rE7,const size_t
ex_VRc9H9oEh84hXu9Yu4okxd,const size_t ex__vFO6imE0nOcdTAyK5nWZf,const size_t
ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t ex_k64KfxW_YeCBd1Jcztnal5,const size_t
ex_FpCuD8p2g1ldYupGLDualI,const size_t ex_F4NwsNKf_S_ubm278AmjEt,const size_t
ex_VzS__hA47OtneLeQmJKhJU,const size_t ex_VseJVSrhmHl_fHMdqZQUoK,const size_t
ex__zov1f51H_xVZDV3hSAwLo,const size_t ex__UCiJ_ovpi8viepU66XSz1,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS,const real_T ex__QgqlEW2f18scLxPhDEnMF,const real_T
ex__yrlSbVOXjWXaTMEdN9cIu);void ex_Futd5IPo6_Sea16WtbGVmf(real_T*
ex__nq35K78gNGYiPqAi6FlY1,real_T*ex_k7clpQTkJip2cDihM27xMo,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const real_T*
ex__4uaYPi3B7txZPrRD2z8ek,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const size_t ex_VzS__hA47OtneLeQmJKhJU,const size_t
ex_VseJVSrhmHl_fHMdqZQUoK,const size_t ex__zov1f51H_xVZDV3hSAwLo,const size_t
ex__UCiJ_ovpi8viepU66XSz1,const size_t ex_FDTDXUQhgm_eYmdJ8sNRVZ,const size_t
ex_VlNl_tKLFzxvYHI0dZ9wzf,const size_t ex_kiGZSX33fPpmaucBO5il15,const size_t
ex__1tnMVPyaKpZeawGCX2ExG,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF,const real_T ex__yrlSbVOXjWXaTMEdN9cIu,const real_T
ex_F1sFV5GwlJdShuwH_gb9cU);size_t ex_F0HBEJ7qD9OkfDK6FdP9lf(real_T*H,real_T*Hx
,real_T*G,real_T*Gx,size_t*numEdges,const real_T*x,const size_t n,const real_T
t,const boolean_T*mode,const real_T ex_F_tm5fod4xxuguhS49BSQm,const boolean_T
ex_kMAXUIgm88xvaunhJ2st8X);size_t ex_FSBp3lkv5gpCXL2yT9vLNh(const real_T*x,
const size_t n,const real_T t);void ex_kGRJvwU4WMthWL53sjRCpO(real_T*
ex_F2l4p_g4sn02huHNflQjMH,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT);void ex_FtfBZE2kLGxyWamCvlRfeQ(real_T*x,real_T*f,
const size_t n);void ex_F4LajttG6uGtbXBJgUNQpW(real_T*x1,real_T*x2,real_T*f,
const size_t n1,const size_t n2);void ex_kIBgcKPC9nhchTKovcabSa(real_T*x1,
real_T*x2,real_T*x3,real_T*f,const size_t n1,const size_t n2,const size_t n3);
void ex_F_6wSEEsvm_1cTAuvwDt9B(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*
f,const size_t n1,const size_t n2,const size_t n3,const size_t n4);
#include "pm_std.h"
#include "lang_std.h"
#include "string.h"
static void ex_FzXlwsFdzbGOh5RDZi0NNm(real_T*fi,const real_T*H1,const real_T*
Hx1,const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,
const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*f,const real_T*fx,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2,const real_T
ex_F_tm5fod4xxuguhS49BSQm,const boolean_T ex_kMAXUIgm88xvaunhJ2st8X);static
void ex_FokJD1b8z0WJX9TTsQfvSP(real_T*x1,real_T*x2,real_T*f,real_T*fx,real_T*
bv1,real_T*bv2,const real_T*x1s,const real_T*x2s,const real_T*fs,const size_t
n1,const size_t n2);void tlu2_2d_akima_nearest_process(real_T*x1,real_T*x2,
real_T*f,real_T*fx1,real_T*bv1,real_T*bv2,const real_T*x1s,const real_T*x2s,
const real_T*fs,const size_t*n1,const size_t*n2){ex_FokJD1b8z0WJX9TTsQfvSP(x1,
x2,f,fx1,bv1,bv2,x1s,x2s,fs,*n1,*n2);}void
tlu2_2d_akima_nearest_process_custom_function_(void*out,const void*in){const
real_T*x1s=(const real_T*)((const void*const*)in)[0];const real_T*x2s=(const
real_T*)((const void*const*)in)[1];const real_T*fs=(const real_T*)((const void
*const*)in)[2];const size_t*n1=(const size_t*)((const void*const*)in)[3];const
size_t*n2=(const size_t*)((const void*const*)in)[4];real_T*x1=(real_T*)((void*
*)out)[0];real_T*x2=(real_T*)((void**)out)[1];real_T*f=(real_T*)((void**)out)[
2];real_T*fx=(real_T*)((void**)out)[3];real_T*bv1=(real_T*)((void**)out)[4];
real_T*bv2=(real_T*)((void**)out)[5];tlu2_2d_akima_nearest_process(x1,x2,f,fx,
bv1,bv2,x1s,x2s,fs,n1,n2);}void tlu2_2d_akima_linear_process(real_T*x1,real_T*
x2,real_T*f,real_T*fx1,real_T*bv1,real_T*bv2,const real_T*x1s,const real_T*x2s
,const real_T*fs,const size_t*n1,const size_t*n2){ex_FokJD1b8z0WJX9TTsQfvSP(x1
,x2,f,fx1,bv1,bv2,x1s,x2s,fs,*n1,*n2);}void
tlu2_2d_akima_linear_process_custom_function_(void*out,const void*in){const
real_T*x1s=(const real_T*)((const void*const*)in)[0];const real_T*x2s=(const
real_T*)((const void*const*)in)[1];const real_T*fs=(const real_T*)((const void
*const*)in)[2];const size_t*n1=(const size_t*)((const void*const*)in)[3];const
size_t*n2=(const size_t*)((const void*const*)in)[4];real_T*x1=(real_T*)((void*
*)out)[0];real_T*x2=(real_T*)((void**)out)[1];real_T*f=(real_T*)((void**)out)[
2];real_T*fx=(real_T*)((void**)out)[3];real_T*bv1=(real_T*)((void**)out)[4];
real_T*bv2=(real_T*)((void**)out)[5];tlu2_2d_akima_linear_process(x1,x2,f,fx,
bv1,bv2,x1s,x2s,fs,n1,n2);}static void ex_FokJD1b8z0WJX9TTsQfvSP(real_T*x1,
real_T*x2,real_T*f,real_T*fx1,real_T*bv1,real_T*bv2,const real_T*x1s,const
real_T*x2s,const real_T*fs,const size_t n1,const size_t n2){const real_T
ex_FfDTppU8N_tOWuLK37x_08=1.0e-12;const size_t n=n1*n2;real_T*
ex__U2B3s_V9tO0_uYiotrZS5=fx1+n;real_T*ex_k8zBiCVRtSWw_L3ohL9ZU6=
ex__U2B3s_V9tO0_uYiotrZS5+n;real_T*ex_V5xxz05F7a_ihqj30K8FAv=pmf_calloc(n1-1,
sizeof(real_T));real_T*ex_V5FHdRJO8p82hTQ1zI7AYZ=pmf_calloc(n2-1,sizeof(real_T
));size_t ex_kf0Q9aAjyy0Uc5W69prr5z=(n1+1)*(n2+1);real_T*
ex_FNXAh_ftg_KpWeXlYDyRqE=pmf_calloc(ex_kf0Q9aAjyy0Uc5W69prr5z,sizeof(real_T))
;real_T*ex_FoUkjTojq1h5WPPqp9E_d2=pmf_calloc(ex_kf0Q9aAjyy0Uc5W69prr5z,sizeof(
real_T));real_T*ex__q3Je3USIpxhYaV_bmlNgE=NULL;real_T*
ex__rg5CXJeg_Cndu5WDoxbMl=pmf_calloc((n1+2)*n2,sizeof(real_T));real_T*
ex_FnljSwbMX3SPj5etZa8_lO=pmf_calloc(n1*(n2+2),sizeof(real_T));real_T
ex_kWYRshm5cyG9_PjD1f9y99,ex__SATdL4SVz8lem2Ly6gi_N,ex_Vza442yC9_C6X9ReplTSo5;
real_T ex_V4NyKkWjXNKyiujQkyTHSS,ex__QgqlEW2f18scLxPhDEnMF;size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH;size_t
ex_VTVqjDxUr989h9kcIs8Z9k,ex_Fklov8agSChIfPNAP5Ja45;size_t
ex_FEpQvc7eQhxoY1eyOlzQgC,ex__Et5EUn_AfCGcaoPYM3rE7,ex_VRPFkIFFnYS8jTEIvSRCk8,
ex_k64KfxW_YeCBd1Jcztnal5;memcpy(x1,x1s,n1*sizeof(real_T));memcpy(x2,x2s,n2*
sizeof(real_T));memcpy(f,fs,n*sizeof(real_T));ex_F4LajttG6uGtbXBJgUNQpW(x1,x2,
f,n1,n2);bv1[0]=x1[0];bv1[1]=x1[n1-1];bv2[0]=x2[0];bv2[1]=x2[n2-1];
ex_kWYRshm5cyG9_PjD1f9y99=ex_VCMYZqH7FzWLWPHooBByoI(x1[n1-1]-x1[0])+
ex_FfDTppU8N_tOWuLK37x_08;ex__SATdL4SVz8lem2Ly6gi_N=ex_VCMYZqH7FzWLWPHooBByoI(
x2[n2-1]-x2[0])+ex_FfDTppU8N_tOWuLK37x_08;ex_Vza442yC9_C6X9ReplTSo5=
ex_kpX___S1Lgx3hu0ti95uMw(f,n)+ex_FfDTppU8N_tOWuLK37x_08;
ex_V4NyKkWjXNKyiujQkyTHSS=ex_FfDTppU8N_tOWuLK37x_08*ex_Vza442yC9_C6X9ReplTSo5/
ex_kWYRshm5cyG9_PjD1f9y99;ex__QgqlEW2f18scLxPhDEnMF=ex_FfDTppU8N_tOWuLK37x_08*
ex_Vza442yC9_C6X9ReplTSo5/ex__SATdL4SVz8lem2Ly6gi_N;ex_kyZWlRgyPY_nhaYrzhlz4N=
1;ex_VSy0VE52bQSafuDoXEVasH=n1;ex_VTVqjDxUr989h9kcIs8Z9k=1;
ex_Fklov8agSChIfPNAP5Ja45=n1+1;ex_FEpQvc7eQhxoY1eyOlzQgC=1;
ex__Et5EUn_AfCGcaoPYM3rE7=n1+2;ex_VRPFkIFFnYS8jTEIvSRCk8=1;
ex_k64KfxW_YeCBd1Jcztnal5=n1;ex_ktEh0_dPE7WMZaXpgviZfL(fx1,
ex__rg5CXJeg_Cndu5WDoxbMl,ex_V5xxz05F7a_ihqj30K8FAv,ex_FNXAh_ftg_KpWeXlYDyRqE,
x1,f,n1,n2,1,1,ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,0,0,
ex_VTVqjDxUr989h9kcIs8Z9k,ex_Fklov8agSChIfPNAP5Ja45,0,0,
ex_FEpQvc7eQhxoY1eyOlzQgC,ex__Et5EUn_AfCGcaoPYM3rE7,0,0,
ex_V4NyKkWjXNKyiujQkyTHSS);ex_ktEh0_dPE7WMZaXpgviZfL(ex__U2B3s_V9tO0_uYiotrZS5
,ex_FnljSwbMX3SPj5etZa8_lO,ex_V5FHdRJO8p82hTQ1zI7AYZ,ex_FoUkjTojq1h5WPPqp9E_d2
,x2,f,n2,n1,1,1,ex_VSy0VE52bQSafuDoXEVasH,ex_kyZWlRgyPY_nhaYrzhlz4N,0,0,
ex_Fklov8agSChIfPNAP5Ja45,ex_VTVqjDxUr989h9kcIs8Z9k,0,0,
ex_k64KfxW_YeCBd1Jcztnal5,ex_VRPFkIFFnYS8jTEIvSRCk8,0,0,
ex__QgqlEW2f18scLxPhDEnMF);ex__q3Je3USIpxhYaV_bmlNgE=ex_FoUkjTojq1h5WPPqp9E_d2
;ex_VKUiWhgLteGl_1sCHRJXum(ex_k8zBiCVRtSWw_L3ohL9ZU6,ex__q3Je3USIpxhYaV_bmlNgE
,ex_V5xxz05F7a_ihqj30K8FAv,ex__rg5CXJeg_Cndu5WDoxbMl,ex_FnljSwbMX3SPj5etZa8_lO
,n1,n2,1,1,ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,0,0,
ex_VTVqjDxUr989h9kcIs8Z9k,ex_Fklov8agSChIfPNAP5Ja45,0,0,
ex_FEpQvc7eQhxoY1eyOlzQgC,ex__Et5EUn_AfCGcaoPYM3rE7,0,0,
ex_VRPFkIFFnYS8jTEIvSRCk8,ex_k64KfxW_YeCBd1Jcztnal5,0,0,
ex_V4NyKkWjXNKyiujQkyTHSS,ex__QgqlEW2f18scLxPhDEnMF);pmf_free(
ex_V5xxz05F7a_ihqj30K8FAv);pmf_free(ex_V5FHdRJO8p82hTQ1zI7AYZ);pmf_free(
ex_FNXAh_ftg_KpWeXlYDyRqE);pmf_free(ex_FoUkjTojq1h5WPPqp9E_d2);pmf_free(
ex__rg5CXJeg_Cndu5WDoxbMl);pmf_free(ex_FnljSwbMX3SPj5etZa8_lO);}void
tlu2_2d_akima_nearest_value(real_T*fi,const real_T*H1,const real_T*Hx1,const
real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,const
real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t*
numEdges2,const size_t*bin2,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2){
ex_FzXlwsFdzbGOh5RDZi0NNm(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,f,fx1,mode1,mode2,n1,n2,0.0,false);}void
tlu2_2d_akima_nearest_value_custom_function_(void*out,const void*in){const
real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(const
real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((const void
*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const size_t*
bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const real_T*)
((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void*const*
)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const real_T
*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(const
size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((const
void*const*)in)[11];const real_T*f=(const real_T*)((const void*const*)in)[12];
const real_T*fx=(const real_T*)((const void*const*)in)[13];const boolean_T*
mode1=(const boolean_T*)((const void*const*)in)[14];const boolean_T*mode2=(
const boolean_T*)((const void*const*)in)[15];const size_t*n1=(const size_t*)((
const void*const*)in)[16];const size_t*n2=(const size_t*)((const void*const*)
in)[17];real_T*fi=(real_T*)out;tlu2_2d_akima_nearest_value(fi,H1,Hx1,G1,Gx1,
numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,f,fx,mode1,mode2,n1,n2);}void
tlu2_2d_akima_linear_value(real_T*fi,const real_T*H1,const real_T*Hx1,const
real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,const
real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t*
numEdges2,const size_t*bin2,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2){
ex_FzXlwsFdzbGOh5RDZi0NNm(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,f,fx1,mode1,mode2,n1,n2,1.0,false);}void
tlu2_2d_akima_linear_value_custom_function_(void*out,const void*in){const
real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(const
real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((const void
*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const size_t*
bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const real_T*)
((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void*const*
)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const real_T
*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(const
size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((const
void*const*)in)[11];const real_T*f=(const real_T*)((const void*const*)in)[12];
const real_T*fx=(const real_T*)((const void*const*)in)[13];const boolean_T*
mode1=(const boolean_T*)((const void*const*)in)[14];const boolean_T*mode2=(
const boolean_T*)((const void*const*)in)[15];const size_t*n1=(const size_t*)((
const void*const*)in)[16];const size_t*n2=(const size_t*)((const void*const*)
in)[17];real_T*fi=(real_T*)out;tlu2_2d_akima_linear_value(fi,H1,Hx1,G1,Gx1,
numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,f,fx,mode1,mode2,n1,n2);}void
tlu2_2d_akima_nearest_derivatives(real_T*fi,const real_T*H1,const real_T*Hx1,
const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,
const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2){
ex_FzXlwsFdzbGOh5RDZi0NNm(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,f,fx1,mode1,mode2,n1,n2,0.0,true);}void
tlu2_2d_akima_nearest_derivatives_custom_function_(void*out,const void*in){
const real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(
const real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((
const void*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)
in)[3];const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const
size_t*bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const
real_T*)((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void
*const*)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const
real_T*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(
const size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((
const void*const*)in)[11];const real_T*f=(const real_T*)((const void*const*)in
)[12];const real_T*fx=(const real_T*)((const void*const*)in)[13];const
boolean_T*mode1=(const boolean_T*)((const void*const*)in)[14];const boolean_T*
mode2=(const boolean_T*)((const void*const*)in)[15];const size_t*n1=(const
size_t*)((const void*const*)in)[16];const size_t*n2=(const size_t*)((const void
*const*)in)[17];real_T*fi=(real_T*)out;tlu2_2d_akima_nearest_derivatives(fi,H1
,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,f,fx,mode1,mode2,n1,n2
);}void tlu2_2d_akima_linear_derivatives(real_T*fi,const real_T*H1,const real_T
*Hx1,const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1
,const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*n1,const size_t*n2){
ex_FzXlwsFdzbGOh5RDZi0NNm(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,f,fx1,mode1,mode2,n1,n2,1.0,true);}void
tlu2_2d_akima_linear_derivatives_custom_function_(void*out,const void*in){
const real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(
const real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((
const void*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)
in)[3];const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const
size_t*bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const
real_T*)((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void
*const*)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const
real_T*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(
const size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((
const void*const*)in)[11];const real_T*f=(const real_T*)((const void*const*)in
)[12];const real_T*fx=(const real_T*)((const void*const*)in)[13];const
boolean_T*mode1=(const boolean_T*)((const void*const*)in)[14];const boolean_T*
mode2=(const boolean_T*)((const void*const*)in)[15];const size_t*n1=(const
size_t*)((const void*const*)in)[16];const size_t*n2=(const size_t*)((const void
*const*)in)[17];real_T*fi=(real_T*)out;tlu2_2d_akima_linear_derivatives(fi,H1,
Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,f,fx,mode1,mode2,n1,n2)
;}static void ex_FzXlwsFdzbGOh5RDZi0NNm(real_T*fi,const real_T*H1,const real_T
*Hx1,const real_T*G1,const real_T*Gx1,const size_t*ex_koMwWVZ5kdO_cmNynyQJr7,
const size_t*ex_V5M9clt1oOxmhHN3Ehciw4,const real_T*H2,const real_T*Hx2,const
real_T*G2,const real_T*Gx2,const size_t*ex___TPtFdMIMdka1RE4RrHK5,const size_t
*ex_kwmw_QOG8uhxiTvKA_xa1Y,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const size_t*ex_VMjU_zotmLxndPNpPFuHG9,const size_t
*ex_VtVCgVxNcpd_YmPNQN4Ru7,const real_T ex_F_tm5fod4xxuguhS49BSQm,const
boolean_T ex_kMAXUIgm88xvaunhJ2st8X){const size_t n1= *
ex_VMjU_zotmLxndPNpPFuHG9;const size_t n2= *ex_VtVCgVxNcpd_YmPNQN4Ru7;const
size_t n=n1*n2;const real_T*ex__U2B3s_V9tO0_uYiotrZS5=fx1+n;const real_T*
ex_k8zBiCVRtSWw_L3ohL9ZU6=ex__U2B3s_V9tO0_uYiotrZS5+n;size_t numEdges1= *
ex_koMwWVZ5kdO_cmNynyQJr7;size_t numEdges2= *ex___TPtFdMIMdka1RE4RrHK5;size_t
bin1= *ex_V5M9clt1oOxmhHN3Ehciw4;size_t bin2= *ex_kwmw_QOG8uhxiTvKA_xa1Y;
size_t bin=bin1+n1*bin2;size_t ex_FnrjFNs9eQp9V5vCxPaoKw,
ex_FRuIUemzxbdhfqkjXhoyK7;size_t ex_Fb8WfqABMs_vcqFzZf37Fa,
ex_k4UiAV7JSYpMjHsHDM_wV6;fi[0]=0.0;if(ex_kMAXUIgm88xvaunhJ2st8X){fi[1]=0.0;}
for(ex_FRuIUemzxbdhfqkjXhoyK7=0;ex_FRuIUemzxbdhfqkjXhoyK7<numEdges2;++
ex_FRuIUemzxbdhfqkjXhoyK7){ex_k4UiAV7JSYpMjHsHDM_wV6=n1*
ex_FRuIUemzxbdhfqkjXhoyK7+bin;for(ex_FnrjFNs9eQp9V5vCxPaoKw=0;
ex_FnrjFNs9eQp9V5vCxPaoKw<numEdges1;++ex_FnrjFNs9eQp9V5vCxPaoKw){
ex_Fb8WfqABMs_vcqFzZf37Fa=ex_FnrjFNs9eQp9V5vCxPaoKw+ex_k4UiAV7JSYpMjHsHDM_wV6;
if(ex_kMAXUIgm88xvaunhJ2st8X){fi[0]+=(f[ex_Fb8WfqABMs_vcqFzZf37Fa]*G1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+fx1[ex_Fb8WfqABMs_vcqFzZf37Fa]*Gx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*H2[ex_FRuIUemzxbdhfqkjXhoyK7]+(
ex__U2B3s_V9tO0_uYiotrZS5[ex_Fb8WfqABMs_vcqFzZf37Fa]*G1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+ex_k8zBiCVRtSWw_L3ohL9ZU6[ex_Fb8WfqABMs_vcqFzZf37Fa
]*Gx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*Hx2[ex_FRuIUemzxbdhfqkjXhoyK7];fi[1]+=(f[
ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[ex_FnrjFNs9eQp9V5vCxPaoKw]+fx1[
ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*G2[
ex_FRuIUemzxbdhfqkjXhoyK7]+(ex__U2B3s_V9tO0_uYiotrZS5[
ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[ex_FnrjFNs9eQp9V5vCxPaoKw]+
ex_k8zBiCVRtSWw_L3ohL9ZU6[ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*Gx2[ex_FRuIUemzxbdhfqkjXhoyK7];}else{fi[0]+=(f[
ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[ex_FnrjFNs9eQp9V5vCxPaoKw]+fx1[
ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*H2[
ex_FRuIUemzxbdhfqkjXhoyK7]+(ex__U2B3s_V9tO0_uYiotrZS5[
ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[ex_FnrjFNs9eQp9V5vCxPaoKw]+
ex_k8zBiCVRtSWw_L3ohL9ZU6[ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*Hx2[ex_FRuIUemzxbdhfqkjXhoyK7];}}}}
