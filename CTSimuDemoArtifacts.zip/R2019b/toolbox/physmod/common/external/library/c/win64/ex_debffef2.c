#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
real_T ex_kpX___S1Lgx3hu0ti95uMw(const real_T*a,const size_t n);real_T
ex_VCMYZqH7FzWLWPHooBByoI(const real_T x);void ex_ktEh0_dPE7WMZaXpgviZfL(
real_T*fx1,real_T*ex__rg5CXJeg_Cndu5WDoxbMl,real_T*ex_V5xxz05F7a_ihqj30K8FAv,
real_T*ex_FNXAh_ftg_KpWeXlYDyRqE,const real_T*x1,const real_T*f,const size_t n1
,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex__dZ6arJEU5pmV9XKy8etwi,const size_t ex_VvovjV_Yc_G4fP1XodrLft,const size_t
ex_VhUgI4c0k9GOgm8dFTThdK,const size_t ex_Fsdzbs_wz00cfyfchwr6K7,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS);void ex_VKUiWhgLteGl_1sCHRJXum(real_T*
ex_k8zBiCVRtSWw_L3ohL9ZU6,real_T*ex__q3Je3USIpxhYaV_bmlNgE,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF);void ex_F7_9Sgo0sqlceT8kkrDtm9(real_T*
ex_kESK0x0mPXxyfXNDYQuNSo,real_T*ex__idLDQm5dX_uePEg9ek_dK,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t ex__Et5EUn_AfCGcaoPYM3rE7,const size_t
ex_VRc9H9oEh84hXu9Yu4okxd,const size_t ex__vFO6imE0nOcdTAyK5nWZf,const size_t
ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t ex_k64KfxW_YeCBd1Jcztnal5,const size_t
ex_FpCuD8p2g1ldYupGLDualI,const size_t ex_F4NwsNKf_S_ubm278AmjEt,const size_t
ex_VzS__hA47OtneLeQmJKhJU,const size_t ex_VseJVSrhmHl_fHMdqZQUoK,const size_t
ex__zov1f51H_xVZDV3hSAwLo,const size_t ex__UCiJ_ovpi8viepU66XSz1,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS,const real_T ex__QgqlEW2f18scLxPhDEnMF,const real_T
ex__yrlSbVOXjWXaTMEdN9cIu);void ex_Futd5IPo6_Sea16WtbGVmf(real_T*
ex__nq35K78gNGYiPqAi6FlY1,real_T*ex_k7clpQTkJip2cDihM27xMo,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const real_T*
ex__4uaYPi3B7txZPrRD2z8ek,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const size_t ex_VzS__hA47OtneLeQmJKhJU,const size_t
ex_VseJVSrhmHl_fHMdqZQUoK,const size_t ex__zov1f51H_xVZDV3hSAwLo,const size_t
ex__UCiJ_ovpi8viepU66XSz1,const size_t ex_FDTDXUQhgm_eYmdJ8sNRVZ,const size_t
ex_VlNl_tKLFzxvYHI0dZ9wzf,const size_t ex_kiGZSX33fPpmaucBO5il15,const size_t
ex__1tnMVPyaKpZeawGCX2ExG,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF,const real_T ex__yrlSbVOXjWXaTMEdN9cIu,const real_T
ex_F1sFV5GwlJdShuwH_gb9cU);size_t ex_F0HBEJ7qD9OkfDK6FdP9lf(real_T*H,real_T*Hx
,real_T*G,real_T*Gx,size_t*numEdges,const real_T*x,const size_t n,const real_T
t,const boolean_T*mode,const real_T ex_F_tm5fod4xxuguhS49BSQm,const boolean_T
ex_kMAXUIgm88xvaunhJ2st8X);size_t ex_FSBp3lkv5gpCXL2yT9vLNh(const real_T*x,
const size_t n,const real_T t);void ex_kGRJvwU4WMthWL53sjRCpO(real_T*
ex_F2l4p_g4sn02huHNflQjMH,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT);void ex_FtfBZE2kLGxyWamCvlRfeQ(real_T*x,real_T*f,
const size_t n);void ex_F4LajttG6uGtbXBJgUNQpW(real_T*x1,real_T*x2,real_T*f,
const size_t n1,const size_t n2);void ex_kIBgcKPC9nhchTKovcabSa(real_T*x1,
real_T*x2,real_T*x3,real_T*f,const size_t n1,const size_t n2,const size_t n3);
void ex_F_6wSEEsvm_1cTAuvwDt9B(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*
f,const size_t n1,const size_t n2,const size_t n3,const size_t n4);
#include "pm_std.h"
#include "lang_std.h"
#include "string.h"
static void ex_FcBoyAOGyQhIhHf_kb6OE_(real_T*fi,const real_T*H1,const real_T*
Hx1,const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,
const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*H3,const real_T*Hx3,const real_T*G3,
const real_T*Gx3,const size_t*numEdges3,const size_t*bin3,const real_T*f,const
real_T*fx,const boolean_T*mode1,const boolean_T*mode2,const boolean_T*mode3,
const size_t*n1,const size_t*n2,const size_t*n3,const real_T
ex_F_tm5fod4xxuguhS49BSQm,const boolean_T ex_kMAXUIgm88xvaunhJ2st8X);static
void ex_FTfRmGUQPqlNaHvVdAUgIB(real_T*x1,real_T*x2,real_T*x3,real_T*f,real_T*
fx,real_T*bv1,real_T*bv2,real_T*bv3,const real_T*x1s,const real_T*x2s,const
real_T*x3s,const real_T*fs,const size_t n1,const size_t n2,const size_t n3);
void tlu2_3d_akima_nearest_process(real_T*x1,real_T*x2,real_T*x3,real_T*f,
real_T*fx1,real_T*bv1,real_T*bv2,real_T*bv3,const real_T*x1s,const real_T*x2s,
const real_T*x3s,const real_T*fs,const size_t*n1,const size_t*n2,const size_t*
n3){ex_FTfRmGUQPqlNaHvVdAUgIB(x1,x2,x3,f,fx1,bv1,bv2,bv3,x1s,x2s,x3s,fs,*n1,*
n2,*n3);}void tlu2_3d_akima_nearest_process_custom_function_(void*out,const
void*in){const real_T*x1s=(const real_T*)((const void*const*)in)[0];const
real_T*x2s=(const real_T*)((const void*const*)in)[1];const real_T*x3s=(const
real_T*)((const void*const*)in)[2];const real_T*fs=(const real_T*)((const void
*const*)in)[3];const size_t*n1=(const size_t*)((const void*const*)in)[4];const
size_t*n2=(const size_t*)((const void*const*)in)[5];const size_t*n3=(const
size_t*)((const void*const*)in)[6];real_T*x1=(real_T*)((void**)out)[0];real_T*
x2=(real_T*)((void**)out)[1];real_T*x3=(real_T*)((void**)out)[2];real_T*f=(
real_T*)((void**)out)[3];real_T*fx=(real_T*)((void**)out)[4];real_T*bv1=(
real_T*)((void**)out)[5];real_T*bv2=(real_T*)((void**)out)[6];real_T*bv3=(
real_T*)((void**)out)[7];tlu2_3d_akima_nearest_process(x1,x2,x3,f,fx,bv1,bv2,
bv3,x1s,x2s,x3s,fs,n1,n2,n3);}void tlu2_3d_akima_linear_process(real_T*x1,
real_T*x2,real_T*x3,real_T*f,real_T*fx1,real_T*bv1,real_T*bv2,real_T*bv3,const
real_T*x1s,const real_T*x2s,const real_T*x3s,const real_T*fs,const size_t*n1,
const size_t*n2,const size_t*n3){ex_FTfRmGUQPqlNaHvVdAUgIB(x1,x2,x3,f,fx1,bv1,
bv2,bv3,x1s,x2s,x3s,fs,*n1,*n2,*n3);}void
tlu2_3d_akima_linear_process_custom_function_(void*out,const void*in){const
real_T*x1s=(const real_T*)((const void*const*)in)[0];const real_T*x2s=(const
real_T*)((const void*const*)in)[1];const real_T*x3s=(const real_T*)((const void
*const*)in)[2];const real_T*fs=(const real_T*)((const void*const*)in)[3];const
size_t*n1=(const size_t*)((const void*const*)in)[4];const size_t*n2=(const
size_t*)((const void*const*)in)[5];const size_t*n3=(const size_t*)((const void
*const*)in)[6];real_T*x1=(real_T*)((void**)out)[0];real_T*x2=(real_T*)((void**
)out)[1];real_T*x3=(real_T*)((void**)out)[2];real_T*f=(real_T*)((void**)out)[3
];real_T*fx=(real_T*)((void**)out)[4];real_T*bv1=(real_T*)((void**)out)[5];
real_T*bv2=(real_T*)((void**)out)[6];real_T*bv3=(real_T*)((void**)out)[7];
tlu2_3d_akima_linear_process(x1,x2,x3,f,fx,bv1,bv2,bv3,x1s,x2s,x3s,fs,n1,n2,n3
);}static void ex_FTfRmGUQPqlNaHvVdAUgIB(real_T*x1,real_T*x2,real_T*x3,real_T*
f,real_T*fx1,real_T*bv1,real_T*bv2,real_T*bv3,const real_T*x1s,const real_T*
x2s,const real_T*x3s,const real_T*fs,const size_t n1,const size_t n2,const
size_t n3){const real_T ex_FfDTppU8N_tOWuLK37x_08=1.0e-12;const size_t n=n1*n2
*n3;real_T*ex__U2B3s_V9tO0_uYiotrZS5=fx1+n;real_T*ex_kTU1pN1_cJ8Bb9gZ2xwW9n=
ex__U2B3s_V9tO0_uYiotrZS5+n;real_T*ex_k8zBiCVRtSWw_L3ohL9ZU6=
ex_kTU1pN1_cJ8Bb9gZ2xwW9n+n;real_T*ex___7Lx6iTDDlF_TSpwiePYC=
ex_k8zBiCVRtSWw_L3ohL9ZU6+n;real_T*ex__I1KXJvl3c0VfehSr1Hfbk=
ex___7Lx6iTDDlF_TSpwiePYC+n;real_T*ex_kESK0x0mPXxyfXNDYQuNSo=
ex__I1KXJvl3c0VfehSr1Hfbk+n;real_T*ex_V5xxz05F7a_ihqj30K8FAv=pmf_calloc(n1-1,
sizeof(real_T));real_T*ex_V5FHdRJO8p82hTQ1zI7AYZ=pmf_calloc(n2-1,sizeof(real_T
));real_T*ex_FWy_LzBBKhKkWab49wMCRY=pmf_calloc(n3-1,sizeof(real_T));size_t
ex_kf0Q9aAjyy0Uc5W69prr5z=(n1+1)*(n2+1)*(n3+1);real_T*
ex_FNXAh_ftg_KpWeXlYDyRqE=pmf_calloc(ex_kf0Q9aAjyy0Uc5W69prr5z,sizeof(real_T))
;real_T*ex_FoUkjTojq1h5WPPqp9E_d2=pmf_calloc(ex_kf0Q9aAjyy0Uc5W69prr5z,sizeof(
real_T));real_T*ex_F8uNcKSi5a8uhH_SN2_SfX=pmf_calloc(ex_kf0Q9aAjyy0Uc5W69prr5z
,sizeof(real_T));real_T*ex__q3Je3USIpxhYaV_bmlNgE=NULL;real_T*
ex_VyQfuHDk_o8oc5NUv379aG=NULL;real_T*ex_FX2EfTndYiKPc9lfwW_XgS=NULL;real_T*
ex__idLDQm5dX_uePEg9ek_dK=NULL;real_T*ex__rg5CXJeg_Cndu5WDoxbMl=pmf_calloc((n1
+2)*n2*n3,sizeof(real_T));real_T*ex_FnljSwbMX3SPj5etZa8_lO=pmf_calloc(n1*(n2+2
)*n3,sizeof(real_T));real_T*ex__nVSfRrp1Ld7fuuZg1ACm0=pmf_calloc(n1*n2*(n3+2),
sizeof(real_T));real_T ex_kWYRshm5cyG9_PjD1f9y99,ex__SATdL4SVz8lem2Ly6gi_N,
ex_V_Hw4i6wueK6fTyH6nPaxQ,ex_Vza442yC9_C6X9ReplTSo5;real_T
ex_V4NyKkWjXNKyiujQkyTHSS,ex__QgqlEW2f18scLxPhDEnMF,ex__yrlSbVOXjWXaTMEdN9cIu;
size_t ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,
ex_keXUKEfwn7pKd9Pw_tgV73;size_t ex_VTVqjDxUr989h9kcIs8Z9k,
ex_Fklov8agSChIfPNAP5Ja45,ex_kuuoJqthi7CXc5HX6B4l4u;size_t
ex_FEpQvc7eQhxoY1eyOlzQgC,ex__Et5EUn_AfCGcaoPYM3rE7,ex_VRc9H9oEh84hXu9Yu4okxd,
ex_VRPFkIFFnYS8jTEIvSRCk8,ex_k64KfxW_YeCBd1Jcztnal5,ex_FpCuD8p2g1ldYupGLDualI,
ex_VzS__hA47OtneLeQmJKhJU,ex_VseJVSrhmHl_fHMdqZQUoK,ex__zov1f51H_xVZDV3hSAwLo;
memcpy(x1,x1s,n1*sizeof(real_T));memcpy(x2,x2s,n2*sizeof(real_T));memcpy(x3,
x3s,n3*sizeof(real_T));memcpy(f,fs,n*sizeof(real_T));ex_kIBgcKPC9nhchTKovcabSa
(x1,x2,x3,f,n1,n2,n3);bv1[0]=x1[0];bv1[1]=x1[n1-1];bv2[0]=x2[0];bv2[1]=x2[n2-1
];bv3[0]=x3[0];bv3[1]=x3[n3-1];ex_kWYRshm5cyG9_PjD1f9y99=
ex_VCMYZqH7FzWLWPHooBByoI(x1[n1-1]-x1[0])+ex_FfDTppU8N_tOWuLK37x_08;
ex__SATdL4SVz8lem2Ly6gi_N=ex_VCMYZqH7FzWLWPHooBByoI(x2[n2-1]-x2[0])+
ex_FfDTppU8N_tOWuLK37x_08;ex_V_Hw4i6wueK6fTyH6nPaxQ=ex_VCMYZqH7FzWLWPHooBByoI(
x3[n3-1]-x3[0])+ex_FfDTppU8N_tOWuLK37x_08;ex_Vza442yC9_C6X9ReplTSo5=
ex_kpX___S1Lgx3hu0ti95uMw(f,n)+ex_FfDTppU8N_tOWuLK37x_08;
ex_V4NyKkWjXNKyiujQkyTHSS=ex_FfDTppU8N_tOWuLK37x_08*ex_Vza442yC9_C6X9ReplTSo5/
ex_kWYRshm5cyG9_PjD1f9y99;ex__QgqlEW2f18scLxPhDEnMF=ex_FfDTppU8N_tOWuLK37x_08*
ex_Vza442yC9_C6X9ReplTSo5/ex__SATdL4SVz8lem2Ly6gi_N;ex__yrlSbVOXjWXaTMEdN9cIu=
ex_FfDTppU8N_tOWuLK37x_08*ex_Vza442yC9_C6X9ReplTSo5/ex_V_Hw4i6wueK6fTyH6nPaxQ;
ex_kyZWlRgyPY_nhaYrzhlz4N=1;ex_VSy0VE52bQSafuDoXEVasH=
ex_kyZWlRgyPY_nhaYrzhlz4N*n1;ex_keXUKEfwn7pKd9Pw_tgV73=
ex_VSy0VE52bQSafuDoXEVasH*n2;ex_VTVqjDxUr989h9kcIs8Z9k=1;
ex_Fklov8agSChIfPNAP5Ja45=ex_VTVqjDxUr989h9kcIs8Z9k*(n1+1);
ex_kuuoJqthi7CXc5HX6B4l4u=ex_Fklov8agSChIfPNAP5Ja45*(n2+1);
ex_FEpQvc7eQhxoY1eyOlzQgC=1;ex__Et5EUn_AfCGcaoPYM3rE7=
ex_FEpQvc7eQhxoY1eyOlzQgC*(n1+2);ex_VRc9H9oEh84hXu9Yu4okxd=
ex__Et5EUn_AfCGcaoPYM3rE7*n2;ex_VRPFkIFFnYS8jTEIvSRCk8=1;
ex_k64KfxW_YeCBd1Jcztnal5=ex_VRPFkIFFnYS8jTEIvSRCk8*n1;
ex_FpCuD8p2g1ldYupGLDualI=ex_k64KfxW_YeCBd1Jcztnal5*(n2+2);
ex_VzS__hA47OtneLeQmJKhJU=1;ex_VseJVSrhmHl_fHMdqZQUoK=
ex_VzS__hA47OtneLeQmJKhJU*n1;ex__zov1f51H_xVZDV3hSAwLo=
ex_VseJVSrhmHl_fHMdqZQUoK*n2;ex_ktEh0_dPE7WMZaXpgviZfL(fx1,
ex__rg5CXJeg_Cndu5WDoxbMl,ex_V5xxz05F7a_ihqj30K8FAv,ex_FNXAh_ftg_KpWeXlYDyRqE,
x1,f,n1,n2,n3,1,ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,
ex_keXUKEfwn7pKd9Pw_tgV73,0,ex_VTVqjDxUr989h9kcIs8Z9k,
ex_Fklov8agSChIfPNAP5Ja45,ex_kuuoJqthi7CXc5HX6B4l4u,0,
ex_FEpQvc7eQhxoY1eyOlzQgC,ex__Et5EUn_AfCGcaoPYM3rE7,ex_VRc9H9oEh84hXu9Yu4okxd,
0,ex_V4NyKkWjXNKyiujQkyTHSS);ex_ktEh0_dPE7WMZaXpgviZfL(
ex__U2B3s_V9tO0_uYiotrZS5,ex_FnljSwbMX3SPj5etZa8_lO,ex_V5FHdRJO8p82hTQ1zI7AYZ,
ex_FoUkjTojq1h5WPPqp9E_d2,x2,f,n2,n3,n1,1,ex_VSy0VE52bQSafuDoXEVasH,
ex_keXUKEfwn7pKd9Pw_tgV73,ex_kyZWlRgyPY_nhaYrzhlz4N,0,
ex_Fklov8agSChIfPNAP5Ja45,ex_kuuoJqthi7CXc5HX6B4l4u,ex_VTVqjDxUr989h9kcIs8Z9k,
0,ex_k64KfxW_YeCBd1Jcztnal5,ex_FpCuD8p2g1ldYupGLDualI,
ex_VRPFkIFFnYS8jTEIvSRCk8,0,ex__QgqlEW2f18scLxPhDEnMF);
ex_ktEh0_dPE7WMZaXpgviZfL(ex_kTU1pN1_cJ8Bb9gZ2xwW9n,ex__nVSfRrp1Ld7fuuZg1ACm0,
ex_FWy_LzBBKhKkWab49wMCRY,ex_F8uNcKSi5a8uhH_SN2_SfX,x3,f,n3,n1,n2,1,
ex_keXUKEfwn7pKd9Pw_tgV73,ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,
0,ex_kuuoJqthi7CXc5HX6B4l4u,ex_VTVqjDxUr989h9kcIs8Z9k,
ex_Fklov8agSChIfPNAP5Ja45,0,ex__zov1f51H_xVZDV3hSAwLo,
ex_VzS__hA47OtneLeQmJKhJU,ex_VseJVSrhmHl_fHMdqZQUoK,0,
ex__yrlSbVOXjWXaTMEdN9cIu);ex__q3Je3USIpxhYaV_bmlNgE=ex_FoUkjTojq1h5WPPqp9E_d2
;ex_VKUiWhgLteGl_1sCHRJXum(ex_k8zBiCVRtSWw_L3ohL9ZU6,ex__q3Je3USIpxhYaV_bmlNgE
,ex_V5xxz05F7a_ihqj30K8FAv,ex__rg5CXJeg_Cndu5WDoxbMl,ex_FnljSwbMX3SPj5etZa8_lO
,n1,n2,n3,1,ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,
ex_keXUKEfwn7pKd9Pw_tgV73,0,ex_VTVqjDxUr989h9kcIs8Z9k,
ex_Fklov8agSChIfPNAP5Ja45,ex_kuuoJqthi7CXc5HX6B4l4u,0,
ex_FEpQvc7eQhxoY1eyOlzQgC,ex__Et5EUn_AfCGcaoPYM3rE7,ex_VRc9H9oEh84hXu9Yu4okxd,
0,ex_VRPFkIFFnYS8jTEIvSRCk8,ex_k64KfxW_YeCBd1Jcztnal5,
ex_FpCuD8p2g1ldYupGLDualI,0,ex_V4NyKkWjXNKyiujQkyTHSS,
ex__QgqlEW2f18scLxPhDEnMF);ex_VyQfuHDk_o8oc5NUv379aG=ex_F8uNcKSi5a8uhH_SN2_SfX
;ex_VKUiWhgLteGl_1sCHRJXum(ex___7Lx6iTDDlF_TSpwiePYC,ex_VyQfuHDk_o8oc5NUv379aG
,ex_V5FHdRJO8p82hTQ1zI7AYZ,ex_FnljSwbMX3SPj5etZa8_lO,ex__nVSfRrp1Ld7fuuZg1ACm0
,n2,n3,n1,1,ex_VSy0VE52bQSafuDoXEVasH,ex_keXUKEfwn7pKd9Pw_tgV73,
ex_kyZWlRgyPY_nhaYrzhlz4N,0,ex_Fklov8agSChIfPNAP5Ja45,
ex_kuuoJqthi7CXc5HX6B4l4u,ex_VTVqjDxUr989h9kcIs8Z9k,0,
ex_k64KfxW_YeCBd1Jcztnal5,ex_FpCuD8p2g1ldYupGLDualI,ex_VRPFkIFFnYS8jTEIvSRCk8,
0,ex_VseJVSrhmHl_fHMdqZQUoK,ex__zov1f51H_xVZDV3hSAwLo,
ex_VzS__hA47OtneLeQmJKhJU,0,ex__QgqlEW2f18scLxPhDEnMF,
ex__yrlSbVOXjWXaTMEdN9cIu);ex_FX2EfTndYiKPc9lfwW_XgS=ex_FNXAh_ftg_KpWeXlYDyRqE
;ex_VKUiWhgLteGl_1sCHRJXum(ex__I1KXJvl3c0VfehSr1Hfbk,ex_FX2EfTndYiKPc9lfwW_XgS
,ex_FWy_LzBBKhKkWab49wMCRY,ex__nVSfRrp1Ld7fuuZg1ACm0,ex__rg5CXJeg_Cndu5WDoxbMl
,n3,n1,n2,1,ex_keXUKEfwn7pKd9Pw_tgV73,ex_kyZWlRgyPY_nhaYrzhlz4N,
ex_VSy0VE52bQSafuDoXEVasH,0,ex_kuuoJqthi7CXc5HX6B4l4u,
ex_VTVqjDxUr989h9kcIs8Z9k,ex_Fklov8agSChIfPNAP5Ja45,0,
ex__zov1f51H_xVZDV3hSAwLo,ex_VzS__hA47OtneLeQmJKhJU,ex_VseJVSrhmHl_fHMdqZQUoK,
0,ex_VRc9H9oEh84hXu9Yu4okxd,ex_FEpQvc7eQhxoY1eyOlzQgC,
ex__Et5EUn_AfCGcaoPYM3rE7,0,ex__yrlSbVOXjWXaTMEdN9cIu,
ex_V4NyKkWjXNKyiujQkyTHSS);ex__idLDQm5dX_uePEg9ek_dK=ex_VyQfuHDk_o8oc5NUv379aG
;ex_F7_9Sgo0sqlceT8kkrDtm9(ex_kESK0x0mPXxyfXNDYQuNSo,ex__idLDQm5dX_uePEg9ek_dK
,ex_V5xxz05F7a_ihqj30K8FAv,ex__rg5CXJeg_Cndu5WDoxbMl,ex_FnljSwbMX3SPj5etZa8_lO
,ex__nVSfRrp1Ld7fuuZg1ACm0,n1,n2,n3,1,ex_kyZWlRgyPY_nhaYrzhlz4N,
ex_VSy0VE52bQSafuDoXEVasH,ex_keXUKEfwn7pKd9Pw_tgV73,0,
ex_VTVqjDxUr989h9kcIs8Z9k,ex_Fklov8agSChIfPNAP5Ja45,ex_kuuoJqthi7CXc5HX6B4l4u,
0,ex_FEpQvc7eQhxoY1eyOlzQgC,ex__Et5EUn_AfCGcaoPYM3rE7,
ex_VRc9H9oEh84hXu9Yu4okxd,0,ex_VRPFkIFFnYS8jTEIvSRCk8,
ex_k64KfxW_YeCBd1Jcztnal5,ex_FpCuD8p2g1ldYupGLDualI,0,
ex_VzS__hA47OtneLeQmJKhJU,ex_VseJVSrhmHl_fHMdqZQUoK,ex__zov1f51H_xVZDV3hSAwLo,
0,ex_V4NyKkWjXNKyiujQkyTHSS,ex__QgqlEW2f18scLxPhDEnMF,
ex__yrlSbVOXjWXaTMEdN9cIu);pmf_free(ex_V5xxz05F7a_ihqj30K8FAv);pmf_free(
ex_V5FHdRJO8p82hTQ1zI7AYZ);pmf_free(ex_FWy_LzBBKhKkWab49wMCRY);pmf_free(
ex_FNXAh_ftg_KpWeXlYDyRqE);pmf_free(ex_FoUkjTojq1h5WPPqp9E_d2);pmf_free(
ex_F8uNcKSi5a8uhH_SN2_SfX);pmf_free(ex__rg5CXJeg_Cndu5WDoxbMl);pmf_free(
ex_FnljSwbMX3SPj5etZa8_lO);pmf_free(ex__nVSfRrp1Ld7fuuZg1ACm0);}void
tlu2_3d_akima_nearest_value(real_T*fi,const real_T*H1,const real_T*Hx1,const
real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,const
real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t*
numEdges2,const size_t*bin2,const real_T*H3,const real_T*Hx3,const real_T*G3,
const real_T*Gx3,const size_t*numEdges3,const size_t*bin3,const real_T*f,const
real_T*fx,const boolean_T*mode1,const boolean_T*mode2,const boolean_T*mode3,
const size_t*n1,const size_t*n2,const size_t*n3){ex_FcBoyAOGyQhIhHf_kb6OE_(fi,
H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,H3,Hx3,G3,Gx3,
numEdges3,bin3,f,fx,mode1,mode2,mode3,n1,n2,n3,0.0,false);}void
tlu2_3d_akima_nearest_value_custom_function_(void*out,const void*in){const
real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(const
real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((const void
*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const size_t*
bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const real_T*)
((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void*const*
)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const real_T
*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(const
size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((const
void*const*)in)[11];const real_T*H3=(const real_T*)((const void*const*)in)[12]
;const real_T*Hx3=(const real_T*)((const void*const*)in)[13];const real_T*G3=(
const real_T*)((const void*const*)in)[14];const real_T*Gx3=(const real_T*)((
const void*const*)in)[15];const size_t*numEdges3=(const size_t*)((const void*
const*)in)[16];const size_t*bin3=(const size_t*)((const void*const*)in)[17];
const real_T*f=(const real_T*)((const void*const*)in)[18];const real_T*fx=(
const real_T*)((const void*const*)in)[19];const boolean_T*mode1=(const
boolean_T*)((const void*const*)in)[20];const boolean_T*mode2=(const boolean_T*
)((const void*const*)in)[21];const boolean_T*mode3=(const boolean_T*)((const
void*const*)in)[22];const size_t*n1=(const size_t*)((const void*const*)in)[23]
;const size_t*n2=(const size_t*)((const void*const*)in)[24];const size_t*n3=(
const size_t*)((const void*const*)in)[25];real_T*fi=(real_T*)out;
tlu2_3d_akima_nearest_value(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,H3,Hx3,G3,Gx3,numEdges3,bin3,f,fx,mode1,mode2,mode3,n1,n2,n3);}
void tlu2_3d_akima_linear_value(real_T*fi,const real_T*H1,const real_T*Hx1,
const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,
const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*H3,const real_T*Hx3,const real_T*G3,
const real_T*Gx3,const size_t*numEdges3,const size_t*bin3,const real_T*f,const
real_T*fx1,const boolean_T*mode1,const boolean_T*mode2,const boolean_T*mode3,
const size_t*n1,const size_t*n2,const size_t*n3){ex_FcBoyAOGyQhIhHf_kb6OE_(fi,
H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,H3,Hx3,G3,Gx3,
numEdges3,bin3,f,fx1,mode1,mode2,mode3,n1,n2,n3,1.0,false);}void
tlu2_3d_akima_linear_value_custom_function_(void*out,const void*in){const
real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(const
real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((const void
*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const size_t*
bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const real_T*)
((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void*const*
)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const real_T
*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(const
size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((const
void*const*)in)[11];const real_T*H3=(const real_T*)((const void*const*)in)[12]
;const real_T*Hx3=(const real_T*)((const void*const*)in)[13];const real_T*G3=(
const real_T*)((const void*const*)in)[14];const real_T*Gx3=(const real_T*)((
const void*const*)in)[15];const size_t*numEdges3=(const size_t*)((const void*
const*)in)[16];const size_t*bin3=(const size_t*)((const void*const*)in)[17];
const real_T*f=(const real_T*)((const void*const*)in)[18];const real_T*fx=(
const real_T*)((const void*const*)in)[19];const boolean_T*mode1=(const
boolean_T*)((const void*const*)in)[20];const boolean_T*mode2=(const boolean_T*
)((const void*const*)in)[21];const boolean_T*mode3=(const boolean_T*)((const
void*const*)in)[22];const size_t*n1=(const size_t*)((const void*const*)in)[23]
;const size_t*n2=(const size_t*)((const void*const*)in)[24];const size_t*n3=(
const size_t*)((const void*const*)in)[25];real_T*fi=(real_T*)out;
tlu2_3d_akima_linear_value(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,H3,Hx3,G3,Gx3,numEdges3,bin3,f,fx,mode1,mode2,mode3,n1,n2,n3);}
void tlu2_3d_akima_nearest_derivatives(real_T*fi,const real_T*H1,const real_T*
Hx1,const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t*bin1,
const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const size_t
*numEdges2,const size_t*bin2,const real_T*H3,const real_T*Hx3,const real_T*G3,
const real_T*Gx3,const size_t*numEdges3,const size_t*bin3,const real_T*f,const
real_T*fx1,const boolean_T*mode1,const boolean_T*mode2,const boolean_T*mode3,
const size_t*n1,const size_t*n2,const size_t*n3){ex_FcBoyAOGyQhIhHf_kb6OE_(fi,
H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,numEdges2,bin2,H3,Hx3,G3,Gx3,
numEdges3,bin3,f,fx1,mode1,mode2,mode3,n1,n2,n3,0.0,true);}void
tlu2_3d_akima_nearest_derivatives_custom_function_(void*out,const void*in){
const real_T*H1=(const real_T*)((const void*const*)in)[0];const real_T*Hx1=(
const real_T*)((const void*const*)in)[1];const real_T*G1=(const real_T*)((
const void*const*)in)[2];const real_T*Gx1=(const real_T*)((const void*const*)
in)[3];const size_t*numEdges1=(const size_t*)((const void*const*)in)[4];const
size_t*bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=(const
real_T*)((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((const void
*const*)in)[7];const real_T*G2=(const real_T*)((const void*const*)in)[8];const
real_T*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*numEdges2=(
const size_t*)((const void*const*)in)[10];const size_t*bin2=(const size_t*)((
const void*const*)in)[11];const real_T*H3=(const real_T*)((const void*const*)
in)[12];const real_T*Hx3=(const real_T*)((const void*const*)in)[13];const
real_T*G3=(const real_T*)((const void*const*)in)[14];const real_T*Gx3=(const
real_T*)((const void*const*)in)[15];const size_t*numEdges3=(const size_t*)((
const void*const*)in)[16];const size_t*bin3=(const size_t*)((const void*const*
)in)[17];const real_T*f=(const real_T*)((const void*const*)in)[18];const real_T
*fx=(const real_T*)((const void*const*)in)[19];const boolean_T*mode1=(const
boolean_T*)((const void*const*)in)[20];const boolean_T*mode2=(const boolean_T*
)((const void*const*)in)[21];const boolean_T*mode3=(const boolean_T*)((const
void*const*)in)[22];const size_t*n1=(const size_t*)((const void*const*)in)[23]
;const size_t*n2=(const size_t*)((const void*const*)in)[24];const size_t*n3=(
const size_t*)((const void*const*)in)[25];real_T*fi=(real_T*)out;
tlu2_3d_akima_nearest_derivatives(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,
Gx2,numEdges2,bin2,H3,Hx3,G3,Gx3,numEdges3,bin3,f,fx,mode1,mode2,mode3,n1,n2,
n3);}void tlu2_3d_akima_linear_derivatives(real_T*fi,const real_T*H1,const
real_T*Hx1,const real_T*G1,const real_T*Gx1,const size_t*numEdges1,const size_t
*bin1,const real_T*H2,const real_T*Hx2,const real_T*G2,const real_T*Gx2,const
size_t*numEdges2,const size_t*bin2,const real_T*H3,const real_T*Hx3,const
real_T*G3,const real_T*Gx3,const size_t*numEdges3,const size_t*bin3,const
real_T*f,const real_T*fx1,const boolean_T*mode1,const boolean_T*mode2,const
boolean_T*mode3,const size_t*n1,const size_t*n2,const size_t*n3){
ex_FcBoyAOGyQhIhHf_kb6OE_(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2,
numEdges2,bin2,H3,Hx3,G3,Gx3,numEdges3,bin3,f,fx1,mode1,mode2,mode3,n1,n2,n3,
1.0,true);}void tlu2_3d_akima_linear_derivatives_custom_function_(void*out,
const void*in){const real_T*H1=(const real_T*)((const void*const*)in)[0];const
real_T*Hx1=(const real_T*)((const void*const*)in)[1];const real_T*G1=(const
real_T*)((const void*const*)in)[2];const real_T*Gx1=(const real_T*)((const void
*const*)in)[3];const size_t*numEdges1=(const size_t*)((const void*const*)in)[4
];const size_t*bin1=(const size_t*)((const void*const*)in)[5];const real_T*H2=
(const real_T*)((const void*const*)in)[6];const real_T*Hx2=(const real_T*)((
const void*const*)in)[7];const real_T*G2=(const real_T*)((const void*const*)in
)[8];const real_T*Gx2=(const real_T*)((const void*const*)in)[9];const size_t*
numEdges2=(const size_t*)((const void*const*)in)[10];const size_t*bin2=(const
size_t*)((const void*const*)in)[11];const real_T*H3=(const real_T*)((const void
*const*)in)[12];const real_T*Hx3=(const real_T*)((const void*const*)in)[13];
const real_T*G3=(const real_T*)((const void*const*)in)[14];const real_T*Gx3=(
const real_T*)((const void*const*)in)[15];const size_t*numEdges3=(const size_t
*)((const void*const*)in)[16];const size_t*bin3=(const size_t*)((const void*
const*)in)[17];const real_T*f=(const real_T*)((const void*const*)in)[18];const
real_T*fx=(const real_T*)((const void*const*)in)[19];const boolean_T*mode1=(
const boolean_T*)((const void*const*)in)[20];const boolean_T*mode2=(const
boolean_T*)((const void*const*)in)[21];const boolean_T*mode3=(const boolean_T*
)((const void*const*)in)[22];const size_t*n1=(const size_t*)((const void*const
*)in)[23];const size_t*n2=(const size_t*)((const void*const*)in)[24];const
size_t*n3=(const size_t*)((const void*const*)in)[25];real_T*fi=(real_T*)out;
tlu2_3d_akima_linear_derivatives(fi,H1,Hx1,G1,Gx1,numEdges1,bin1,H2,Hx2,G2,Gx2
,numEdges2,bin2,H3,Hx3,G3,Gx3,numEdges3,bin3,f,fx,mode1,mode2,mode3,n1,n2,n3);
}static void ex_FcBoyAOGyQhIhHf_kb6OE_(real_T*fi,const real_T*H1,const real_T*
Hx1,const real_T*G1,const real_T*Gx1,const size_t*ex_koMwWVZ5kdO_cmNynyQJr7,
const size_t*ex_V5M9clt1oOxmhHN3Ehciw4,const real_T*H2,const real_T*Hx2,const
real_T*G2,const real_T*Gx2,const size_t*ex___TPtFdMIMdka1RE4RrHK5,const size_t
*ex_kwmw_QOG8uhxiTvKA_xa1Y,const real_T*H3,const real_T*Hx3,const real_T*G3,
const real_T*Gx3,const size_t*ex_VZ7ghYjIgM4UdqVbOYqmwq,const size_t*
ex_kqBPhXXIwWlQh5lks9Qd9B,const real_T*f,const real_T*fx1,const boolean_T*
mode1,const boolean_T*mode2,const boolean_T*mode3,const size_t*
ex_VMjU_zotmLxndPNpPFuHG9,const size_t*ex_VtVCgVxNcpd_YmPNQN4Ru7,const size_t*
ex__6OOHGUUNBKPcaYip0O_Dj,const real_T ex_F_tm5fod4xxuguhS49BSQm,const
boolean_T ex_kMAXUIgm88xvaunhJ2st8X){const size_t n1= *
ex_VMjU_zotmLxndPNpPFuHG9;const size_t n2= *ex_VtVCgVxNcpd_YmPNQN4Ru7;const
size_t n3= *ex__6OOHGUUNBKPcaYip0O_Dj;const size_t ex_FQ8I1Oq4CShSeySHdok3C7=
n1*n2;const size_t ex__f2__JfR9_hAeX8hDwMaow=ex_FQ8I1Oq4CShSeySHdok3C7*n3;
const real_T*ex__U2B3s_V9tO0_uYiotrZS5=fx1+ex__f2__JfR9_hAeX8hDwMaow;const
real_T*ex_kTU1pN1_cJ8Bb9gZ2xwW9n=ex__U2B3s_V9tO0_uYiotrZS5+
ex__f2__JfR9_hAeX8hDwMaow;const real_T*ex_k8zBiCVRtSWw_L3ohL9ZU6=
ex_kTU1pN1_cJ8Bb9gZ2xwW9n+ex__f2__JfR9_hAeX8hDwMaow;const real_T*
ex___7Lx6iTDDlF_TSpwiePYC=ex_k8zBiCVRtSWw_L3ohL9ZU6+ex__f2__JfR9_hAeX8hDwMaow;
const real_T*ex__I1KXJvl3c0VfehSr1Hfbk=ex___7Lx6iTDDlF_TSpwiePYC+
ex__f2__JfR9_hAeX8hDwMaow;const real_T*ex_kESK0x0mPXxyfXNDYQuNSo=
ex__I1KXJvl3c0VfehSr1Hfbk+ex__f2__JfR9_hAeX8hDwMaow;size_t numEdges1= *
ex_koMwWVZ5kdO_cmNynyQJr7;size_t numEdges2= *ex___TPtFdMIMdka1RE4RrHK5;size_t
numEdges3= *ex_VZ7ghYjIgM4UdqVbOYqmwq;size_t bin1= *ex_V5M9clt1oOxmhHN3Ehciw4;
size_t bin2= *ex_kwmw_QOG8uhxiTvKA_xa1Y;size_t bin3= *
ex_kqBPhXXIwWlQh5lks9Qd9B;size_t bin=bin1+n1*bin2+ex_FQ8I1Oq4CShSeySHdok3C7*
bin3;size_t ex_FnrjFNs9eQp9V5vCxPaoKw,ex_FRuIUemzxbdhfqkjXhoyK7,
ex_kRXTNbOCUd0KeHaF5Udb_Y;size_t ex_Fb8WfqABMs_vcqFzZf37Fa,
ex_k4UiAV7JSYpMjHsHDM_wV6,ex__Y8nRW2S0zdlXHnGSWOxB7;fi[0]=0.0;if(
ex_kMAXUIgm88xvaunhJ2st8X){fi[1]=0.0;fi[2]=0.0;}for(ex_kRXTNbOCUd0KeHaF5Udb_Y=
0;ex_kRXTNbOCUd0KeHaF5Udb_Y<numEdges3;++ex_kRXTNbOCUd0KeHaF5Udb_Y){
ex__Y8nRW2S0zdlXHnGSWOxB7=ex_FQ8I1Oq4CShSeySHdok3C7*ex_kRXTNbOCUd0KeHaF5Udb_Y+
bin;for(ex_FRuIUemzxbdhfqkjXhoyK7=0;ex_FRuIUemzxbdhfqkjXhoyK7<numEdges2;++
ex_FRuIUemzxbdhfqkjXhoyK7){ex_k4UiAV7JSYpMjHsHDM_wV6=n1*
ex_FRuIUemzxbdhfqkjXhoyK7+ex__Y8nRW2S0zdlXHnGSWOxB7;for(
ex_FnrjFNs9eQp9V5vCxPaoKw=0;ex_FnrjFNs9eQp9V5vCxPaoKw<numEdges1;++
ex_FnrjFNs9eQp9V5vCxPaoKw){ex_Fb8WfqABMs_vcqFzZf37Fa=ex_FnrjFNs9eQp9V5vCxPaoKw
+ex_k4UiAV7JSYpMjHsHDM_wV6;if(ex_kMAXUIgm88xvaunhJ2st8X){fi[0]+=((f[
ex_Fb8WfqABMs_vcqFzZf37Fa]*G1[ex_FnrjFNs9eQp9V5vCxPaoKw]+fx1[
ex_Fb8WfqABMs_vcqFzZf37Fa]*Gx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*H2[
ex_FRuIUemzxbdhfqkjXhoyK7]+(ex__U2B3s_V9tO0_uYiotrZS5[
ex_Fb8WfqABMs_vcqFzZf37Fa]*G1[ex_FnrjFNs9eQp9V5vCxPaoKw]+
ex_k8zBiCVRtSWw_L3ohL9ZU6[ex_Fb8WfqABMs_vcqFzZf37Fa]*Gx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*Hx2[ex_FRuIUemzxbdhfqkjXhoyK7])*H3[
ex_kRXTNbOCUd0KeHaF5Udb_Y]+((ex_kTU1pN1_cJ8Bb9gZ2xwW9n[
ex_Fb8WfqABMs_vcqFzZf37Fa]*G1[ex_FnrjFNs9eQp9V5vCxPaoKw]+
ex__I1KXJvl3c0VfehSr1Hfbk[ex_Fb8WfqABMs_vcqFzZf37Fa]*Gx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*H2[ex_FRuIUemzxbdhfqkjXhoyK7]+(
ex___7Lx6iTDDlF_TSpwiePYC[ex_Fb8WfqABMs_vcqFzZf37Fa]*G1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+ex_kESK0x0mPXxyfXNDYQuNSo[ex_Fb8WfqABMs_vcqFzZf37Fa
]*Gx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*Hx2[ex_FRuIUemzxbdhfqkjXhoyK7])*Hx3[
ex_kRXTNbOCUd0KeHaF5Udb_Y];fi[1]+=((f[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+fx1[ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*G2[ex_FRuIUemzxbdhfqkjXhoyK7]+(
ex__U2B3s_V9tO0_uYiotrZS5[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+ex_k8zBiCVRtSWw_L3ohL9ZU6[ex_Fb8WfqABMs_vcqFzZf37Fa
]*Hx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*Gx2[ex_FRuIUemzxbdhfqkjXhoyK7])*H3[
ex_kRXTNbOCUd0KeHaF5Udb_Y]+((ex_kTU1pN1_cJ8Bb9gZ2xwW9n[
ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[ex_FnrjFNs9eQp9V5vCxPaoKw]+
ex__I1KXJvl3c0VfehSr1Hfbk[ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*G2[ex_FRuIUemzxbdhfqkjXhoyK7]+(
ex___7Lx6iTDDlF_TSpwiePYC[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+ex_kESK0x0mPXxyfXNDYQuNSo[ex_Fb8WfqABMs_vcqFzZf37Fa
]*Hx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*Gx2[ex_FRuIUemzxbdhfqkjXhoyK7])*Hx3[
ex_kRXTNbOCUd0KeHaF5Udb_Y];fi[2]+=((f[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+fx1[ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*H2[ex_FRuIUemzxbdhfqkjXhoyK7]+(
ex__U2B3s_V9tO0_uYiotrZS5[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+ex_k8zBiCVRtSWw_L3ohL9ZU6[ex_Fb8WfqABMs_vcqFzZf37Fa
]*Hx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*Hx2[ex_FRuIUemzxbdhfqkjXhoyK7])*G3[
ex_kRXTNbOCUd0KeHaF5Udb_Y]+((ex_kTU1pN1_cJ8Bb9gZ2xwW9n[
ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[ex_FnrjFNs9eQp9V5vCxPaoKw]+
ex__I1KXJvl3c0VfehSr1Hfbk[ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*H2[ex_FRuIUemzxbdhfqkjXhoyK7]+(
ex___7Lx6iTDDlF_TSpwiePYC[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+ex_kESK0x0mPXxyfXNDYQuNSo[ex_Fb8WfqABMs_vcqFzZf37Fa
]*Hx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*Hx2[ex_FRuIUemzxbdhfqkjXhoyK7])*Gx3[
ex_kRXTNbOCUd0KeHaF5Udb_Y];}else{fi[0]+=((f[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+fx1[ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*H2[ex_FRuIUemzxbdhfqkjXhoyK7]+(
ex__U2B3s_V9tO0_uYiotrZS5[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+ex_k8zBiCVRtSWw_L3ohL9ZU6[ex_Fb8WfqABMs_vcqFzZf37Fa
]*Hx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*Hx2[ex_FRuIUemzxbdhfqkjXhoyK7])*H3[
ex_kRXTNbOCUd0KeHaF5Udb_Y]+((ex_kTU1pN1_cJ8Bb9gZ2xwW9n[
ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[ex_FnrjFNs9eQp9V5vCxPaoKw]+
ex__I1KXJvl3c0VfehSr1Hfbk[ex_Fb8WfqABMs_vcqFzZf37Fa]*Hx1[
ex_FnrjFNs9eQp9V5vCxPaoKw])*H2[ex_FRuIUemzxbdhfqkjXhoyK7]+(
ex___7Lx6iTDDlF_TSpwiePYC[ex_Fb8WfqABMs_vcqFzZf37Fa]*H1[
ex_FnrjFNs9eQp9V5vCxPaoKw]+ex_kESK0x0mPXxyfXNDYQuNSo[ex_Fb8WfqABMs_vcqFzZf37Fa
]*Hx1[ex_FnrjFNs9eQp9V5vCxPaoKw])*Hx2[ex_FRuIUemzxbdhfqkjXhoyK7])*Hx3[
ex_kRXTNbOCUd0KeHaF5Udb_Y];}}}}}
