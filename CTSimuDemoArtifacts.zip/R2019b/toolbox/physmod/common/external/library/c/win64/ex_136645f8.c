#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
real_T ex_kpX___S1Lgx3hu0ti95uMw(const real_T*a,const size_t n);real_T
ex_VCMYZqH7FzWLWPHooBByoI(const real_T x);void ex_ktEh0_dPE7WMZaXpgviZfL(
real_T*fx1,real_T*ex__rg5CXJeg_Cndu5WDoxbMl,real_T*ex_V5xxz05F7a_ihqj30K8FAv,
real_T*ex_FNXAh_ftg_KpWeXlYDyRqE,const real_T*x1,const real_T*f,const size_t n1
,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex__dZ6arJEU5pmV9XKy8etwi,const size_t ex_VvovjV_Yc_G4fP1XodrLft,const size_t
ex_VhUgI4c0k9GOgm8dFTThdK,const size_t ex_Fsdzbs_wz00cfyfchwr6K7,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS);void ex_VKUiWhgLteGl_1sCHRJXum(real_T*
ex_k8zBiCVRtSWw_L3ohL9ZU6,real_T*ex__q3Je3USIpxhYaV_bmlNgE,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF);void ex_F7_9Sgo0sqlceT8kkrDtm9(real_T*
ex_kESK0x0mPXxyfXNDYQuNSo,real_T*ex__idLDQm5dX_uePEg9ek_dK,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t ex__Et5EUn_AfCGcaoPYM3rE7,const size_t
ex_VRc9H9oEh84hXu9Yu4okxd,const size_t ex__vFO6imE0nOcdTAyK5nWZf,const size_t
ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t ex_k64KfxW_YeCBd1Jcztnal5,const size_t
ex_FpCuD8p2g1ldYupGLDualI,const size_t ex_F4NwsNKf_S_ubm278AmjEt,const size_t
ex_VzS__hA47OtneLeQmJKhJU,const size_t ex_VseJVSrhmHl_fHMdqZQUoK,const size_t
ex__zov1f51H_xVZDV3hSAwLo,const size_t ex__UCiJ_ovpi8viepU66XSz1,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS,const real_T ex__QgqlEW2f18scLxPhDEnMF,const real_T
ex__yrlSbVOXjWXaTMEdN9cIu);void ex_Futd5IPo6_Sea16WtbGVmf(real_T*
ex__nq35K78gNGYiPqAi6FlY1,real_T*ex_k7clpQTkJip2cDihM27xMo,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const real_T*
ex__4uaYPi3B7txZPrRD2z8ek,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const size_t ex_VzS__hA47OtneLeQmJKhJU,const size_t
ex_VseJVSrhmHl_fHMdqZQUoK,const size_t ex__zov1f51H_xVZDV3hSAwLo,const size_t
ex__UCiJ_ovpi8viepU66XSz1,const size_t ex_FDTDXUQhgm_eYmdJ8sNRVZ,const size_t
ex_VlNl_tKLFzxvYHI0dZ9wzf,const size_t ex_kiGZSX33fPpmaucBO5il15,const size_t
ex__1tnMVPyaKpZeawGCX2ExG,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF,const real_T ex__yrlSbVOXjWXaTMEdN9cIu,const real_T
ex_F1sFV5GwlJdShuwH_gb9cU);size_t ex_F0HBEJ7qD9OkfDK6FdP9lf(real_T*H,real_T*Hx
,real_T*G,real_T*Gx,size_t*numEdges,const real_T*x,const size_t n,const real_T
t,const boolean_T*mode,const real_T ex_F_tm5fod4xxuguhS49BSQm,const boolean_T
ex_kMAXUIgm88xvaunhJ2st8X);size_t ex_FSBp3lkv5gpCXL2yT9vLNh(const real_T*x,
const size_t n,const real_T t);void ex_kGRJvwU4WMthWL53sjRCpO(real_T*
ex_F2l4p_g4sn02huHNflQjMH,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT);void ex_FtfBZE2kLGxyWamCvlRfeQ(real_T*x,real_T*f,
const size_t n);void ex_F4LajttG6uGtbXBJgUNQpW(real_T*x1,real_T*x2,real_T*f,
const size_t n1,const size_t n2);void ex_kIBgcKPC9nhchTKovcabSa(real_T*x1,
real_T*x2,real_T*x3,real_T*f,const size_t n1,const size_t n2,const size_t n3);
void ex_F_6wSEEsvm_1cTAuvwDt9B(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*
f,const size_t n1,const size_t n2,const size_t n3,const size_t n4);
#include "pm_std.h"
#include "lang_std.h"
#include "string.h"
static void ex_F4J173IGY_hgXaf_WD6AOj(real_T*fi,const real_T*H,const real_T*Hx
,const real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const
real_T*f,const real_T*fx,const boolean_T*mode,const size_t*n,const real_T
ex_F_tm5fod4xxuguhS49BSQm,const boolean_T ex_kMAXUIgm88xvaunhJ2st8X);static
void ex_kYk7SswBvLtHbmZRWvRMEh(real_T*x,real_T*f,real_T*fx,real_T*bv,const
real_T*xs,const real_T*fs,const size_t n);void tlu2_1d_akima_nearest_process(
real_T*x,real_T*f,real_T*fx,real_T*bv,const real_T*xs,const real_T*fs,const
size_t*n){ex_kYk7SswBvLtHbmZRWvRMEh(x,f,fx,bv,xs,fs,*n);}void
tlu2_1d_akima_nearest_process_custom_function_(void*out,const void*in){const
real_T*xs=(const real_T*)((const void*const*)in)[0];const real_T*fs=(const
real_T*)((const void*const*)in)[1];const size_t*n=(const size_t*)((const void*
const*)in)[2];real_T*x=(real_T*)((void**)out)[0];real_T*f=(real_T*)((void**)
out)[1];real_T*fx=(real_T*)((void**)out)[2];real_T*bv=(real_T*)((void**)out)[3
];tlu2_1d_akima_nearest_process(x,f,fx,bv,xs,fs,n);}void
tlu2_1d_akima_linear_process(real_T*x,real_T*f,real_T*fx,real_T*bv,const real_T
*xs,const real_T*fs,const size_t*n){ex_kYk7SswBvLtHbmZRWvRMEh(x,f,fx,bv,xs,fs,
*n);}void tlu2_1d_akima_linear_process_custom_function_(void*out,const void*in
){const real_T*xs=(const real_T*)((const void*const*)in)[0];const real_T*fs=(
const real_T*)((const void*const*)in)[1];const size_t*n=(const size_t*)((const
void*const*)in)[2];real_T*x=(real_T*)((void**)out)[0];real_T*f=(real_T*)((void
**)out)[1];real_T*fx=(real_T*)((void**)out)[2];real_T*bv=(real_T*)((void**)out
)[3];tlu2_1d_akima_linear_process(x,f,fx,bv,xs,fs,n);}static void
ex_kYk7SswBvLtHbmZRWvRMEh(real_T*x,real_T*f,real_T*fx,real_T*bv,const real_T*
xs,const real_T*fs,const size_t n){const real_T ex_FfDTppU8N_tOWuLK37x_08=
1.0e-12;real_T*ex__1EFbmUY_TlBhLJH5Hc_gX=pmf_calloc(n-1,sizeof(real_T));real_T
*ex_F5sdvPXYnk4WeLdUuXJHoP=pmf_calloc(n+1,sizeof(real_T));real_T*
ex_FyavW58i3AxTYa77Kzq1uq=pmf_calloc(n+2,sizeof(real_T));real_T
ex_kZ71d5LLSC09empYr7uPmw,ex_Vza442yC9_C6X9ReplTSo5;memcpy(x,xs,n*sizeof(
real_T));memcpy(f,fs,n*sizeof(real_T));ex_FtfBZE2kLGxyWamCvlRfeQ(x,f,n);bv[0]=
x[0];bv[1]=x[n-1];ex_kZ71d5LLSC09empYr7uPmw=ex_VCMYZqH7FzWLWPHooBByoI(x[n-1]-x
[0])+ex_FfDTppU8N_tOWuLK37x_08;ex_Vza442yC9_C6X9ReplTSo5=
ex_kpX___S1Lgx3hu0ti95uMw(f,n)+ex_FfDTppU8N_tOWuLK37x_08;
ex_ktEh0_dPE7WMZaXpgviZfL(fx,ex_FyavW58i3AxTYa77Kzq1uq,
ex__1EFbmUY_TlBhLJH5Hc_gX,ex_F5sdvPXYnk4WeLdUuXJHoP,x,f,n,1,1,1,1,0,0,0,1,0,0,
0,1,0,0,0,ex_FfDTppU8N_tOWuLK37x_08*ex_Vza442yC9_C6X9ReplTSo5/
ex_kZ71d5LLSC09empYr7uPmw);pmf_free(ex__1EFbmUY_TlBhLJH5Hc_gX);pmf_free(
ex_F5sdvPXYnk4WeLdUuXJHoP);pmf_free(ex_FyavW58i3AxTYa77Kzq1uq);}void
tlu2_1d_akima_nearest_value(real_T*fi,const real_T*H,const real_T*Hx,const
real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const real_T*f
,const real_T*fx,const boolean_T*mode,const size_t*n){
ex_F4J173IGY_hgXaf_WD6AOj(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n,0.0,false);}
void tlu2_1d_akima_nearest_value_custom_function_(void*out,const void*in){
const real_T*H=(const real_T*)((const void*const*)in)[0];const real_T*Hx=(
const real_T*)((const void*const*)in)[1];const real_T*G=(const real_T*)((const
void*const*)in)[2];const real_T*Gx=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges=(const size_t*)((const void*const*)in)[4];const size_t*
bin=(const size_t*)((const void*const*)in)[5];const real_T*f=(const real_T*)((
const void*const*)in)[6];const real_T*fx=(const real_T*)((const void*const*)in
)[7];const boolean_T*mode=(const boolean_T*)((const void*const*)in)[8];const
size_t*n=(const size_t*)((const void*const*)in)[9];real_T*fi=(real_T*)out;
tlu2_1d_akima_nearest_value(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n);}void
tlu2_1d_akima_linear_value(real_T*fi,const real_T*H,const real_T*Hx,const
real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const real_T*f
,const real_T*fx,const boolean_T*mode,const size_t*n){
ex_F4J173IGY_hgXaf_WD6AOj(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n,1.0,false);}
void tlu2_1d_akima_linear_value_custom_function_(void*out,const void*in){const
real_T*H=(const real_T*)((const void*const*)in)[0];const real_T*Hx=(const
real_T*)((const void*const*)in)[1];const real_T*G=(const real_T*)((const void*
const*)in)[2];const real_T*Gx=(const real_T*)((const void*const*)in)[3];const
size_t*numEdges=(const size_t*)((const void*const*)in)[4];const size_t*bin=(
const size_t*)((const void*const*)in)[5];const real_T*f=(const real_T*)((const
void*const*)in)[6];const real_T*fx=(const real_T*)((const void*const*)in)[7];
const boolean_T*mode=(const boolean_T*)((const void*const*)in)[8];const size_t
*n=(const size_t*)((const void*const*)in)[9];real_T*fi=(real_T*)out;
tlu2_1d_akima_linear_value(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n);}void
tlu2_1d_akima_nearest_derivatives(real_T*fi,const real_T*H,const real_T*Hx,
const real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const
real_T*f,const real_T*fx,const boolean_T*mode,const size_t*n){
ex_F4J173IGY_hgXaf_WD6AOj(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n,0.0,true);}
void tlu2_1d_akima_nearest_derivatives_custom_function_(void*out,const void*in
){const real_T*H=(const real_T*)((const void*const*)in)[0];const real_T*Hx=(
const real_T*)((const void*const*)in)[1];const real_T*G=(const real_T*)((const
void*const*)in)[2];const real_T*Gx=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges=(const size_t*)((const void*const*)in)[4];const size_t*
bin=(const size_t*)((const void*const*)in)[5];const real_T*f=(const real_T*)((
const void*const*)in)[6];const real_T*fx=(const real_T*)((const void*const*)in
)[7];const boolean_T*mode=(const boolean_T*)((const void*const*)in)[8];const
size_t*n=(const size_t*)((const void*const*)in)[9];real_T*fi=(real_T*)out;
tlu2_1d_akima_nearest_derivatives(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n);}void
tlu2_1d_akima_linear_derivatives(real_T*fi,const real_T*H,const real_T*Hx,
const real_T*G,const real_T*Gx,const size_t*numEdges,const size_t*bin,const
real_T*f,const real_T*fx,const boolean_T*mode,const size_t*n){
ex_F4J173IGY_hgXaf_WD6AOj(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n,1.0,true);}
void tlu2_1d_akima_linear_derivatives_custom_function_(void*out,const void*in)
{const real_T*H=(const real_T*)((const void*const*)in)[0];const real_T*Hx=(
const real_T*)((const void*const*)in)[1];const real_T*G=(const real_T*)((const
void*const*)in)[2];const real_T*Gx=(const real_T*)((const void*const*)in)[3];
const size_t*numEdges=(const size_t*)((const void*const*)in)[4];const size_t*
bin=(const size_t*)((const void*const*)in)[5];const real_T*f=(const real_T*)((
const void*const*)in)[6];const real_T*fx=(const real_T*)((const void*const*)in
)[7];const boolean_T*mode=(const boolean_T*)((const void*const*)in)[8];const
size_t*n=(const size_t*)((const void*const*)in)[9];real_T*fi=(real_T*)out;
tlu2_1d_akima_linear_derivatives(fi,H,Hx,G,Gx,numEdges,bin,f,fx,mode,n);}
static void ex_F4J173IGY_hgXaf_WD6AOj(real_T*fi,const real_T*H,const real_T*Hx
,const real_T*G,const real_T*Gx,const size_t*ex_VcmHWq3nTKx8_LXu6tlwuC,const
size_t*ex_F7H2tSYw2e8bdTAaOONgVs,const real_T*f,const real_T*fx,const boolean_T
*mode,const size_t*n,const real_T ex_F_tm5fod4xxuguhS49BSQm,const boolean_T
ex_kMAXUIgm88xvaunhJ2st8X){size_t numEdges= *ex_VcmHWq3nTKx8_LXu6tlwuC;size_t
bin= *ex_F7H2tSYw2e8bdTAaOONgVs;if(ex_kMAXUIgm88xvaunhJ2st8X){if(numEdges<2){
fi[0]=0.0;}else{fi[0]=f[bin]*G[0]+f[bin+1]*G[1]+fx[bin]*Gx[0]+fx[bin+1]*Gx[1];
}}else{if(numEdges<2){fi[0]=f[0];}else{fi[0]=f[bin]*H[0]+f[bin+1]*H[1]+fx[bin]
*Hx[0]+fx[bin+1]*Hx[1];}}}
