#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
int_T pm_kkW9oQAVI7Wt_9Rzuat5bx(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t pm_keOJjiAyBTtFhyWf033kni,size_t pm_kJxontPsxndNYXwDXdE1iy,size_t
pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
PmSparsityPattern*pm_create_sparsity_pattern(size_t pm_keOJjiAyBTtFhyWf033kni,
size_t pm_kJxontPsxndNYXwDXdE1iy,size_t pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kTFq3qlgTulWiT6pafkmmT(PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);
boolean_T pm__ZRI70SuGwhmamUtcsoyxS(const PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);
PmSparsityPattern*pm_FQMLyYzCQ5CtgHjze1nNJP(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FvcKvutPfxG9Xe1kjs7gg0(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);void pm_VYooJBURCwKrVu6RXzQZ_5(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm__YwdRBXissh3bPWPl30Fpe(size_t
pm_FW8nEXbTFjdJhTIKepsgFT,size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm_FFniD_kRQg_JWTYc5cmjGs(size_t
pm_FW8nEXbTFjdJhTIKepsgFT,size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm_FhqtSrxlPotrcypQHJ9Dcq(size_t
pm__lqjegyKuwStj56WZLiC_e,size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm__TNI3M36rThlaTetY4tWiB(size_t n,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_rv_equals_rv(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_VeeoZXnlJQ4u_112lGs8YD(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);
boolean_T pm_FltUsml2sTlHZuCkbw_pdM(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);
boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);
boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);int_T
pm_create_real_vector_fields(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_create_real_vector(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(const PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VeffaD_A8DxagH31Usec1H(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_destroy_real_vector(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_int_vector_fields(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm_create_int_vector(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmIntVector*
pm__fSS_VMqhWlobeqe6mQF_x(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_V_eFnKjg5I4Uc1DwG4yU27(
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_destroy_int_vector(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_bool_vector_fields(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmBoolVector*pm__jbisDMumXdocXANx5LhhY(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_kia_QXK77_xDg9M1NzHr3r(
PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm_kpRdzyG9L_8MV5lRovACCg(
const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_VH4is_vKxDpFiupATTqV_4(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_FaBQ30lWObWMi1zpzQ_EZG(
PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc__0IkRn0eQ9Wc_u8mCNbQDh
(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc_kMScbNM1RKOTaD4QwTME8Y(
const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*mc_VlnhKi82gfCLgumIqeduOq);void
mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(const PmRealVector*
mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,
const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void mc__NertSre4cWh_mN2RJ5UPq(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*pm_VCVhWy_VaDhraHrlfFWxBa);
PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const PmRealVector*
mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);PmSparsityPattern*mc_kAZzxJsz9tloc11S9uThaF(const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void mc_klSR73f0rO4LhXVlV6gmb7(real_T*
mc_FkvBQdfnWOCY_uJC_r4riI,const PmSparsityPattern*mc__z_znac6SDtIeyvo_HaL8F,
const real_T*mc_F2l4p_g4sn02huHNflQjMH,const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI);void mc_FXA9yTEpI9pfhyLrn8ZGts(PmSparsityPattern*
mc_VO4ezo9C6qdUWq1Fln4EVt,PmRealVector*mc_kfuTzKNJF8C9XawgZFM5k9);
PmSparsityPattern*mc_V_3Bm28Cx08dj9ZMdrwaJg(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const
PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*mc__qAqv2Z2m7K0VPPGKiCpwD(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const
PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*mc__mBVa3_c658wjuT_cJe_Qy(const PmSparsityPattern*b,const
PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC,const PmBoolVector*
pm_VCVhWy_VaDhraHrlfFWxBa,PmAllocator*mc_FZx3iFiX1YW7j5eEojoAPc);void
mc_Fv2sZggivbSOc5zulDbRra(const PmRealVector*mc_k5z61obNZCWCbyygZn_fdK,const
real_T*mc__uV9GcaXWFlx_5jfPip5Mo,const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const
PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH);PmSparsityPattern*
mc__JB9jUvbb10FaTie1cmY8_(const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,
size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t mc_knvTkz3vM6t4a9WNgNRMzB,size_t
mc_VGPLyQQmjMlldLbUiddSkc,size_t mc_Fp_w9JW6vqt5eXL55IL0g1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*mc_VINzQey3e2GxYDxzr7cOY_(const
PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,size_t mc_Fxvltms7Im4baT5ZPxj7f2,
size_t mc_knvTkz3vM6t4a9WNgNRMzB,size_t mc_VGPLyQQmjMlldLbUiddSkc,size_t
mc_Fp_w9JW6vqt5eXL55IL0g1,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
mc_Fzylow9cnZxIhyL1O9nM0I(const PmRealVector*mc_VIutEr_JmfWNeDyKonnHVk,const
PmRealVector*mc_VW_HqYZElHCjWHwd6Iv4ON,const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t
mc_knvTkz3vM6t4a9WNgNRMzB,size_t mc_VGPLyQQmjMlldLbUiddSkc,size_t
mc_Fp_w9JW6vqt5eXL55IL0g1);void mc_FY8ifnDZsXphdqo3UGrtOk(PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,size_t n);void mc_kNxwVTI76g4kj9P52yKhA5(
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,size_t n);PmSparsityPattern*
mc_kNYMmfXA1XtHcmiWCr7l_C(const PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*
mc_VJlBwQnSeLpciXVTLb_llB(const PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*
mc__5C6m_ZyP9_NYekcJCEULM(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void mc__8x7kz_627_gXDli_FJo22(const PmRealVector*
mc_kuYGZlr6GiOSeqresCsPcM,const PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR,
const PmRealVector*mc_FmeGGSq6P2_Kg9j7twxwci,const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,const PmRealVector*mc_FQSQWg_QFOKIWm9DWdLQR6,const
PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,const PmRealVector*
mc_krOJvR5Qa1KQZu3eEsQtEU);PmSparsityPattern*mc_kyCwDjPxmBGRiTH73vrjJL(const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const PmSparsityPattern*
mc_VLr_Ia18P_8icXM9WFOfYI,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
mc__tyTSVoY7fpafmg4sUl1P3(const PmRealVector*mc_kuYGZlr6GiOSeqresCsPcM,const
PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR,const PmRealVector*
mc_FmeGGSq6P2_Kg9j7twxwci,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmRealVector*mc_FQSQWg_QFOKIWm9DWdLQR6,const PmSparsityPattern*
mc_VLr_Ia18P_8icXM9WFOfYI,const PmRealVector*mc_krOJvR5Qa1KQZu3eEsQtEU);
PmSparsityPattern*mc_VI58f6RQKXS_Y5sclnoOPT(const PmSparsityPattern*a,const
PmSparsityPattern*b,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
#include "string.h"
PmSparsityPattern*mc_kAZzxJsz9tloc11S9uThaF(const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,PmAllocator*pm__8zlSpb2Hixod149p2zadR){size_t
mc__jwySfHyx1SXgXJeVWoIzb=mc_V_ku0ZO8TOxhc9438tlsBI->mNumCol;size_t
mc_FdNKyaRLqeWhg5tGqF_VYT=mc_V_ku0ZO8TOxhc9438tlsBI->mNumRow;size_t
mc_kNgcOktCtQxdYedrGvFn5i=((size_t)(mc_V_ku0ZO8TOxhc9438tlsBI)->mJc[(
mc_V_ku0ZO8TOxhc9438tlsBI)->mNumCol]);int32_T*mc__GGFaLirzMOkais94_xH_b=
mc_V_ku0ZO8TOxhc9438tlsBI->mJc;int32_T*mc_FGty7dNhdoxeiPHYbn7B52=
mc_V_ku0ZO8TOxhc9438tlsBI->mIr;int32_T*mc_k8K14pYI93OLZLYgNQPjFw,*
mc__2aeAol_qBdmiyUh6cJk3b;size_t mc_kwrB3ZoKf7OufTHWaHJV7a,
mc_kyp6uAyJE40UVuAQNEYzS1;PmSparsityPattern*mc__z_znac6SDtIeyvo_HaL8F=(
PmSparsityPattern*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(1),(sizeof(PmSparsityPattern))));
mc__z_znac6SDtIeyvo_HaL8F->mNumCol=mc_FdNKyaRLqeWhg5tGqF_VYT;
mc__z_znac6SDtIeyvo_HaL8F->mNumRow=mc__jwySfHyx1SXgXJeVWoIzb;
mc_k8K14pYI93OLZLYgNQPjFw=mc__z_znac6SDtIeyvo_HaL8F->mJc=(int32_T*)((
pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(
mc_FdNKyaRLqeWhg5tGqF_VYT+1),(sizeof(int32_T))));mc__2aeAol_qBdmiyUh6cJk3b=
mc__z_znac6SDtIeyvo_HaL8F->mIr=(int32_T*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(mc_kNgcOktCtQxdYedrGvFn5i),(sizeof(
int32_T))));for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_kNgcOktCtQxdYedrGvFn5i;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_k8K14pYI93OLZLYgNQPjFw[mc_FGty7dNhdoxeiPHYbn7B52[mc_kwrB3ZoKf7OufTHWaHJV7a]
]++;}for(mc_kwrB3ZoKf7OufTHWaHJV7a=1;mc_kwrB3ZoKf7OufTHWaHJV7a<=
mc_FdNKyaRLqeWhg5tGqF_VYT;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_k8K14pYI93OLZLYgNQPjFw[mc_kwrB3ZoKf7OufTHWaHJV7a]+=
mc_k8K14pYI93OLZLYgNQPjFw[mc_kwrB3ZoKf7OufTHWaHJV7a-1];}for(
mc_kyp6uAyJE40UVuAQNEYzS1=mc__jwySfHyx1SXgXJeVWoIzb-1;
mc_kyp6uAyJE40UVuAQNEYzS1+1!=0;mc_kyp6uAyJE40UVuAQNEYzS1--){int32_T
mc_V5XnIQ0HZCxrbPmX4D3LbT;for(mc_V5XnIQ0HZCxrbPmX4D3LbT=
mc__GGFaLirzMOkais94_xH_b[mc_kyp6uAyJE40UVuAQNEYzS1];mc_V5XnIQ0HZCxrbPmX4D3LbT
<mc__GGFaLirzMOkais94_xH_b[mc_kyp6uAyJE40UVuAQNEYzS1+1];
mc_V5XnIQ0HZCxrbPmX4D3LbT++){mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_FGty7dNhdoxeiPHYbn7B52[mc_V5XnIQ0HZCxrbPmX4D3LbT];mc__2aeAol_qBdmiyUh6cJk3b
[--mc_k8K14pYI93OLZLYgNQPjFw[mc_kwrB3ZoKf7OufTHWaHJV7a]]=((int32_T)(
mc_kyp6uAyJE40UVuAQNEYzS1));}};return mc__z_znac6SDtIeyvo_HaL8F;}void
mc_klSR73f0rO4LhXVlV6gmb7(real_T*mc_FkvBQdfnWOCY_uJC_r4riI,const
PmSparsityPattern*mc__z_znac6SDtIeyvo_HaL8F,const real_T*
mc_F2l4p_g4sn02huHNflQjMH,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI){
size_t mc__jwySfHyx1SXgXJeVWoIzb=mc_V_ku0ZO8TOxhc9438tlsBI->mNumCol;int32_T*
mc__GGFaLirzMOkais94_xH_b=mc_V_ku0ZO8TOxhc9438tlsBI->mJc;int32_T*
mc_FGty7dNhdoxeiPHYbn7B52=mc_V_ku0ZO8TOxhc9438tlsBI->mIr;int32_T*
mc_k8K14pYI93OLZLYgNQPjFw=mc__z_znac6SDtIeyvo_HaL8F->mJc;size_t
mc_kwrB3ZoKf7OufTHWaHJV7a,mc_kyp6uAyJE40UVuAQNEYzS1;for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc__jwySfHyx1SXgXJeVWoIzb;mc_kyp6uAyJE40UVuAQNEYzS1++){int32_T
mc_V5XnIQ0HZCxrbPmX4D3LbT;for(mc_V5XnIQ0HZCxrbPmX4D3LbT=
mc__GGFaLirzMOkais94_xH_b[mc_kyp6uAyJE40UVuAQNEYzS1];mc_V5XnIQ0HZCxrbPmX4D3LbT
<mc__GGFaLirzMOkais94_xH_b[mc_kyp6uAyJE40UVuAQNEYzS1+1];
mc_V5XnIQ0HZCxrbPmX4D3LbT++){mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_FGty7dNhdoxeiPHYbn7B52[mc_V5XnIQ0HZCxrbPmX4D3LbT];mc_FkvBQdfnWOCY_uJC_r4riI
[mc_k8K14pYI93OLZLYgNQPjFw[mc_kwrB3ZoKf7OufTHWaHJV7a]++]=
mc_F2l4p_g4sn02huHNflQjMH[mc_V5XnIQ0HZCxrbPmX4D3LbT];}}memmove(&
mc_k8K14pYI93OLZLYgNQPjFw[1],mc_k8K14pYI93OLZLYgNQPjFw,
mc__z_znac6SDtIeyvo_HaL8F->mNumCol*sizeof(int32_T));mc_k8K14pYI93OLZLYgNQPjFw[
0]=0;}void mc_FXA9yTEpI9pfhyLrn8ZGts(PmSparsityPattern*
mc_VO4ezo9C6qdUWq1Fln4EVt,PmRealVector*mc_kfuTzKNJF8C9XawgZFM5k9){int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a=0;int32_T mc__WoC_1CVq_xCVaNeWtt2OB=((int32_T)(
mc_VO4ezo9C6qdUWq1Fln4EVt->mNumCol));int32_T mc_FQhc2zS5zmGug5tCROrz9Q=
mc_VO4ezo9C6qdUWq1Fln4EVt->mJc[mc__WoC_1CVq_xCVaNeWtt2OB];int32_T
mc_FiS0XlSTkIO8Y5NatVd27K=0,mc_FK8hugJu4VGtXXDuu21E8N=0;int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc_VO4ezo9C6qdUWq1Fln4EVt->mJc;int32_T*
mc_kGzac_K2Srh7amdEOS00Xm=mc_VO4ezo9C6qdUWq1Fln4EVt->mJc+
mc__WoC_1CVq_xCVaNeWtt2OB+1;int32_T*mc_VEXzFHKjFN87iiOtLrddNz=
mc_VO4ezo9C6qdUWq1Fln4EVt->mIr;real_T*mc_klotywLHL8_JfinmQwixPW=NULL;;;
mc_klotywLHL8_JfinmQwixPW=mc_kfuTzKNJF8C9XawgZFM5k9->mX;
mc_FiS0XlSTkIO8Y5NatVd27K=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_FQhc2zS5zmGug5tCROrz9Q;mc_kwrB3ZoKf7OufTHWaHJV7a
++){while(*mc_kXeDcvuOSpSqamcA4a5jc_==mc_kwrB3ZoKf7OufTHWaHJV7a){*
mc_kXeDcvuOSpSqamcA4a5jc_++-=mc_FiS0XlSTkIO8Y5NatVd27K;}if(
mc_klotywLHL8_JfinmQwixPW[mc_kwrB3ZoKf7OufTHWaHJV7a]==0.0){
mc_FiS0XlSTkIO8Y5NatVd27K++;}else{mc_VEXzFHKjFN87iiOtLrddNz[
mc_kwrB3ZoKf7OufTHWaHJV7a-mc_FiS0XlSTkIO8Y5NatVd27K]=mc_VEXzFHKjFN87iiOtLrddNz
[mc_kwrB3ZoKf7OufTHWaHJV7a];mc_klotywLHL8_JfinmQwixPW[
mc_kwrB3ZoKf7OufTHWaHJV7a-mc_FiS0XlSTkIO8Y5NatVd27K]=mc_klotywLHL8_JfinmQwixPW
[mc_kwrB3ZoKf7OufTHWaHJV7a];}}mc_kfuTzKNJF8C9XawgZFM5k9->mN=
mc_FQhc2zS5zmGug5tCROrz9Q-mc_FiS0XlSTkIO8Y5NatVd27K;;while(
mc_kXeDcvuOSpSqamcA4a5jc_!=mc_kGzac_K2Srh7amdEOS00Xm){*
mc_kXeDcvuOSpSqamcA4a5jc_++-=mc_FiS0XlSTkIO8Y5NatVd27K;};}static
PmSparsityPattern*mc_kRhnXRy_F3OLcu26HcqOKB(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*mc_FIRQmUoZ8GOih5Os6NY5A_,const
PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH,PmAllocator*pm__8zlSpb2Hixod149p2zadR,
boolean_T mc_VX7HfGsCn0KZdLvyd11xid){int32_T*mc___zo4Li75yK0YLHAVMctDw=
pm__HVqeFmd5gKdguw04VZTsk->mIr;int32_T*mc_FiHVcEQROGW8_HIfdPn0j3=NULL;int32_T*
mc_Fp5npk_4EItUj9RiETHm6R=pm__HVqeFmd5gKdguw04VZTsk->mJc;int32_T*
mc_kLo3PhvBON8qYaxOFVgaFS=NULL;size_t mc__2KDWyiJeY4Pj1erRpfNCC=0,
mc_FYv4y94626tPV1FSsbbP56=0,mc_F8fEsD1Otn_HiX9tvTISDv=0,
pm_Fr_bHKkQKFWbfi50VWd5Pw=0,pm_kplAJmOlA30feiNcOzi7oj=0,
mc_kTYDEKlBgFdmfXNFRlIAsd=0,mc_V2Ap3MG6qy_ijioo_xKfYu=0,
mc__1w3rrAoDPWHdX86QQPNUm=0;size_t mc_k9MbS8ximDhyae2LODIlRL=
pm__HVqeFmd5gKdguw04VZTsk->mNumRow,mc__9lYVjpAT5x_Y5qsCgHlRA=
pm__HVqeFmd5gKdguw04VZTsk->mNumCol;PmSparsityPattern*mc_VwTH0kBm_KtWVyf9lUFfw7
=(PmSparsityPattern*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(1),(sizeof(PmSparsityPattern))));size_t*
mc__G2DbMuk5LSFXLoD15I6CL=(size_t*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(mc_k9MbS8ximDhyae2LODIlRL),(sizeof(size_t))));;;
mc__2KDWyiJeY4Pj1erRpfNCC=0;if(mc_VX7HfGsCn0KZdLvyd11xid||!
mc_F50LHIM89Xpj_mZvqqCQnH){mc_FYv4y94626tPV1FSsbbP56=pm__HVqeFmd5gKdguw04VZTsk
->mNumCol;}else{mc_FYv4y94626tPV1FSsbbP56=mc_FLTxr_Wc1PKSeTxwfrcl5B(
mc_F50LHIM89Xpj_mZvqqCQnH);}for(pm_Fr_bHKkQKFWbfi50VWd5Pw=0;
pm_Fr_bHKkQKFWbfi50VWd5Pw<mc__9lYVjpAT5x_Y5qsCgHlRA;pm_Fr_bHKkQKFWbfi50VWd5Pw
++){if(!mc_F50LHIM89Xpj_mZvqqCQnH||mc_F50LHIM89Xpj_mZvqqCQnH->mX[
pm_Fr_bHKkQKFWbfi50VWd5Pw]){for(mc_kTYDEKlBgFdmfXNFRlIAsd=
mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw];mc_kTYDEKlBgFdmfXNFRlIAsd
<(size_t)mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw+1];
mc_kTYDEKlBgFdmfXNFRlIAsd++){if(!mc_FIRQmUoZ8GOih5Os6NY5A_||
mc_FIRQmUoZ8GOih5Os6NY5A_->mX[mc___zo4Li75yK0YLHAVMctDw[
mc_kTYDEKlBgFdmfXNFRlIAsd]]){mc__2KDWyiJeY4Pj1erRpfNCC++;}}}}
mc_F8fEsD1Otn_HiX9tvTISDv=0;for(pm_kplAJmOlA30feiNcOzi7oj=0;
pm_kplAJmOlA30feiNcOzi7oj<mc_k9MbS8ximDhyae2LODIlRL;pm_kplAJmOlA30feiNcOzi7oj
++){mc_F8fEsD1Otn_HiX9tvTISDv+=(mc_VX7HfGsCn0KZdLvyd11xid||!
mc_FIRQmUoZ8GOih5Os6NY5A_||mc_FIRQmUoZ8GOih5Os6NY5A_->mX[
pm_kplAJmOlA30feiNcOzi7oj])?1:0;mc__G2DbMuk5LSFXLoD15I6CL[
pm_kplAJmOlA30feiNcOzi7oj]=mc_F8fEsD1Otn_HiX9tvTISDv-1;}
mc_VwTH0kBm_KtWVyf9lUFfw7->mNumCol=mc_FYv4y94626tPV1FSsbbP56;
mc_VwTH0kBm_KtWVyf9lUFfw7->mNumRow=mc_F8fEsD1Otn_HiX9tvTISDv;
mc_kLo3PhvBON8qYaxOFVgaFS=(int32_T*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(mc_VwTH0kBm_KtWVyf9lUFfw7->mNumCol+1),(sizeof(
int32_T))));mc_VwTH0kBm_KtWVyf9lUFfw7->mJc=mc_kLo3PhvBON8qYaxOFVgaFS;
mc_FiHVcEQROGW8_HIfdPn0j3=(int32_T*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(mc__2KDWyiJeY4Pj1erRpfNCC),(sizeof(int32_T))));
mc_VwTH0kBm_KtWVyf9lUFfw7->mIr=mc_FiHVcEQROGW8_HIfdPn0j3;
mc_V2Ap3MG6qy_ijioo_xKfYu=0;mc__1w3rrAoDPWHdX86QQPNUm=0;for(
pm_Fr_bHKkQKFWbfi50VWd5Pw=0;pm_Fr_bHKkQKFWbfi50VWd5Pw<
mc__9lYVjpAT5x_Y5qsCgHlRA;pm_Fr_bHKkQKFWbfi50VWd5Pw++){if(
mc_VX7HfGsCn0KZdLvyd11xid){mc_kLo3PhvBON8qYaxOFVgaFS[mc__1w3rrAoDPWHdX86QQPNUm
]=((int32_T)(mc_V2Ap3MG6qy_ijioo_xKfYu));mc__1w3rrAoDPWHdX86QQPNUm++;}if(!
mc_F50LHIM89Xpj_mZvqqCQnH||mc_F50LHIM89Xpj_mZvqqCQnH->mX[
pm_Fr_bHKkQKFWbfi50VWd5Pw]){if(!mc_VX7HfGsCn0KZdLvyd11xid){
mc_kLo3PhvBON8qYaxOFVgaFS[mc__1w3rrAoDPWHdX86QQPNUm]=((int32_T)(
mc_V2Ap3MG6qy_ijioo_xKfYu));mc__1w3rrAoDPWHdX86QQPNUm++;}for(
mc_kTYDEKlBgFdmfXNFRlIAsd=mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw]
;mc_kTYDEKlBgFdmfXNFRlIAsd<(size_t)mc_Fp5npk_4EItUj9RiETHm6R[
pm_Fr_bHKkQKFWbfi50VWd5Pw+1];mc_kTYDEKlBgFdmfXNFRlIAsd++){if(!
mc_FIRQmUoZ8GOih5Os6NY5A_||mc_FIRQmUoZ8GOih5Os6NY5A_->mX[
mc___zo4Li75yK0YLHAVMctDw[mc_kTYDEKlBgFdmfXNFRlIAsd]]){
mc_FiHVcEQROGW8_HIfdPn0j3[mc_V2Ap3MG6qy_ijioo_xKfYu]=((int32_T)(
mc__G2DbMuk5LSFXLoD15I6CL[mc___zo4Li75yK0YLHAVMctDw[mc_kTYDEKlBgFdmfXNFRlIAsd]
]));mc_V2Ap3MG6qy_ijioo_xKfYu++;}}}}mc_kLo3PhvBON8qYaxOFVgaFS[
mc__1w3rrAoDPWHdX86QQPNUm]=((int32_T)(mc_V2Ap3MG6qy_ijioo_xKfYu));;;;{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc__G2DbMuk5LSFXLoD15I6CL);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,mc_kk06poLCQlh5i5Yv6GSh7e);}};return
mc_VwTH0kBm_KtWVyf9lUFfw7;}PmSparsityPattern*mc_V_3Bm28Cx08dj9ZMdrwaJg(const
PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*
mc_FIRQmUoZ8GOih5Os6NY5A_,const PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH,
PmAllocator*pm__8zlSpb2Hixod149p2zadR){return mc_kRhnXRy_F3OLcu26HcqOKB(
pm__HVqeFmd5gKdguw04VZTsk,mc_FIRQmUoZ8GOih5Os6NY5A_,mc_F50LHIM89Xpj_mZvqqCQnH,
pm__8zlSpb2Hixod149p2zadR,false);}PmSparsityPattern*mc__qAqv2Z2m7K0VPPGKiCpwD(
const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*
mc_FIRQmUoZ8GOih5Os6NY5A_,const PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH,
PmAllocator*pm__8zlSpb2Hixod149p2zadR){return mc_kRhnXRy_F3OLcu26HcqOKB(
pm__HVqeFmd5gKdguw04VZTsk,mc_FIRQmUoZ8GOih5Os6NY5A_,mc_F50LHIM89Xpj_mZvqqCQnH,
pm__8zlSpb2Hixod149p2zadR,true);}PmSparsityPattern*mc__mBVa3_c658wjuT_cJe_Qy(
const PmSparsityPattern*b,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC,const
PmBoolVector*pm_VCVhWy_VaDhraHrlfFWxBa,PmAllocator*mc_FZx3iFiX1YW7j5eEojoAPc){
PmSparsityPattern*a=pm_create_sparsity_pattern(((size_t)(b)->mJc[(b)->mNumCol]
),mc_F8fT7naL9bOcimTADCVzTC->mN,pm_VCVhWy_VaDhraHrlfFWxBa->mN,
mc_FZx3iFiX1YW7j5eEojoAPc);PmIntVector*mc__qHZ_V9ajmO6aqKi26lC7w=
pm_create_int_vector(b->mNumRow,mc_FZx3iFiX1YW7j5eEojoAPc);;;{size_t
mc_kyp6uAyJE40UVuAQNEYzS1=0;size_t mc_Fyn54yKBEdp7e5btQpeYD2=0;for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<a->mNumCol;
mc_kyp6uAyJE40UVuAQNEYzS1++){a->mJc[mc_kyp6uAyJE40UVuAQNEYzS1]=b->mJc[
mc_Fyn54yKBEdp7e5btQpeYD2];mc_Fyn54yKBEdp7e5btQpeYD2+=
pm_VCVhWy_VaDhraHrlfFWxBa->mX[mc_kyp6uAyJE40UVuAQNEYzS1]?1:0;};a->mJc[a->
mNumCol]=((int32_T)(((size_t)(b)->mJc[(b)->mNumCol])));}{size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0;size_t mc_V9A3eW1u92dT_yVuTmAzhq=0;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_F8fT7naL9bOcimTADCVzTC->mN;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
mc_F8fT7naL9bOcimTADCVzTC->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]){
mc__qHZ_V9ajmO6aqKi26lC7w->mX[mc_V9A3eW1u92dT_yVuTmAzhq]=((int32_T)(
mc_kwrB3ZoKf7OufTHWaHJV7a));mc_V9A3eW1u92dT_yVuTmAzhq++;}};}{size_t
mc_kyp6uAyJE40UVuAQNEYzS1=0;for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<a->mNumCol;mc_kyp6uAyJE40UVuAQNEYzS1++){int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=a->mJc[
mc_kyp6uAyJE40UVuAQNEYzS1];mc_kwrB3ZoKf7OufTHWaHJV7a<a->mJc[
mc_kyp6uAyJE40UVuAQNEYzS1+1];mc_kwrB3ZoKf7OufTHWaHJV7a++){a->mIr[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc__qHZ_V9ajmO6aqKi26lC7w->mX[b->mIr[
mc_kwrB3ZoKf7OufTHWaHJV7a]];}}}pm_destroy_int_vector(mc__qHZ_V9ajmO6aqKi26lC7w
,mc_FZx3iFiX1YW7j5eEojoAPc);return a;}void mc_Fv2sZggivbSOc5zulDbRra(const
PmRealVector*mc_k5z61obNZCWCbyygZn_fdK,const real_T*mc__uV9GcaXWFlx_5jfPip5Mo,
const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,const PmBoolVector*
mc_FIRQmUoZ8GOih5Os6NY5A_,const PmBoolVector*mc_F50LHIM89Xpj_mZvqqCQnH){
int32_T*mc___zo4Li75yK0YLHAVMctDw=pm__HVqeFmd5gKdguw04VZTsk->mIr;int32_T*
mc_Fp5npk_4EItUj9RiETHm6R=pm__HVqeFmd5gKdguw04VZTsk->mJc;size_t
pm_Fr_bHKkQKFWbfi50VWd5Pw=0;size_t mc_V2Ap3MG6qy_ijioo_xKfYu=0;size_t
mc_kTYDEKlBgFdmfXNFRlIAsd=0;real_T*mc_FxDsqMskU2hobH8caD9M6Q=
mc_k5z61obNZCWCbyygZn_fdK->mX;;;mc_V2Ap3MG6qy_ijioo_xKfYu=0;for(
pm_Fr_bHKkQKFWbfi50VWd5Pw=0;pm_Fr_bHKkQKFWbfi50VWd5Pw<
pm__HVqeFmd5gKdguw04VZTsk->mNumCol;pm_Fr_bHKkQKFWbfi50VWd5Pw++){if(!
mc_F50LHIM89Xpj_mZvqqCQnH||mc_F50LHIM89Xpj_mZvqqCQnH->mX[
pm_Fr_bHKkQKFWbfi50VWd5Pw]){for(mc_kTYDEKlBgFdmfXNFRlIAsd=
mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw];mc_kTYDEKlBgFdmfXNFRlIAsd
<(size_t)mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw+1];
mc_kTYDEKlBgFdmfXNFRlIAsd++){if(!mc_FIRQmUoZ8GOih5Os6NY5A_||
mc_FIRQmUoZ8GOih5Os6NY5A_->mX[mc___zo4Li75yK0YLHAVMctDw[
mc_kTYDEKlBgFdmfXNFRlIAsd]]){mc_FxDsqMskU2hobH8caD9M6Q[
mc_V2Ap3MG6qy_ijioo_xKfYu]=mc__uV9GcaXWFlx_5jfPip5Mo[mc_kTYDEKlBgFdmfXNFRlIAsd
];mc_V2Ap3MG6qy_ijioo_xKfYu++;}}}};}PmSparsityPattern*
mc__JB9jUvbb10FaTie1cmY8_(const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,
size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t mc_knvTkz3vM6t4a9WNgNRMzB,size_t
mc_VGPLyQQmjMlldLbUiddSkc,size_t mc_Fp_w9JW6vqt5eXL55IL0g1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){int32_T*mc___zo4Li75yK0YLHAVMctDw=
pm__HVqeFmd5gKdguw04VZTsk->mIr,*mc__eSHPfMiNCO4euXMf_WN0e=NULL;int32_T*
mc_Fp5npk_4EItUj9RiETHm6R=pm__HVqeFmd5gKdguw04VZTsk->mJc,*
mc__HOQF1OdcL88himHyKX6Lo=NULL;int32_T mc_VuoWFfkjeKGLcTqK0XAEoe=0;size_t
pm_Fr_bHKkQKFWbfi50VWd5Pw=0,mc_kTYDEKlBgFdmfXNFRlIAsd=0;int32_T
mc_kK3JqGNm4N04giTNsCnRPc=0,mc_V2Ap3MG6qy_ijioo_xKfYu=0;PmSparsityPattern*
mc__ivNMlhmkSOmd5YEhDk_wV=(PmSparsityPattern*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(1),(sizeof(PmSparsityPattern))));;;;;;
;mc_VuoWFfkjeKGLcTqK0XAEoe=0;for(pm_Fr_bHKkQKFWbfi50VWd5Pw=
mc_VGPLyQQmjMlldLbUiddSkc;pm_Fr_bHKkQKFWbfi50VWd5Pw<mc_Fp_w9JW6vqt5eXL55IL0g1;
pm_Fr_bHKkQKFWbfi50VWd5Pw++){for(mc_kK3JqGNm4N04giTNsCnRPc=
mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw];mc_kK3JqGNm4N04giTNsCnRPc
<mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw+1];
mc_kK3JqGNm4N04giTNsCnRPc++){mc_kTYDEKlBgFdmfXNFRlIAsd=
mc___zo4Li75yK0YLHAVMctDw[mc_kK3JqGNm4N04giTNsCnRPc];if(
mc_kTYDEKlBgFdmfXNFRlIAsd>=mc_Fxvltms7Im4baT5ZPxj7f2&&
mc_kTYDEKlBgFdmfXNFRlIAsd<mc_knvTkz3vM6t4a9WNgNRMzB){mc_VuoWFfkjeKGLcTqK0XAEoe
++;}}}mc__ivNMlhmkSOmd5YEhDk_wV->mNumCol=mc_Fp_w9JW6vqt5eXL55IL0g1-
mc_VGPLyQQmjMlldLbUiddSkc;mc__ivNMlhmkSOmd5YEhDk_wV->mNumRow=
mc_knvTkz3vM6t4a9WNgNRMzB-mc_Fxvltms7Im4baT5ZPxj7f2;mc__HOQF1OdcL88himHyKX6Lo=
mc__ivNMlhmkSOmd5YEhDk_wV->mJc=(int32_T*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(mc__ivNMlhmkSOmd5YEhDk_wV->mNumCol+1),
(sizeof(int32_T))));mc__eSHPfMiNCO4euXMf_WN0e=mc__ivNMlhmkSOmd5YEhDk_wV->mIr=(
int32_T*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),
(mc_VuoWFfkjeKGLcTqK0XAEoe),(sizeof(int32_T))));mc_V2Ap3MG6qy_ijioo_xKfYu=0;
for(pm_Fr_bHKkQKFWbfi50VWd5Pw=mc_VGPLyQQmjMlldLbUiddSkc;
pm_Fr_bHKkQKFWbfi50VWd5Pw<mc_Fp_w9JW6vqt5eXL55IL0g1;pm_Fr_bHKkQKFWbfi50VWd5Pw
++){*mc__HOQF1OdcL88himHyKX6Lo++=mc_V2Ap3MG6qy_ijioo_xKfYu;for(
mc_kK3JqGNm4N04giTNsCnRPc=mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw]
;mc_kK3JqGNm4N04giTNsCnRPc<mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw
+1];mc_kK3JqGNm4N04giTNsCnRPc++){mc_kTYDEKlBgFdmfXNFRlIAsd=
mc___zo4Li75yK0YLHAVMctDw[mc_kK3JqGNm4N04giTNsCnRPc];if(
mc_kTYDEKlBgFdmfXNFRlIAsd>=mc_Fxvltms7Im4baT5ZPxj7f2&&
mc_kTYDEKlBgFdmfXNFRlIAsd<mc_knvTkz3vM6t4a9WNgNRMzB){mc_V2Ap3MG6qy_ijioo_xKfYu
++;*mc__eSHPfMiNCO4euXMf_WN0e++=((int32_T)(mc_kTYDEKlBgFdmfXNFRlIAsd-
mc_Fxvltms7Im4baT5ZPxj7f2));}}}*mc__HOQF1OdcL88himHyKX6Lo=
mc_V2Ap3MG6qy_ijioo_xKfYu;;;return mc__ivNMlhmkSOmd5YEhDk_wV;}
PmSparsityPattern*mc_VINzQey3e2GxYDxzr7cOY_(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t
mc_knvTkz3vM6t4a9WNgNRMzB,size_t mc_VGPLyQQmjMlldLbUiddSkc,size_t
mc_Fp_w9JW6vqt5eXL55IL0g1,PmAllocator*pm__8zlSpb2Hixod149p2zadR){size_t
mc_Vjqz98n_yVhiWmGpa3vShU=pm__HVqeFmd5gKdguw04VZTsk->mNumRow;size_t
mc__mu6AvYcb5GeeHD1YRmXQv=pm__HVqeFmd5gKdguw04VZTsk->mNumCol;PmSparsityPattern
*mc__ivNMlhmkSOmd5YEhDk_wV=mc__JB9jUvbb10FaTie1cmY8_(pm__HVqeFmd5gKdguw04VZTsk
,mc_Fxvltms7Im4baT5ZPxj7f2,mc_knvTkz3vM6t4a9WNgNRMzB,mc_VGPLyQQmjMlldLbUiddSkc
,mc_Fp_w9JW6vqt5eXL55IL0g1,pm__8zlSpb2Hixod149p2zadR);size_t
mc_VV95b_WbOSSdZ95sS763bO=mc__ivNMlhmkSOmd5YEhDk_wV->mNumRow;size_t
mc_FdVPcdZw6sSpfefc3qdV5w=mc__ivNMlhmkSOmd5YEhDk_wV->mNumCol;int32_T*
mc_FIbp8o5BTB4IbPQMbLRLLh=mc__ivNMlhmkSOmd5YEhDk_wV->mIr;size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0;size_t mc_VIclr3vOYJOybqgxMwnDak=((size_t)(
mc__ivNMlhmkSOmd5YEhDk_wV)->mJc[(mc__ivNMlhmkSOmd5YEhDk_wV)->mNumCol]);int32_T
*mc__b6f9kVM6wx_hqdsMuK3so=(int32_T*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn(
(pm__8zlSpb2Hixod149p2zadR),(mc__mu6AvYcb5GeeHD1YRmXQv+1),(sizeof(int32_T))));
for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VIclr3vOYJOybqgxMwnDak;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_FIbp8o5BTB4IbPQMbLRLLh[mc_kwrB3ZoKf7OufTHWaHJV7a]+=((int32_T)(
mc_Fxvltms7Im4baT5ZPxj7f2));}memcpy(mc__b6f9kVM6wx_hqdsMuK3so+
mc_VGPLyQQmjMlldLbUiddSkc,mc__ivNMlhmkSOmd5YEhDk_wV->mJc,(
mc_FdVPcdZw6sSpfefc3qdV5w+1)*sizeof(int32_T));for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_Fp_w9JW6vqt5eXL55IL0g1+1;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc__mu6AvYcb5GeeHD1YRmXQv+1;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__b6f9kVM6wx_hqdsMuK3so[mc_kwrB3ZoKf7OufTHWaHJV7a]=((int32_T)(
mc_VIclr3vOYJOybqgxMwnDak));}{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc__ivNMlhmkSOmd5YEhDk_wV->mJc);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(pm__8zlSpb2Hixod149p2zadR,
mc_kk06poLCQlh5i5Yv6GSh7e);}};mc__ivNMlhmkSOmd5YEhDk_wV->mJc=
mc__b6f9kVM6wx_hqdsMuK3so;mc__ivNMlhmkSOmd5YEhDk_wV->mNumRow=
mc_Vjqz98n_yVhiWmGpa3vShU;mc__ivNMlhmkSOmd5YEhDk_wV->mNumCol=
mc__mu6AvYcb5GeeHD1YRmXQv;return mc__ivNMlhmkSOmd5YEhDk_wV;}void
mc_Fzylow9cnZxIhyL1O9nM0I(const PmRealVector*mc_VIutEr_JmfWNeDyKonnHVk,const
PmRealVector*mc_VW_HqYZElHCjWHwd6Iv4ON,const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,size_t mc_Fxvltms7Im4baT5ZPxj7f2,size_t
mc_knvTkz3vM6t4a9WNgNRMzB,size_t mc_VGPLyQQmjMlldLbUiddSkc,size_t
mc_Fp_w9JW6vqt5eXL55IL0g1){int32_T*mc___zo4Li75yK0YLHAVMctDw=
pm__HVqeFmd5gKdguw04VZTsk->mIr;int32_T*mc_Fp5npk_4EItUj9RiETHm6R=
pm__HVqeFmd5gKdguw04VZTsk->mJc;real_T*mc__uV9GcaXWFlx_5jfPip5Mo=
mc_VW_HqYZElHCjWHwd6Iv4ON->mX;size_t pm_Fr_bHKkQKFWbfi50VWd5Pw=0,
mc_V2Ap3MG6qy_ijioo_xKfYu=0,mc_kTYDEKlBgFdmfXNFRlIAsd=0;real_T*
mc_FUqFh_8tU0_NiHE2hKa5t9=mc_VIutEr_JmfWNeDyKonnHVk->mX;
mc_V2Ap3MG6qy_ijioo_xKfYu=0;;for(pm_Fr_bHKkQKFWbfi50VWd5Pw=
mc_VGPLyQQmjMlldLbUiddSkc;pm_Fr_bHKkQKFWbfi50VWd5Pw<mc_Fp_w9JW6vqt5eXL55IL0g1;
pm_Fr_bHKkQKFWbfi50VWd5Pw++){int32_T mc_kK3JqGNm4N04giTNsCnRPc=0;for(
mc_kK3JqGNm4N04giTNsCnRPc=mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw]
;mc_kK3JqGNm4N04giTNsCnRPc<mc_Fp5npk_4EItUj9RiETHm6R[pm_Fr_bHKkQKFWbfi50VWd5Pw
+1];mc_kK3JqGNm4N04giTNsCnRPc++){mc_kTYDEKlBgFdmfXNFRlIAsd=
mc___zo4Li75yK0YLHAVMctDw[mc_kK3JqGNm4N04giTNsCnRPc];if(
mc_kTYDEKlBgFdmfXNFRlIAsd>=mc_Fxvltms7Im4baT5ZPxj7f2&&
mc_kTYDEKlBgFdmfXNFRlIAsd<mc_knvTkz3vM6t4a9WNgNRMzB){mc_V2Ap3MG6qy_ijioo_xKfYu
++;*mc_FUqFh_8tU0_NiHE2hKa5t9++=mc__uV9GcaXWFlx_5jfPip5Mo[
mc_kK3JqGNm4N04giTNsCnRPc];}}};}void mc_FY8ifnDZsXphdqo3UGrtOk(
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,size_t n){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a;size_t mc_kNgcOktCtQxdYedrGvFn5i=((size_t)(
mc_V_ku0ZO8TOxhc9438tlsBI)->mJc[(mc_V_ku0ZO8TOxhc9438tlsBI)->mNumCol]);int32_T
*mc_VEXzFHKjFN87iiOtLrddNz=mc_V_ku0ZO8TOxhc9438tlsBI->mIr;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_kNgcOktCtQxdYedrGvFn5i;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_VEXzFHKjFN87iiOtLrddNz[mc_kwrB3ZoKf7OufTHWaHJV7a]+=((int32_T)(n));}
mc_V_ku0ZO8TOxhc9438tlsBI->mNumRow+=n;}void mc_kNxwVTI76g4kj9P52yKhA5(
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,size_t n){
mc_V_ku0ZO8TOxhc9438tlsBI->mNumRow+=n;}PmSparsityPattern*
mc_kNYMmfXA1XtHcmiWCr7l_C(const PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR){if(n>0){size_t
mc_krxmiCel2JOBZPzmcLiTBY=pm__6H5I5OnY3KoY5YVL6mLgG->mNumCol+n;int32_T*
mc__w_2QhsZQ4_1hq8U8LeesT=pm__6H5I5OnY3KoY5YVL6mLgG->mJc;PmSparsityPattern*
mc_k_h7tLhAIQ8FbyFddCHBNp=pm_create_sparsity_pattern(((size_t)(
pm__6H5I5OnY3KoY5YVL6mLgG)->mJc[(pm__6H5I5OnY3KoY5YVL6mLgG)->mNumCol]),
pm__6H5I5OnY3KoY5YVL6mLgG->mNumRow,mc_krxmiCel2JOBZPzmcLiTBY,
pm__8zlSpb2Hixod149p2zadR);int32_T*mc__32hmUz_GWWHjPUY6P_T1j=
mc_k_h7tLhAIQ8FbyFddCHBNp->mJc;memcpy(mc_k_h7tLhAIQ8FbyFddCHBNp->mIr,
pm__6H5I5OnY3KoY5YVL6mLgG->mIr,sizeof(int32_T)*((size_t)(
mc_k_h7tLhAIQ8FbyFddCHBNp)->mJc[(mc_k_h7tLhAIQ8FbyFddCHBNp)->mNumCol]));memset
(mc__32hmUz_GWWHjPUY6P_T1j,0,n*sizeof(int32_T));memcpy(
mc__32hmUz_GWWHjPUY6P_T1j+n,mc__w_2QhsZQ4_1hq8U8LeesT,(
pm__6H5I5OnY3KoY5YVL6mLgG->mNumCol+1)*sizeof(int32_T));return
mc_k_h7tLhAIQ8FbyFddCHBNp;}else{return pm_FQMLyYzCQ5CtgHjze1nNJP(
pm__6H5I5OnY3KoY5YVL6mLgG,pm__8zlSpb2Hixod149p2zadR);}}PmSparsityPattern*
mc_VJlBwQnSeLpciXVTLb_llB(const PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR){if(n>0){size_t
mc_krxmiCel2JOBZPzmcLiTBY=pm__6H5I5OnY3KoY5YVL6mLgG->mNumCol+n;int32_T*
mc__w_2QhsZQ4_1hq8U8LeesT=pm__6H5I5OnY3KoY5YVL6mLgG->mJc;PmSparsityPattern*
mc_k_h7tLhAIQ8FbyFddCHBNp=pm_create_sparsity_pattern(((size_t)(
pm__6H5I5OnY3KoY5YVL6mLgG)->mJc[(pm__6H5I5OnY3KoY5YVL6mLgG)->mNumCol]),
pm__6H5I5OnY3KoY5YVL6mLgG->mNumRow,mc_krxmiCel2JOBZPzmcLiTBY,
pm__8zlSpb2Hixod149p2zadR);int32_T*mc__32hmUz_GWWHjPUY6P_T1j=
mc_k_h7tLhAIQ8FbyFddCHBNp->mJc;size_t mc_V1k_Xi78CKGLdXtrb8zJmG=
pm__6H5I5OnY3KoY5YVL6mLgG->mJc[pm__6H5I5OnY3KoY5YVL6mLgG->mNumCol];size_t
mc_kh3C5f6ZAPlGWXfJykpWPn=0;memcpy(mc_k_h7tLhAIQ8FbyFddCHBNp->mIr,
pm__6H5I5OnY3KoY5YVL6mLgG->mIr,sizeof(int32_T)*((size_t)(
mc_k_h7tLhAIQ8FbyFddCHBNp)->mJc[(mc_k_h7tLhAIQ8FbyFddCHBNp)->mNumCol]));memcpy
(mc__32hmUz_GWWHjPUY6P_T1j,mc__w_2QhsZQ4_1hq8U8LeesT,pm__6H5I5OnY3KoY5YVL6mLgG
->mNumCol*sizeof(int32_T));for(mc_kh3C5f6ZAPlGWXfJykpWPn=
pm__6H5I5OnY3KoY5YVL6mLgG->mNumCol;mc_kh3C5f6ZAPlGWXfJykpWPn<
mc_krxmiCel2JOBZPzmcLiTBY+1;mc_kh3C5f6ZAPlGWXfJykpWPn++){
mc__32hmUz_GWWHjPUY6P_T1j[mc_kh3C5f6ZAPlGWXfJykpWPn]=((int32_T)(
mc_V1k_Xi78CKGLdXtrb8zJmG));}return mc_k_h7tLhAIQ8FbyFddCHBNp;}else{return
pm_FQMLyYzCQ5CtgHjze1nNJP(pm__6H5I5OnY3KoY5YVL6mLgG,pm__8zlSpb2Hixod149p2zadR)
;}}static size_t mc_VKx7ZOzwre8XfewIhU1w3R(const int32_T*
mc_kMGBCYsWuASnV93g6HrFl7,const int32_T*mc__iEoCyRavqWzgHpmUS5o_B,const int32_T
*mc__E2YBge0HSdQXuehCPGj40,const int32_T*mc_Vslqmgpu5w4hguJEIhlaWJ){int
mc_FZdKS_L29g4QXX9FtBLtvv;size_t mc__BwCbGCDlrx2gDK5rof3H8;
mc__BwCbGCDlrx2gDK5rof3H8=(size_t)((mc__iEoCyRavqWzgHpmUS5o_B-
mc_kMGBCYsWuASnV93g6HrFl7)+(mc_Vslqmgpu5w4hguJEIhlaWJ-
mc__E2YBge0HSdQXuehCPGj40));while(mc_kMGBCYsWuASnV93g6HrFl7<
mc__iEoCyRavqWzgHpmUS5o_B&&mc__E2YBge0HSdQXuehCPGj40<mc_Vslqmgpu5w4hguJEIhlaWJ
){mc_FZdKS_L29g4QXX9FtBLtvv= *mc_kMGBCYsWuASnV93g6HrFl7-*
mc__E2YBge0HSdQXuehCPGj40;mc_FZdKS_L29g4QXX9FtBLtvv=mc_FZdKS_L29g4QXX9FtBLtvv?
((mc_FZdKS_L29g4QXX9FtBLtvv>0)?1:-1):0;switch(mc_FZdKS_L29g4QXX9FtBLtvv){case-
1:mc_kMGBCYsWuASnV93g6HrFl7++;break;case 0:mc__BwCbGCDlrx2gDK5rof3H8--;
mc_kMGBCYsWuASnV93g6HrFl7++;case 1:mc__E2YBge0HSdQXuehCPGj40++;}}return
mc__BwCbGCDlrx2gDK5rof3H8;}static void mc_F4xbTY0DieKUWa0mDhe6pc(int32_T*
mc_Vm5okzQ7grKob1GJ0zNYcc,const int32_T*mc_kMGBCYsWuASnV93g6HrFl7,const int32_T
*const mc__iEoCyRavqWzgHpmUS5o_B,const int32_T*mc__E2YBge0HSdQXuehCPGj40,const
int32_T*const mc_Vslqmgpu5w4hguJEIhlaWJ){int mc_FZdKS_L29g4QXX9FtBLtvv;while(
mc_kMGBCYsWuASnV93g6HrFl7<mc__iEoCyRavqWzgHpmUS5o_B&&mc__E2YBge0HSdQXuehCPGj40
<mc_Vslqmgpu5w4hguJEIhlaWJ){mc_FZdKS_L29g4QXX9FtBLtvv= *
mc_kMGBCYsWuASnV93g6HrFl7-*mc__E2YBge0HSdQXuehCPGj40;mc_FZdKS_L29g4QXX9FtBLtvv
=mc_FZdKS_L29g4QXX9FtBLtvv?((mc_FZdKS_L29g4QXX9FtBLtvv>0)?1:-1):0;switch(
mc_FZdKS_L29g4QXX9FtBLtvv){case-1:*mc_Vm5okzQ7grKob1GJ0zNYcc++= *
mc_kMGBCYsWuASnV93g6HrFl7++;break;case 0:mc_kMGBCYsWuASnV93g6HrFl7++;case 1:*
mc_Vm5okzQ7grKob1GJ0zNYcc++= *mc__E2YBge0HSdQXuehCPGj40++;break;default:;}}if(
mc_kMGBCYsWuASnV93g6HrFl7<mc__iEoCyRavqWzgHpmUS5o_B){memcpy(
mc_Vm5okzQ7grKob1GJ0zNYcc,mc_kMGBCYsWuASnV93g6HrFl7,(mc__iEoCyRavqWzgHpmUS5o_B
-mc_kMGBCYsWuASnV93g6HrFl7)*sizeof(int32_T));}else if(
mc__E2YBge0HSdQXuehCPGj40<mc_Vslqmgpu5w4hguJEIhlaWJ){memcpy(
mc_Vm5okzQ7grKob1GJ0zNYcc,mc__E2YBge0HSdQXuehCPGj40,(mc_Vslqmgpu5w4hguJEIhlaWJ
-mc__E2YBge0HSdQXuehCPGj40)*sizeof(int32_T));}}PmSparsityPattern*
mc__5C6m_ZyP9_NYekcJCEULM(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,
mc_kNgcOktCtQxdYedrGvFn5i;size_t mc__jwySfHyx1SXgXJeVWoIzb=
mc_V_ku0ZO8TOxhc9438tlsBI->mNumCol;int32_T*mc__6B9YAP8szKvjq2kQ8O6VO,*
mc_kwUVpSNUux4FXLAocRFjyD;int32_T*mc__GGFaLirzMOkais94_xH_b=
mc_V_ku0ZO8TOxhc9438tlsBI->mJc;int32_T*mc_FGty7dNhdoxeiPHYbn7B52=
mc_V_ku0ZO8TOxhc9438tlsBI->mIr;int32_T*mc_kbRitxPnTtKShL8FInz4nW=
mc_VLr_Ia18P_8icXM9WFOfYI->mJc;int32_T*mc_VjOKR9Oi4Nx_a9R9oEty_X=
mc_VLr_Ia18P_8icXM9WFOfYI->mIr;PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR=(
PmSparsityPattern*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(1),(sizeof(PmSparsityPattern))));
mc__ILFYYSbi7hW_uYs_eHsRR->mNumCol=mc__jwySfHyx1SXgXJeVWoIzb;
mc__ILFYYSbi7hW_uYs_eHsRR->mNumRow=mc_V_ku0ZO8TOxhc9438tlsBI->mNumRow;;
mc__6B9YAP8szKvjq2kQ8O6VO=mc__ILFYYSbi7hW_uYs_eHsRR->mJc=(int32_T*)((
pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),((
mc__jwySfHyx1SXgXJeVWoIzb+1)),(sizeof(int32_T))));for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc_kNgcOktCtQxdYedrGvFn5i=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc__jwySfHyx1SXgXJeVWoIzb;mc_kwrB3ZoKf7OufTHWaHJV7a
++){mc__6B9YAP8szKvjq2kQ8O6VO[mc_kwrB3ZoKf7OufTHWaHJV7a]=((int32_T)(
mc_kNgcOktCtQxdYedrGvFn5i));mc_kNgcOktCtQxdYedrGvFn5i+=
mc_VKx7ZOzwre8XfewIhU1w3R(&mc_FGty7dNhdoxeiPHYbn7B52[mc__GGFaLirzMOkais94_xH_b
[mc_kwrB3ZoKf7OufTHWaHJV7a]],&mc_FGty7dNhdoxeiPHYbn7B52[
mc__GGFaLirzMOkais94_xH_b[mc_kwrB3ZoKf7OufTHWaHJV7a+1]],&
mc_VjOKR9Oi4Nx_a9R9oEty_X[mc_kbRitxPnTtKShL8FInz4nW[mc_kwrB3ZoKf7OufTHWaHJV7a]
],&mc_VjOKR9Oi4Nx_a9R9oEty_X[mc_kbRitxPnTtKShL8FInz4nW[
mc_kwrB3ZoKf7OufTHWaHJV7a+1]]);}mc__6B9YAP8szKvjq2kQ8O6VO[
mc__jwySfHyx1SXgXJeVWoIzb]=((int32_T)(mc_kNgcOktCtQxdYedrGvFn5i));
mc_kwUVpSNUux4FXLAocRFjyD=mc__ILFYYSbi7hW_uYs_eHsRR->mIr=(int32_T*)((
pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(
mc_kNgcOktCtQxdYedrGvFn5i),(sizeof(int32_T))));for(mc_kwrB3ZoKf7OufTHWaHJV7a=0
;mc_kwrB3ZoKf7OufTHWaHJV7a<mc__jwySfHyx1SXgXJeVWoIzb;mc_kwrB3ZoKf7OufTHWaHJV7a
++){mc_F4xbTY0DieKUWa0mDhe6pc(&mc_kwUVpSNUux4FXLAocRFjyD[
mc__6B9YAP8szKvjq2kQ8O6VO[mc_kwrB3ZoKf7OufTHWaHJV7a]],&
mc_FGty7dNhdoxeiPHYbn7B52[mc__GGFaLirzMOkais94_xH_b[mc_kwrB3ZoKf7OufTHWaHJV7a]
],&mc_FGty7dNhdoxeiPHYbn7B52[mc__GGFaLirzMOkais94_xH_b[
mc_kwrB3ZoKf7OufTHWaHJV7a+1]],&mc_VjOKR9Oi4Nx_a9R9oEty_X[
mc_kbRitxPnTtKShL8FInz4nW[mc_kwrB3ZoKf7OufTHWaHJV7a]],&
mc_VjOKR9Oi4Nx_a9R9oEty_X[mc_kbRitxPnTtKShL8FInz4nW[mc_kwrB3ZoKf7OufTHWaHJV7a+
1]]);}return mc__ILFYYSbi7hW_uYs_eHsRR;}void mc__8x7kz_627_gXDli_FJo22(const
PmRealVector*mc_kuYGZlr6GiOSeqresCsPcM,const PmSparsityPattern*
mc__ILFYYSbi7hW_uYs_eHsRR,const PmRealVector*mc_FmeGGSq6P2_Kg9j7twxwci,const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const PmRealVector*
mc_FQSQWg_QFOKIWm9DWdLQR6,const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,
const PmRealVector*mc_krOJvR5Qa1KQZu3eEsQtEU){size_t mc__jwySfHyx1SXgXJeVWoIzb
=mc_V_ku0ZO8TOxhc9438tlsBI->mNumCol;int32_T*mc__6B9YAP8szKvjq2kQ8O6VO=
mc__ILFYYSbi7hW_uYs_eHsRR->mJc;int32_T*mc_kwUVpSNUux4FXLAocRFjyD=
mc__ILFYYSbi7hW_uYs_eHsRR->mIr;int32_T*mc__GGFaLirzMOkais94_xH_b=
mc_V_ku0ZO8TOxhc9438tlsBI->mJc;int32_T*mc_FGty7dNhdoxeiPHYbn7B52=
mc_V_ku0ZO8TOxhc9438tlsBI->mIr;int32_T*mc_kbRitxPnTtKShL8FInz4nW=
mc_VLr_Ia18P_8icXM9WFOfYI->mJc;int32_T*mc_VjOKR9Oi4Nx_a9R9oEty_X=
mc_VLr_Ia18P_8icXM9WFOfYI->mIr;size_t mc_kwrB3ZoKf7OufTHWaHJV7a;int32_T
mc_kyp6uAyJE40UVuAQNEYzS1;const real_T*mc_F2l4p_g4sn02huHNflQjMH=
mc_FmeGGSq6P2_Kg9j7twxwci->mX;const real_T*mc_Vqiy96WqvuhCaXm5e_vvT0=
mc_FQSQWg_QFOKIWm9DWdLQR6->mX;real_T*mc_FStFcQlyAJ_dVy4kGZXBPQ=
mc_kuYGZlr6GiOSeqresCsPcM->mX;real_T*mc_VRZCD_UL_ESThy75dC9J8D=
mc_krOJvR5Qa1KQZu3eEsQtEU->mX;;;;;mc__aNO1s5qwzt6fXwft5YgCz(
mc_krOJvR5Qa1KQZu3eEsQtEU);if(((size_t)(mc__ILFYYSbi7hW_uYs_eHsRR)->mJc[(
mc__ILFYYSbi7hW_uYs_eHsRR)->mNumCol])!=0){mc__aNO1s5qwzt6fXwft5YgCz(
mc_kuYGZlr6GiOSeqresCsPcM);;;;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc__jwySfHyx1SXgXJeVWoIzb;mc_kwrB3ZoKf7OufTHWaHJV7a
++){for(mc_kyp6uAyJE40UVuAQNEYzS1=mc__GGFaLirzMOkais94_xH_b[
mc_kwrB3ZoKf7OufTHWaHJV7a];mc_kyp6uAyJE40UVuAQNEYzS1<mc__GGFaLirzMOkais94_xH_b
[mc_kwrB3ZoKf7OufTHWaHJV7a+1];mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_VRZCD_UL_ESThy75dC9J8D[mc_FGty7dNhdoxeiPHYbn7B52[mc_kyp6uAyJE40UVuAQNEYzS1]
]=mc_F2l4p_g4sn02huHNflQjMH[mc_kyp6uAyJE40UVuAQNEYzS1];}for(
mc_kyp6uAyJE40UVuAQNEYzS1=mc_kbRitxPnTtKShL8FInz4nW[mc_kwrB3ZoKf7OufTHWaHJV7a]
;mc_kyp6uAyJE40UVuAQNEYzS1<mc_kbRitxPnTtKShL8FInz4nW[mc_kwrB3ZoKf7OufTHWaHJV7a
+1];mc_kyp6uAyJE40UVuAQNEYzS1++){mc_VRZCD_UL_ESThy75dC9J8D[
mc_VjOKR9Oi4Nx_a9R9oEty_X[mc_kyp6uAyJE40UVuAQNEYzS1]]+=
mc_Vqiy96WqvuhCaXm5e_vvT0[mc_kyp6uAyJE40UVuAQNEYzS1];}for(
mc_kyp6uAyJE40UVuAQNEYzS1=mc__6B9YAP8szKvjq2kQ8O6VO[mc_kwrB3ZoKf7OufTHWaHJV7a]
;mc_kyp6uAyJE40UVuAQNEYzS1<mc__6B9YAP8szKvjq2kQ8O6VO[mc_kwrB3ZoKf7OufTHWaHJV7a
+1];mc_kyp6uAyJE40UVuAQNEYzS1++){mc_FStFcQlyAJ_dVy4kGZXBPQ[
mc_kyp6uAyJE40UVuAQNEYzS1]=mc_VRZCD_UL_ESThy75dC9J8D[mc_kwUVpSNUux4FXLAocRFjyD
[mc_kyp6uAyJE40UVuAQNEYzS1]];}for(mc_kyp6uAyJE40UVuAQNEYzS1=
mc__6B9YAP8szKvjq2kQ8O6VO[mc_kwrB3ZoKf7OufTHWaHJV7a];mc_kyp6uAyJE40UVuAQNEYzS1
<mc__6B9YAP8szKvjq2kQ8O6VO[mc_kwrB3ZoKf7OufTHWaHJV7a+1];
mc_kyp6uAyJE40UVuAQNEYzS1++){mc_VRZCD_UL_ESThy75dC9J8D[
mc_kwUVpSNUux4FXLAocRFjyD[mc_kyp6uAyJE40UVuAQNEYzS1]]=0.0;}}}}static size_t
mc_FMVi5zjKc7GleyvbJheUkd(const size_t pm_FsQ9LRKHRTKdgeP2xWDL07,int32_T**
pm_VCVhWy_VaDhraHrlfFWxBa,int32_T**mc_F9xtdRtJpNCTW1Sbnnf4Y9){char
mc_khtOmmtNw4WoWDTG4oCyb6=1;size_t mc_kwrB3ZoKf7OufTHWaHJV7a,
mc__BwCbGCDlrx2gDK5rof3H8=0;int32_T mc_kVY78_OU5fOIh1BsuSffVC;while(
mc_khtOmmtNw4WoWDTG4oCyb6){for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_khtOmmtNw4WoWDTG4oCyb6=0,mc_kVY78_OU5fOIh1BsuSffVC=MAX_int32_T;
mc_kwrB3ZoKf7OufTHWaHJV7a<pm_FsQ9LRKHRTKdgeP2xWDL07;mc_kwrB3ZoKf7OufTHWaHJV7a
++){if(pm_VCVhWy_VaDhraHrlfFWxBa[mc_kwrB3ZoKf7OufTHWaHJV7a]<
mc_F9xtdRtJpNCTW1Sbnnf4Y9[mc_kwrB3ZoKf7OufTHWaHJV7a]){
mc_khtOmmtNw4WoWDTG4oCyb6=1;if(pm_VCVhWy_VaDhraHrlfFWxBa[
mc_kwrB3ZoKf7OufTHWaHJV7a][0]<mc_kVY78_OU5fOIh1BsuSffVC){
mc_kVY78_OU5fOIh1BsuSffVC=pm_VCVhWy_VaDhraHrlfFWxBa[mc_kwrB3ZoKf7OufTHWaHJV7a]
[0];}}}if(mc_khtOmmtNw4WoWDTG4oCyb6){mc__BwCbGCDlrx2gDK5rof3H8++;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
pm_FsQ9LRKHRTKdgeP2xWDL07;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
pm_VCVhWy_VaDhraHrlfFWxBa[mc_kwrB3ZoKf7OufTHWaHJV7a]<mc_F9xtdRtJpNCTW1Sbnnf4Y9
[mc_kwrB3ZoKf7OufTHWaHJV7a]&&pm_VCVhWy_VaDhraHrlfFWxBa[
mc_kwrB3ZoKf7OufTHWaHJV7a][0]==mc_kVY78_OU5fOIh1BsuSffVC){
pm_VCVhWy_VaDhraHrlfFWxBa[mc_kwrB3ZoKf7OufTHWaHJV7a]++;}}}}return
mc__BwCbGCDlrx2gDK5rof3H8;}static void mc_FOc1NFJKwbKEbmH1_ROOZu(int32_T*
mc_Vm5okzQ7grKob1GJ0zNYcc,const int32_T pm_FsQ9LRKHRTKdgeP2xWDL07,int32_T**
pm_VCVhWy_VaDhraHrlfFWxBa,int32_T**mc_F9xtdRtJpNCTW1Sbnnf4Y9){char
mc_khtOmmtNw4WoWDTG4oCyb6=1;int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,
mc_kVY78_OU5fOIh1BsuSffVC;while(mc_khtOmmtNw4WoWDTG4oCyb6){for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc_khtOmmtNw4WoWDTG4oCyb6=0,
mc_kVY78_OU5fOIh1BsuSffVC=MAX_int32_T;mc_kwrB3ZoKf7OufTHWaHJV7a<
pm_FsQ9LRKHRTKdgeP2xWDL07;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
pm_VCVhWy_VaDhraHrlfFWxBa[mc_kwrB3ZoKf7OufTHWaHJV7a]<mc_F9xtdRtJpNCTW1Sbnnf4Y9
[mc_kwrB3ZoKf7OufTHWaHJV7a]){mc_khtOmmtNw4WoWDTG4oCyb6=1;if(
pm_VCVhWy_VaDhraHrlfFWxBa[mc_kwrB3ZoKf7OufTHWaHJV7a][0]<
mc_kVY78_OU5fOIh1BsuSffVC){mc_kVY78_OU5fOIh1BsuSffVC=pm_VCVhWy_VaDhraHrlfFWxBa
[mc_kwrB3ZoKf7OufTHWaHJV7a][0];}}}if(mc_khtOmmtNw4WoWDTG4oCyb6){*
mc_Vm5okzQ7grKob1GJ0zNYcc++=mc_kVY78_OU5fOIh1BsuSffVC;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
pm_FsQ9LRKHRTKdgeP2xWDL07;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
pm_VCVhWy_VaDhraHrlfFWxBa[mc_kwrB3ZoKf7OufTHWaHJV7a]<mc_F9xtdRtJpNCTW1Sbnnf4Y9
[mc_kwrB3ZoKf7OufTHWaHJV7a]&&pm_VCVhWy_VaDhraHrlfFWxBa[
mc_kwrB3ZoKf7OufTHWaHJV7a][0]==mc_kVY78_OU5fOIh1BsuSffVC){
pm_VCVhWy_VaDhraHrlfFWxBa[mc_kwrB3ZoKf7OufTHWaHJV7a]++;}}}}}PmSparsityPattern*
mc_kyCwDjPxmBGRiTH73vrjJL(const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){size_t mc_VLHhnPUiNQpve5VIL9P3O9=
mc_V_ku0ZO8TOxhc9438tlsBI->mNumRow;size_t mc_V2__YrimeI4E_yWnhKofpy=
mc_V_ku0ZO8TOxhc9438tlsBI->mNumCol;size_t n=mc_VLr_Ia18P_8icXM9WFOfYI->mNumCol
;int32_T*mc__GGFaLirzMOkais94_xH_b=mc_V_ku0ZO8TOxhc9438tlsBI->mJc;int32_T*
mc_FGty7dNhdoxeiPHYbn7B52=mc_V_ku0ZO8TOxhc9438tlsBI->mIr;int32_T*
mc_kbRitxPnTtKShL8FInz4nW=mc_VLr_Ia18P_8icXM9WFOfYI->mJc;int32_T*
mc_VjOKR9Oi4Nx_a9R9oEty_X=mc_VLr_Ia18P_8icXM9WFOfYI->mIr;int32_T*
mc__6B9YAP8szKvjq2kQ8O6VO,*mc_kwUVpSNUux4FXLAocRFjyD;int32_T**
mc_Fo1tUR18sIdue1E1QXuOnL,**mc___7SXc4Q_w8saDIIf2ecjp;size_t
mc_kwrB3ZoKf7OufTHWaHJV7a,mc_kyp6uAyJE40UVuAQNEYzS1,mc__lO81KuDBk41W9Wd2wAkb0,
mc_kNgcOktCtQxdYedrGvFn5i;PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR=(
PmSparsityPattern*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(1),(sizeof(PmSparsityPattern))));;
mc_Fo1tUR18sIdue1E1QXuOnL=(int32_T**)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn(
(pm__8zlSpb2Hixod149p2zadR),(2*mc_V2__YrimeI4E_yWnhKofpy),(sizeof(int32_T*))))
;mc___7SXc4Q_w8saDIIf2ecjp= &mc_Fo1tUR18sIdue1E1QXuOnL[
mc_V2__YrimeI4E_yWnhKofpy];mc__6B9YAP8szKvjq2kQ8O6VO=mc__ILFYYSbi7hW_uYs_eHsRR
->mJc=(int32_T*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(n+1),(sizeof(int32_T))));mc__ILFYYSbi7hW_uYs_eHsRR
->mNumRow=mc_VLHhnPUiNQpve5VIL9P3O9;mc__ILFYYSbi7hW_uYs_eHsRR->mNumCol=n;for(
mc_kyp6uAyJE40UVuAQNEYzS1=mc_kNgcOktCtQxdYedrGvFn5i=0;
mc_kyp6uAyJE40UVuAQNEYzS1<n;mc_kyp6uAyJE40UVuAQNEYzS1++){int32_T
mc_V5XnIQ0HZCxrbPmX4D3LbT;for(mc_V5XnIQ0HZCxrbPmX4D3LbT=
mc_kbRitxPnTtKShL8FInz4nW[mc_kyp6uAyJE40UVuAQNEYzS1],mc__lO81KuDBk41W9Wd2wAkb0
=0;mc_V5XnIQ0HZCxrbPmX4D3LbT<mc_kbRitxPnTtKShL8FInz4nW[
mc_kyp6uAyJE40UVuAQNEYzS1+1];mc_V5XnIQ0HZCxrbPmX4D3LbT++,
mc__lO81KuDBk41W9Wd2wAkb0++){mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_VjOKR9Oi4Nx_a9R9oEty_X[mc_V5XnIQ0HZCxrbPmX4D3LbT];mc_Fo1tUR18sIdue1E1QXuOnL
[mc__lO81KuDBk41W9Wd2wAkb0]= &mc_FGty7dNhdoxeiPHYbn7B52[
mc__GGFaLirzMOkais94_xH_b[mc_kwrB3ZoKf7OufTHWaHJV7a]];
mc___7SXc4Q_w8saDIIf2ecjp[mc__lO81KuDBk41W9Wd2wAkb0]= &
mc_FGty7dNhdoxeiPHYbn7B52[mc__GGFaLirzMOkais94_xH_b[mc_kwrB3ZoKf7OufTHWaHJV7a+
1]];}mc__6B9YAP8szKvjq2kQ8O6VO[mc_kyp6uAyJE40UVuAQNEYzS1]=((int32_T)(
mc_kNgcOktCtQxdYedrGvFn5i));mc_kNgcOktCtQxdYedrGvFn5i+=
mc_FMVi5zjKc7GleyvbJheUkd(mc__lO81KuDBk41W9Wd2wAkb0,mc_Fo1tUR18sIdue1E1QXuOnL,
mc___7SXc4Q_w8saDIIf2ecjp);}mc__6B9YAP8szKvjq2kQ8O6VO[n]=((int32_T)(
mc_kNgcOktCtQxdYedrGvFn5i));mc_kwUVpSNUux4FXLAocRFjyD=
mc__ILFYYSbi7hW_uYs_eHsRR->mIr=(int32_T*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(mc_kNgcOktCtQxdYedrGvFn5i),(sizeof(
int32_T))));for(mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<n;
mc_kyp6uAyJE40UVuAQNEYzS1++){int32_T mc_V5XnIQ0HZCxrbPmX4D3LbT;for(
mc_V5XnIQ0HZCxrbPmX4D3LbT=mc_kbRitxPnTtKShL8FInz4nW[mc_kyp6uAyJE40UVuAQNEYzS1]
,mc__lO81KuDBk41W9Wd2wAkb0=0;mc_V5XnIQ0HZCxrbPmX4D3LbT<
mc_kbRitxPnTtKShL8FInz4nW[mc_kyp6uAyJE40UVuAQNEYzS1+1];
mc_V5XnIQ0HZCxrbPmX4D3LbT++,mc__lO81KuDBk41W9Wd2wAkb0++){
mc_kwrB3ZoKf7OufTHWaHJV7a=mc_VjOKR9Oi4Nx_a9R9oEty_X[mc_V5XnIQ0HZCxrbPmX4D3LbT]
;mc_Fo1tUR18sIdue1E1QXuOnL[mc__lO81KuDBk41W9Wd2wAkb0]= &
mc_FGty7dNhdoxeiPHYbn7B52[mc__GGFaLirzMOkais94_xH_b[mc_kwrB3ZoKf7OufTHWaHJV7a]
];mc___7SXc4Q_w8saDIIf2ecjp[mc__lO81KuDBk41W9Wd2wAkb0]= &
mc_FGty7dNhdoxeiPHYbn7B52[mc__GGFaLirzMOkais94_xH_b[mc_kwrB3ZoKf7OufTHWaHJV7a+
1]];}mc_FOc1NFJKwbKEbmH1_ROOZu(&mc_kwUVpSNUux4FXLAocRFjyD[
mc__6B9YAP8szKvjq2kQ8O6VO[mc_kyp6uAyJE40UVuAQNEYzS1]],((int32_T)(
mc__lO81KuDBk41W9Wd2wAkb0)),mc_Fo1tUR18sIdue1E1QXuOnL,
mc___7SXc4Q_w8saDIIf2ecjp);}{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc_Fo1tUR18sIdue1E1QXuOnL);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(pm__8zlSpb2Hixod149p2zadR,
mc_kk06poLCQlh5i5Yv6GSh7e);}};return mc__ILFYYSbi7hW_uYs_eHsRR;}void
mc__tyTSVoY7fpafmg4sUl1P3(const PmRealVector*mc_kuYGZlr6GiOSeqresCsPcM,const
PmSparsityPattern*mc__ILFYYSbi7hW_uYs_eHsRR,const PmRealVector*
mc_FmeGGSq6P2_Kg9j7twxwci,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
const PmRealVector*mc_FQSQWg_QFOKIWm9DWdLQR6,const PmSparsityPattern*
mc_VLr_Ia18P_8icXM9WFOfYI,const PmRealVector*mc_krOJvR5Qa1KQZu3eEsQtEU){size_t
n=mc_VLr_Ia18P_8icXM9WFOfYI->mNumCol;int32_T*mc__GGFaLirzMOkais94_xH_b=
mc_V_ku0ZO8TOxhc9438tlsBI->mJc;int32_T*mc_FGty7dNhdoxeiPHYbn7B52=
mc_V_ku0ZO8TOxhc9438tlsBI->mIr;int32_T*mc_kbRitxPnTtKShL8FInz4nW=
mc_VLr_Ia18P_8icXM9WFOfYI->mJc;int32_T*mc_VjOKR9Oi4Nx_a9R9oEty_X=
mc_VLr_Ia18P_8icXM9WFOfYI->mIr;int32_T*mc__6B9YAP8szKvjq2kQ8O6VO=
mc__ILFYYSbi7hW_uYs_eHsRR->mJc;int32_T*mc_kwUVpSNUux4FXLAocRFjyD=
mc__ILFYYSbi7hW_uYs_eHsRR->mIr;size_t mc_kwrB3ZoKf7OufTHWaHJV7a,
mc_kyp6uAyJE40UVuAQNEYzS1;int32_T mc__lO81KuDBk41W9Wd2wAkb0;real_T
mc_kHfMSiCBJRSoju34wwOKOx;const real_T*mc_F2l4p_g4sn02huHNflQjMH=
mc_FmeGGSq6P2_Kg9j7twxwci->mX;const real_T*mc_Vqiy96WqvuhCaXm5e_vvT0=
mc_FQSQWg_QFOKIWm9DWdLQR6->mX;real_T*mc_FStFcQlyAJ_dVy4kGZXBPQ=
mc_kuYGZlr6GiOSeqresCsPcM->mX;real_T*mc_VRZCD_UL_ESThy75dC9J8D=
mc_krOJvR5Qa1KQZu3eEsQtEU->mX;;;;;;mc__aNO1s5qwzt6fXwft5YgCz(
mc_krOJvR5Qa1KQZu3eEsQtEU);for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<n;mc_kyp6uAyJE40UVuAQNEYzS1++){int32_T
mc_V5XnIQ0HZCxrbPmX4D3LbT;for(mc_V5XnIQ0HZCxrbPmX4D3LbT=
mc_kbRitxPnTtKShL8FInz4nW[mc_kyp6uAyJE40UVuAQNEYzS1];mc_V5XnIQ0HZCxrbPmX4D3LbT
<mc_kbRitxPnTtKShL8FInz4nW[mc_kyp6uAyJE40UVuAQNEYzS1+1];
mc_V5XnIQ0HZCxrbPmX4D3LbT++){mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_VjOKR9Oi4Nx_a9R9oEty_X[mc_V5XnIQ0HZCxrbPmX4D3LbT];mc_kHfMSiCBJRSoju34wwOKOx
=mc_Vqiy96WqvuhCaXm5e_vvT0[mc_V5XnIQ0HZCxrbPmX4D3LbT];for(
mc__lO81KuDBk41W9Wd2wAkb0=mc__GGFaLirzMOkais94_xH_b[mc_kwrB3ZoKf7OufTHWaHJV7a]
;mc__lO81KuDBk41W9Wd2wAkb0<mc__GGFaLirzMOkais94_xH_b[mc_kwrB3ZoKf7OufTHWaHJV7a
+1];mc__lO81KuDBk41W9Wd2wAkb0++){mc_VRZCD_UL_ESThy75dC9J8D[
mc_FGty7dNhdoxeiPHYbn7B52[mc__lO81KuDBk41W9Wd2wAkb0]]+=
mc_kHfMSiCBJRSoju34wwOKOx*mc_F2l4p_g4sn02huHNflQjMH[mc__lO81KuDBk41W9Wd2wAkb0]
;}}for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc__ILFYYSbi7hW_uYs_eHsRR->mNumRow;mc_kwrB3ZoKf7OufTHWaHJV7a++){}for(
mc_V5XnIQ0HZCxrbPmX4D3LbT=mc__6B9YAP8szKvjq2kQ8O6VO[mc_kyp6uAyJE40UVuAQNEYzS1]
;mc_V5XnIQ0HZCxrbPmX4D3LbT<mc__6B9YAP8szKvjq2kQ8O6VO[mc_kyp6uAyJE40UVuAQNEYzS1
+1];mc_V5XnIQ0HZCxrbPmX4D3LbT++){mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_kwUVpSNUux4FXLAocRFjyD[mc_V5XnIQ0HZCxrbPmX4D3LbT];mc_FStFcQlyAJ_dVy4kGZXBPQ
[mc_V5XnIQ0HZCxrbPmX4D3LbT]=mc_VRZCD_UL_ESThy75dC9J8D[
mc_kwrB3ZoKf7OufTHWaHJV7a];mc_VRZCD_UL_ESThy75dC9J8D[mc_kwrB3ZoKf7OufTHWaHJV7a
]=0.0;}}}PmSparsityPattern*mc_VI58f6RQKXS_Y5sclnoOPT(const PmSparsityPattern*a
,const PmSparsityPattern*b,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY){size_t
pm_kplAJmOlA30feiNcOzi7oj=a->mNumRow;size_t mc_Ft65Vg0EYXGZc1U2hhnDR3=a->
mNumCol;size_t mc_FfB_cKVsLVCbi1JUbosj0G=((size_t)(a)->mJc[(a)->mNumCol]);
size_t mc__7__ujF80mGeci_UJ9h5o5=b->mNumCol;size_t mc_F1iQRckkC3xShHqq_EqsVq=(
(size_t)(b)->mJc[(b)->mNumCol]);PmSparsityPattern mc_kKUYaAfBZwdNgqnuatsGau;
PmIntVector mc_VFy7T5dMeuhNjXZOl9Vfx4;PmSparsityPattern*
mc_V2mBNcV1EqCifyH9UdCbkF=pm_create_sparsity_pattern(mc_FfB_cKVsLVCbi1JUbosj0G
+mc_F1iQRckkC3xShHqq_EqsVq,pm_kplAJmOlA30feiNcOzi7oj,mc_Ft65Vg0EYXGZc1U2hhnDR3
+mc__7__ujF80mGeci_UJ9h5o5,pm_FbYb_iLqY2hwZTVlVaiqJY);;
mc_kKUYaAfBZwdNgqnuatsGau= *a;mc_kKUYaAfBZwdNgqnuatsGau.mJc=
mc_V2mBNcV1EqCifyH9UdCbkF->mJc;mc_kKUYaAfBZwdNgqnuatsGau.mIr=
mc_V2mBNcV1EqCifyH9UdCbkF->mIr;((&mc_kKUYaAfBZwdNgqnuatsGau)->mJc[(&
mc_kKUYaAfBZwdNgqnuatsGau)->mNumCol]=(int32_T)(mc_FfB_cKVsLVCbi1JUbosj0G));
pm_kTFq3qlgTulWiT6pafkmmT(&mc_kKUYaAfBZwdNgqnuatsGau,a);
mc_kKUYaAfBZwdNgqnuatsGau= *b;mc_kKUYaAfBZwdNgqnuatsGau.mJc=
mc_V2mBNcV1EqCifyH9UdCbkF->mJc+mc_Ft65Vg0EYXGZc1U2hhnDR3;
mc_kKUYaAfBZwdNgqnuatsGau.mIr=mc_V2mBNcV1EqCifyH9UdCbkF->mIr+
mc_FfB_cKVsLVCbi1JUbosj0G;((&mc_kKUYaAfBZwdNgqnuatsGau)->mJc[(&
mc_kKUYaAfBZwdNgqnuatsGau)->mNumCol]=(int32_T)(mc_F1iQRckkC3xShHqq_EqsVq));
pm_kTFq3qlgTulWiT6pafkmmT(&mc_kKUYaAfBZwdNgqnuatsGau,b);
mc_VFy7T5dMeuhNjXZOl9Vfx4 .mN=mc__7__ujF80mGeci_UJ9h5o5+1;
mc_VFy7T5dMeuhNjXZOl9Vfx4 .mX=mc_kKUYaAfBZwdNgqnuatsGau.mJc;
mc_FioOBDJiFMpkWaAcUdBb1E(&mc_VFy7T5dMeuhNjXZOl9Vfx4,((int32_T)(
mc_FfB_cKVsLVCbi1JUbosj0G)));return mc_V2mBNcV1EqCifyH9UdCbkF;}
