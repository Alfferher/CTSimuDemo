#ifndef __ne_dae_fwd_h__
#define __ne_dae_fwd_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
typedef struct NeDaeTag NeDae;
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __ne_dae_fwd_h__ */
