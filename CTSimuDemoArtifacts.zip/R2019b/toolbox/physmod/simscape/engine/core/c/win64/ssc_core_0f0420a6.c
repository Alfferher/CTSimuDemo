#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
typedef struct ssc_core_V3scVTYpjYthiPB7SQIxc_ ssc_core_FlZrG1BcKjtGV1aBRQ0fZ8
;typedef struct ssc_core_kIPOBZ_WiKlfjLUfb6Vbcm ssc_core__SHoBDzmLMOwaLvvD5hSet
;struct ssc_core_kIPOBZ_WiKlfjLUfb6Vbcm{boolean_T(*
ssc_core_FBsF3SW3Cyp_j5Pu5wPhdl)(const ssc_core__SHoBDzmLMOwaLvvD5hSet*
ssc_core_FeUzPe0YQn4rca7KjD_v4G,const NeSystemInput*mc_kDRphcAfRHSbf1ZLKEDW9k)
;void(*mc_VrNsQKHIiLOFaL3PHRFxZL)(const ssc_core__SHoBDzmLMOwaLvvD5hSet*
ssc_core_FeUzPe0YQn4rca7KjD_v4G);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core_FeUzPe0YQn4rca7KjD_v4G);
ssc_core_FlZrG1BcKjtGV1aBRQ0fZ8*mc_VFNhKLCqbHpDYXjdjCOMmT;};
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core__BnL6AKHA_KDhap6bFRZzx(
NeSystemInputSizes ne_kCK4VKKlkwtEXP7Ya6eu5y,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);
#include "pm_std.h"
struct ssc_core_V3scVTYpjYthiPB7SQIxc_{PmAllocator*
ssc_core_Ff9S1xA4Ip4ZXeljM4_eEa;};static boolean_T
ssc_core_kTtSUEBuNYSDc5jvQsk369(const ssc_core__SHoBDzmLMOwaLvvD5hSet*
ssc_core_FeUzPe0YQn4rca7KjD_v4G,const NeSystemInput*mc_kDRphcAfRHSbf1ZLKEDW9k)
{return true;}static void ssc_core_VKp00NftRMt9VHXCrTxU2Z(const
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core_FeUzPe0YQn4rca7KjD_v4G){(void)
ssc_core_FeUzPe0YQn4rca7KjD_v4G;}static void ssc_core_VhM6LeTCpVKS_9UnRhu_KK(
ssc_core__SHoBDzmLMOwaLvvD5hSet*ssc_core_FeUzPe0YQn4rca7KjD_v4G){
ssc_core_FlZrG1BcKjtGV1aBRQ0fZ8*mc__d1alWYexptL_X5HTFhbNK=
ssc_core_FeUzPe0YQn4rca7KjD_v4G->mc_VFNhKLCqbHpDYXjdjCOMmT;PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY=mc__d1alWYexptL_X5HTFhbNK->
ssc_core_Ff9S1xA4Ip4ZXeljM4_eEa;{void*ssc_core_kk06poLCQlh5i5Yv6GSh7e=(
mc__d1alWYexptL_X5HTFhbNK);if(ssc_core_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
ssc_core_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_core_kk06poLCQlh5i5Yv6GSh7e=(
ssc_core_FeUzPe0YQn4rca7KjD_v4G);if(ssc_core_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
ssc_core_kk06poLCQlh5i5Yv6GSh7e);}};}ssc_core__SHoBDzmLMOwaLvvD5hSet*
ssc_core__BnL6AKHA_KDhap6bFRZzx(NeSystemInputSizes ne_kCK4VKKlkwtEXP7Ya6eu5y,
PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY){ssc_core__SHoBDzmLMOwaLvvD5hSet*
ssc_core_FeUzPe0YQn4rca7KjD_v4G=(ssc_core__SHoBDzmLMOwaLvvD5hSet*)((
pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(
ssc_core__SHoBDzmLMOwaLvvD5hSet)),(1)));ssc_core_FlZrG1BcKjtGV1aBRQ0fZ8*
mc__d1alWYexptL_X5HTFhbNK=(ssc_core_FlZrG1BcKjtGV1aBRQ0fZ8*)((
pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(
ssc_core_FlZrG1BcKjtGV1aBRQ0fZ8)),(1)));mc__d1alWYexptL_X5HTFhbNK->
ssc_core_Ff9S1xA4Ip4ZXeljM4_eEa=pm_FbYb_iLqY2hwZTVlVaiqJY;
ssc_core_FeUzPe0YQn4rca7KjD_v4G->ssc_core_FBsF3SW3Cyp_j5Pu5wPhdl=
ssc_core_kTtSUEBuNYSDc5jvQsk369;ssc_core_FeUzPe0YQn4rca7KjD_v4G->
mc_VrNsQKHIiLOFaL3PHRFxZL=ssc_core_VKp00NftRMt9VHXCrTxU2Z;
ssc_core_FeUzPe0YQn4rca7KjD_v4G->mc_VYGWBho6N1K_eyHOMGjDiW=
ssc_core_VhM6LeTCpVKS_9UnRhu_KK;ssc_core_FeUzPe0YQn4rca7KjD_v4G->
mc_VFNhKLCqbHpDYXjdjCOMmT=mc__d1alWYexptL_X5HTFhbNK;return
ssc_core_FeUzPe0YQn4rca7KjD_v4G;}
